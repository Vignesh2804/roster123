import { createBrowserHistory } from "history";

const History = createBrowserHistory();

export default History; 