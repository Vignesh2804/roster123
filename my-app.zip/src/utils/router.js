/** * Import libraries ** */
import React, { Suspense } from "react";
import { Route, Switch, Router } from "react-router-dom";
/** * Import Layouts ** */
import Layout from "../Containers/Layouts/index";
import DashboardHeader from "../Containers/Layouts/DashboardHeader";

/** * Import History ** */
import History from "./history";

/** * Import Pages ** */ //LazyLoading
const Login = React.lazy(() => import("../Containers/Pages/Login"));
const DashboardPage = React.lazy(() => import("../Containers/Pages/Dashboard"));
const Feed = React.lazy(() => import("../Containers/Pages/Feeds"));
const Schedules = React.lazy(() => import("../Containers/Pages/Schedules"));
const Task = React.lazy(() => import("../Containers/Pages/Tasks"));
const Chat = React.lazy(() => import("../Containers/Pages/Chats"));
const Timesheet = React.lazy(() => import("../Containers/Pages/Timesheets"));
const SignUp = React.lazy(() => import("../Containers/Pages/Signup"));
const EmployeeList = React.lazy(() => import("../Containers/Pages/Employees"));
const PositionsList = React.lazy(() => import("../Containers/Pages/Positions"));
const LocationsList = React.lazy(() => import("../Containers/Pages/Locations"));
const GroupsList = React.lazy(() => import("../Containers/Pages/Groups"));
const TagsList = React.lazy(() => import("../Containers/Pages/Tags"));
const Settings = React.lazy(() => import("../Containers/Pages/Settings"));
const Reports = React.lazy(() => import("../Containers/Pages/Reports"));

const AnnouncementsList = React.lazy(() =>
  import("../Containers/Pages/Announcements")
);
const LaborCost = React.lazy(() => import("../Containers/Pages/Laborcost"));
const AddEmployee = React.lazy(() =>
  import("../Containers/Pages/Employees/AddEmployee")
);
const AddPosition = React.lazy(() =>
  import("../Containers/Pages/Positions/AddPosition")
);
const AddLocation = React.lazy(() =>
  import("../Containers/Pages/Locations/AddLocation")
);
const AddGroup = React.lazy(() =>
  import("../Containers/Pages/Groups/AddGroup")
);
const AddTag = React.lazy(() => import("../Containers/Pages/Tags/AddTag"));

const MainRouter = (props) => (
  <Suspense fallback={<div>Loading...</div>}>
    <Router history={History}>
      <Switch>
        <Route exact path="/" render={() => <Login />} {...props} />
        <Route exact path="/login" render={() => <Login />} {...props} />
        <Route exact path="/signup" render={() => <SignUp />} {...props} />
        <Route
          exact
          path="/dashboard"
          render={() => (
            <Layout>
              <DashboardHeader>
                <DashboardPage />
              </DashboardHeader>
            </Layout>
          )}
          {...props}
        />
        <Route
          path="/dashboard/employees"
          render={() => (
            <Layout>
              <DashboardHeader>
                <EmployeeList />
              </DashboardHeader>
            </Layout>
          )}
          {...props}
        />
        <Route
          path="/dashboard/positions"
          render={() => (
            <Layout>
              <DashboardHeader>
                <PositionsList />
              </DashboardHeader>
            </Layout>
          )}
          {...props}
        />
        <Route
          path="/dashboard/locations"
          render={() => (
            <Layout>
              <DashboardHeader>
                <LocationsList />
              </DashboardHeader>
            </Layout>
          )}
          {...props}
        />
        <Route
          path="/dashboard/groups"
          render={() => (
            <Layout>
              <DashboardHeader>
                <GroupsList />
              </DashboardHeader>
            </Layout>
          )}
          {...props}
        />
        <Route
          path="/dashboard/tags"
          render={() => (
            <Layout>
              <DashboardHeader>
                <TagsList />
              </DashboardHeader>
            </Layout>
          )}
          {...props}
        />
        <Route
          path="/dashboard/announcements"
          render={() => (
            <Layout>
              <DashboardHeader>
                <AnnouncementsList />
              </DashboardHeader>
            </Layout>
          )}
          {...props}
        />
        <Route
          path="/dashboard/laborcost"
          render={() => (
            <Layout>
              <DashboardHeader>
                <LaborCost />
              </DashboardHeader>
            </Layout>
          )}
          {...props}
        />
        <Route
          path="/dashboard/addemployee"
          render={() => (
            <Layout>
              <AddEmployee />
            </Layout>
          )}
          {...props}
        />
        <Route
          path="/dashboard/addposition"
          render={() => (
            <Layout>
              <AddPosition />
            </Layout>
          )}
          {...props}
        />
        <Route
          path="/dashboard/addlocation"
          render={() => (
            <Layout>
              <AddLocation />
            </Layout>
          )}
          {...props}
        />
        <Route
          path="/dashboard/addgroup"
          render={() => (
            <Layout>
              <AddGroup />
            </Layout>
          )}
          {...props}
        />
        <Route
          path="/dashboard/addtag"
          render={() => (
            <Layout>
              <AddTag />
            </Layout>
          )}
          {...props}
        />
        <Route
          exact
          path="/schedules"
          render={() => (
            <Layout>
              <Schedules />
            </Layout>
          )}
          {...props}
        />
        <Route
          exact
          path="/tasks"
          render={() => (
            <Layout>
              <Task />
            </Layout>
          )}
          {...props}
        />
        <Route
          exact
          path="/chats"
          render={() => (
            <Layout>
              <Chat />
            </Layout>
          )}
          {...props}
        />
        <Route
          exact
          path="/feeds"
          render={() => (
            <Layout>
              <Feed />
            </Layout>
          )}
          {...props}
        />
        <Route
          exact
          path="/timesheets"
          render={() => (
            <Layout>
              <Timesheet />
            </Layout>
          )}
          {...props}
        />
        <Route
          exact
          path="/settings"
          render={() => (
            <Layout>
              <Settings />
            </Layout>
          )}
          {...props}
        />
        <Route
          exact
          path="/reports"
          render={() => (
            <Layout>
              <Reports />
            </Layout>
          )}
          {...props}
        />
        {/* <Route exact path="/*" render={() => <UrlNotFoundPage />} {...props} /> */}
      </Switch>
    </Router>
  </Suspense>
);

export default MainRouter;
