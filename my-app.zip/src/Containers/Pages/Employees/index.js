import React from "react";
import CustomDataTable from "../../../Components/CustomDataTable";
import SubHeader from "../../../Components/SubHeader";

import { Delete, Edit, Mail, NoAccounts } from "@mui/icons-material";
import { GridActionsCellItem } from "@mui/x-data-grid";

const EmployeeList = (props) => {
  const deleteUser = (id) => {
    return;
  };

  const inviteUser = (id) => {
    return;
  };

  const deactivateUser = (id) => {
    return;
  };

  const editUser = (id) => {
    return;
  };

  const EmployeesColumns = [
    { field: "name", headerName: "Name", flex: 1 },
    { field: "employeeID", headerName: "Employee ID", flex: 1 },
    {
      field: "positions",
      headerName: "Positions",
      width: 200,
      valueFormatter: (params) => {
        // console.log(
        //   "params ===> ",
        //   params.value.toString().split(",").join("\r\n")
        // );
        return params.value.toString();
      },
    },
    { field: "locations", headerName: "Locations", flex: 1 },
    { field: "groups", headerName: "Groups", flex: 1 },
    { field: "email", headerName: "Email", width: 200 },
    { field: "phone", headerName: "Phone", flex: 1 },
    { field: "status", headerName: "Status", flex: 1 },
    {
      field: "actions",
      type: "actions",
      width: 80,
      getActions: (params) => [
        <GridActionsCellItem
          icon={<Edit />}
          label="Edit"
          onClick={editUser(params.id)}
        />,
        <GridActionsCellItem
          icon={<Delete />}
          label="Delete"
          onClick={deleteUser(params.id)}
          showInMenu
        />,
        <GridActionsCellItem
          icon={<Mail />}
          label="Invite"
          onClick={inviteUser(params.id)}
          showInMenu
        />,
        <GridActionsCellItem
          icon={<NoAccounts />}
          label="Deactivate"
          onClick={deactivateUser(params.id)}
          showInMenu
        />,
      ],
    },
  ];

  const EmployeesData = [
    {
      id: Math.random().toString(),
      name: "Vinoth",
      employeeID: "29083",
      positions: ["Executive", "Senior Executive"],
      locations: ["XYZ", "ABC"],
      groups: ["HR"],
      email: "sivavintha@yahoo.co.in",
      phone: "+919677535702",
      status: "Joined",
    },
    {
      id: Math.random().toString(),
      name: "Rakesh",
      employeeID: "30165",
      positions: ["Junior Executive"],
      locations: ["ABC"],
      groups: ["IT"],
      email: "sivavintha23@gmail.com",
      phone: "+918838658678",
      status: "Invited",
    },
  ];
  
  return (
    <>
      <SubHeader
        heading={"2 Employees"}
        buttonText="Employee"
        navigateTo="/dashboard/addemployee"
        ButtonType="navigation"
      />
      <br />
      <CustomDataTable
        title="Employees"
        columns={EmployeesColumns}
        rows={EmployeesData}
        elevation={6}
        checkboxNeeded
      />
    </>
  );
};

export default EmployeeList;
