import React, { useState } from "react";

import {
  Button,
  CssBaseline,
  TextField,
  Grid,
  Box,
  Container,
  MenuItem,
  InputLabel,
  FormControl,
  Select,
  FormLabel,
  Switch,
  Breadcrumbs,
  Link,
  IconButton,
} from "@mui/material";
import CountrySelector from "../../../Components/CountrySelector";
import { useHistory } from "react-router";
import SelectTimezoneMaterialUi from "select-timezone-material-ui";
import CustomAutoComplete from "../../../Components/CustomAutoComplete";
import { ArrowBack } from "@material-ui/icons";
import AddPagesHeader from "../../../Components/AddPagesHeader";

const AddEmployee = (props) => {
  const history = useHistory();
  const [timezone, setTimeZone] = useState({});
  const [systemRole, setSystemRole] = useState("employee");
  const [locations, setLocations] = useState([{ label: "xyz" }]);
  const [positions, setPositions] = useState([{ label: "Senior Executive" }]);
  const [groups, setGroups] = useState([{ label: "HR" }]);
  const [managers, setManagers] = useState([{ label: "Rakesh S" }]);

  const handleSubmit = (event) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    // eslint-disable-next-line no-console
    console.log({
      email: data.get("email"),
      password: data.get("password"),
    });

    history.push("/dashboard/employees");
  };

  const handleTimeZoneChange = (timezoneName, timezoneOffset) => {
    console.log(timezoneName);
    setTimeZone(timezoneName);
  };

  const handleRoleChange = (role) => {
    setSystemRole(role);
  };

  const handleBackClick = (e) => {
    e.preventDefault();
    history.push("/dashboard/employees");
  };

  const RenderForm = () => {
    return (
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <Box component="form" noValidate onSubmit={handleSubmit} sx={{ mt: 3 }}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <TextField
                autoComplete="fname"
                name="firstName"
                required
                fullWidth
                id="firstName"
                label="First Name"
                autoFocus
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                id="lastName"
                label="Last Name"
                name="lastName"
                autoComplete="lname"
              />
            </Grid>

            <Grid item xs={12}>
              <TextField
                required
                fullWidth
                id="email"
                label="Email Address"
                name="email"
                autoComplete="email"
              />
            </Grid>

            <Grid item xs={12} sm={5}>
              <CountrySelector required />
            </Grid>
            <Grid item xs={12} sm={7}>
              <TextField
                required
                fullWidth
                id="phoneNumber"
                label="Phone Number"
                name="phoneNumber"
                autoComplete="phoneNumber"
                type="number"
              />
            </Grid>
            <Grid item xs={12}>
              <div style={{ textAlign: "left" }}>
                <SelectTimezoneMaterialUi
                  label="Timezone"
                  helperText="Please select a timezone from the list"
                  onChange={handleTimeZoneChange}
                  showTimezoneOffset={true}
                />
              </div>
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth sx={{ textAlign: "left" }}>
                <InputLabel id="system-role-label">System Role</InputLabel>
                <Select
                  labelId="system-role-label"
                  id="systemrole"
                  value={systemRole}
                  label="System Role"
                  onChange={handleRoleChange}
                >
                  <MenuItem value={"admin"}>Admin</MenuItem>
                  <MenuItem value={"manager"}>Manager</MenuItem>
                  <MenuItem value={"employee"}>Employee</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                autoComplete="empId"
                name="empId"
                fullWidth
                id="empId"
                label="Employee ID"
              />
            </Grid>
            <Grid item xs={12} sm={4}>
              <FormLabel component="p" sx={{ textAlign: "left" }}>
                Locations
              </FormLabel>
            </Grid>
            <Grid item xs={12} sm={8}>
              <CustomAutoComplete
                id="locations"
                options={locations}
                inputLabel=""
              />
            </Grid>

            <Grid item xs={12} sm={4}>
              <FormLabel component="p" sx={{ textAlign: "left" }}>
                Positions
              </FormLabel>
            </Grid>
            <Grid item xs={12} sm={8}>
              <CustomAutoComplete
                id="positions"
                options={positions}
                inputLabel=""
              />
            </Grid>

            <Grid item xs={12} sm={4}>
              <FormLabel component="p" sx={{ textAlign: "left" }}>
                Groups
              </FormLabel>
            </Grid>
            <Grid item xs={12} sm={8}>
              <CustomAutoComplete id="groups" options={groups} inputLabel="" />
            </Grid>

            <Grid item xs={12} sm={4}>
              <FormLabel component="p" sx={{ textAlign: "left" }}>
                Managers
              </FormLabel>
            </Grid>
            <Grid item xs={12} sm={8}>
              <CustomAutoComplete
                id="managers"
                options={managers}
                inputLabel=""
              />
            </Grid>

            <Grid item xs={12} sm={4}>
              <FormLabel component="p" sx={{ textAlign: "left" }}>
                Send Invite
              </FormLabel>
            </Grid>
            <Grid item xs={12} sm={8} sx={{ textAlign: "right" }}>
              <Switch defaultChecked />
            </Grid>

            <Grid item xs={12} sm={4}>
              <FormLabel component="p" sx={{ textAlign: "left" }}>
                Grand Access
              </FormLabel>
            </Grid>
            <Grid item xs={12} sm={8} sx={{ textAlign: "right" }}>
              <Switch defaultChecked />
            </Grid>

            <Grid item xs={12} sm={6}>
              <Button
                fullWidth
                variant="contained"
                sx={{ mt: 3, mb: 2, backgroundColor: "#616161" }}
                onClick={handleBackClick}
              >
                Cancel
              </Button>
            </Grid>

            <Grid item xs={12} sm={6}>
              <Button
                type="submit"
                fullWidth
                variant="contained"
                sx={{ mt: 3, mb: 2 }}
                color={"secondary"}
              >
                Save
              </Button>
            </Grid>
          </Grid>
        </Box>
      </Box>
    );
  };

  return (
    <Grid
      container
      sx={{ display: "flex", flexDirection: "column", alignItems: "center" }}
    >
      <Grid
        item
        xs={8}
        sx={{
          mt: "15px",
          width: "100%",
          backgroundColor: "#ffffff",
          borderRadius: "10px",
        }}
      >
        <AddPagesHeader
          firstLink="Employee"
          secondLink="Add Employee"
          navigateTo="/dashboard/employees"
        />
      </Grid>

      <Grid item xs={12}>
        <Container component="main" maxWidth="sm">
          <CssBaseline />
          <RenderForm />
        </Container>
      </Grid>
    </Grid>
  );
};

export default AddEmployee;
