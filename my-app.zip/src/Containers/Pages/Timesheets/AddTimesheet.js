import React, { useEffect, useState } from "react";
import moment from "moment";
import {
  Add,
  AddCircleOutlined,
  Close,
  Delete,
  RemoveCircle,
  RemoveCircleOutlined,
  TaskAltOutlined,
} from "@mui/icons-material";
import {
  Grid,
  Button,
  TextField,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Box,
  Divider,
  FormLabel,
  Tooltip,
  Autocomplete,
} from "@mui/material";
import CustomDateTimePicker from "../../../Components/CustomDateTimePicker";

const employeeList = [
  {
    id: "emp1",
    name: "Employee 1",
  },
];

const locationList = [
  {
    id: "xyz",
    name: "Xyz",
  },
];

const positionList = [
  {
    id: "srExecutive",
    name: "Senior Executive",
  },
];

const BreakTime = (props) => {
  return (
    <Grid container spacing={2}>
      <Grid item xs={12} sm={3}>
        <FormLabel sx={{ textAlign: "left" }}>Break</FormLabel>
      </Grid>
      <Grid item xs={12} sm={4}>
        <CustomDateTimePicker
          label="Start"
          id={props.id + "_Start"}
          onChange={props.dateChangeHandler}
          value={props.dateValue && props.dateValue[props.id + "_Start"]}
        />
      </Grid>
      <Grid item xs={12} sm={4}>
        <CustomDateTimePicker
          label="End"
          id={props.id + "_End"}
          onChange={props.dateChangeHandler}
          value={props.dateValue && props.dateValue[props.id + "_End"]}
        />
      </Grid>
      <Grid item xs={12} sm={1} sx={{ display: "flex", alignItems: "center" }}>
        <Delete
          onClick={() => props.removeHandler(props.breakTime.id)}
        ></Delete>
      </Grid>
    </Grid>
  );
};

const ClockTime = (props) => {
  const handleRemovClock = () => {
    props.removeHandler(props.clockTime.id);
  };

  return (
    <Grid container spacing={2} sx={{ mt: "5px" }}>
      <Grid item xs={12} sm={3}>
        <FormLabel sx={{ textAlign: "left" }}>Clock In</FormLabel>
      </Grid>
      <Grid item xs={12} sm={5}>
        <CustomDateTimePicker
          id={props.id + "_clockIn"}
          onChange={props.dateChangeHandler}
          value={props.dateValue && props.dateValue[props.id + "_clockIn"]}
        />
      </Grid>
      <Grid item xs={12} sm={4} sx={{ display: "flex", alignItems: "center" }}>
        {!props.hideRemoveClockButton && (
          <Button
            variant="text"
            endIcon={<Delete />}
            size="small"
            onClick={handleRemovClock}
          >
            Remove
          </Button>
        )}
      </Grid>
      {props.clockTime.breakTime &&
        props.clockTime.breakTime.length > 0 &&
        props.clockTime.breakTime.map((brk) => (
          <Grid item xs={12} key={brk.id}>
            <BreakTime
              id={props.id + "_" + brk.id}
              breakTime={brk}
              removeHandler={() => props.removeBreakHandler(props.id, brk.id)}
              dateChangeHandler={props.dateChangeHandler}
              dateValue={props.dateValue}
            />
          </Grid>
        ))}
      <Grid item xs={12} sm={3}>
        <FormLabel sx={{ textAlign: "left" }}>Clock Out</FormLabel>
      </Grid>
      <Grid item xs={12} sm={5}>
        <CustomDateTimePicker
          id={props.id + "_clockOut"}
          onChange={props.dateChangeHandler}
          value={props.dateValue && props.dateValue[props.id + "_clockOut"]}
        />
      </Grid>
      <Grid item xs={12} sm={4} sx={{ display: "flex", alignItems: "center" }}>
        <Button
          variant="text"
          endIcon={<Add />}
          size="small"
          onClick={() => props.addBreakHandler(props.id)}
        >
          Add Break
        </Button>
      </Grid>
      <Grid item xs={12}>
        <Divider />
      </Grid>
    </Grid>
  );
};

const AddTimeSheet = (props) => {
  const [employee, setEmployee] = useState(null);
  const [locations, setLocations] = useState(null);
  const [positions, setPositions] = useState(null);
  const [dateValue, setDateValue] = useState(null);
  const [totalHours, setTotalHours] = useState(0);
  const [formattedTotalHours, setFormattedTotalHours] = useState(null);

  const [clockTime, setClockTime] = useState([
    {
      id: "clockTime1",
      clockIn: "",
      clockOut: "",
      breakTime: [],
      totalBreak: 0,
      totalHours: 0,
    },
  ]);

  const handleEmployeeChange = (event, newValue) => {
    setEmployee(newValue);
  };

  const handleLocationChange = (event, newValue) => {
    setLocations(newValue);
  };

  const handlePositionChange = (event, newValue) => {
    setPositions(newValue);
  };

  const handleDateChange = (fieldId, value) => {
    setDateValue({ ...dateValue, [fieldId]: value });

    let clockId = fieldId.split("_");

    let clkTime = [...clockTime];

    let newArr = clkTime.filter((clk) => clk.id === clockId[0]);

    let clkObj = newArr[0];

    if (clockId[1] === "clockIn") {
      clkObj.clockIn = value;
    }

    if (clockId[1] === "clockOut") {
      clkObj.clockOut = value;
    }

    if (clockId[1].includes("breakTime")) {
      let nBrkArr = clkObj.breakTime.filter((brk) => brk.id === clockId[1]);

      if (nBrkArr && nBrkArr.length > 0) {
        let existingObj = nBrkArr[0];
        existingObj[clockId[2]] = value;
      } else {
        let obj = {};
        obj.id = clockId[1];
        obj[clockId[2]] = value;
        clkObj.breakTime.push(obj);
      }
    }

    if (clkObj.hasOwnProperty("clockIn") && clkObj.hasOwnProperty("clockOut")) {
      let ms = moment(clkObj.clockOut).diff(moment(clkObj.clockIn));

      let brk_ms = 0;
      clkObj.breakTime &&
        clkObj.breakTime.length > 0 &&
        clkObj.breakTime.map((brk) => {
          if (brk.hasOwnProperty("End") && brk.hasOwnProperty("Start")) {
            brk_ms += moment(brk.End).diff(moment(brk.Start));
          }
        });
      // let brk_d = moment.duration(brk_ms);
      // let brk_s =
      //   Math.floor(brk_d.asHours()) +
      //   "h " +
      //   moment.utc(brk_ms).format("mm") +
      //   "mins";

      // let d = moment.duration(ms - brk_ms);
      // let s =
      //   Math.floor(d.asHours()) +
      //   "h " +
      //   moment.utc(ms - brk_ms).format("mm") +
      //   "mins";

      clkObj.totalHours = ms - brk_ms;
      clkObj.totalBreak = brk_ms;
    }

    setClockTime(clkTime);
  };

  useEffect(() => {
    console.log("clockTime ===> ", clockTime);
    let clkTime = [...clockTime];
    setTotalHours(0);
    let totalTime = 0;
    clkTime.map((clk) => {
      totalTime += clk.totalHours;
    });
    setTotalHours(totalTime);
  }, [clockTime]);

  useEffect(() => {
    if (totalHours > 0) {
      let d = moment.duration(totalHours);
      let s =
        Math.floor(d.asHours()) +
        "h " +
        moment.utc(totalHours).format("mm") +
        "mins";
      console.log("totalHours ===> ", s);
      setFormattedTotalHours(s);
    }
  }, [totalHours]);

  const handleSubmit = () => {};

  const handleAddClock = () => {
    let id =
      clockTime && clockTime.length > 0
        ? "clockTime" +
          (+clockTime[clockTime.length - 1].id.match(/\d+/)[0] + 1)
        : "clockTime1";
    setClockTime([
      ...clockTime,
      {
        id: id,
        clockIn: "",
        clockOut: "",
        breakTime: [],
        totalBreak: 0,
        totalHours: 0,
      },
    ]);
  };

  const handleAddBreak = (clockId) => {
    let clkTime = [...clockTime];
    let clk = clkTime.filter((clk) => clk.id === clockId);
    let nObj = clk[0];

    let brkTimeArr = nObj.breakTime || [];

    console.log("brkTimeArr ===> ", brkTimeArr);
    let id =
      brkTimeArr && brkTimeArr.length > 0
        ? "breakTime" +
          (+brkTimeArr[brkTimeArr.length - 1].id.match(/\d+/)[0] + 1)
        : "breakTime1";

    let obj = {
      id: id,
    };

    brkTimeArr.push(obj);
    setClockTime(clkTime);
  };

  const handleRemoveBreak = (clockId, brkId) => {
    let clkTime = [...clockTime];
    let clk = clkTime.filter((clk) => clk.id === clockId);
    let nObj = clk[0];

    let brkTimeArr = nObj.breakTime.filter((brkTime) => brkTime.id !== brkId);

    nObj.breakTime = brkTimeArr;
    setClockTime(clkTime);
  };

  const handleRemoveClock = (clkid) => {
    let newArr = clockTime.filter((clkTime) => clkTime.id !== clkid);
    setClockTime(newArr);
  };

  return (
    <div>
      <Dialog open={props.open} onClose={props.closeHandler}>
        <DialogTitle sx={{ display: "flex", alignItems: "center" }}>
          <TaskAltOutlined
            sx={{ width: "32px", height: "32px", paddingRight: "5px" }}
          />{" "}
          New TimeSheet
          <Close
            sx={{ marginLeft: "auto", cursor: "pointer" }}
            onClick={props.closeHandler}
          />
        </DialogTitle>
        <DialogContent>
          <DialogContentText>
            <Divider />
          </DialogContentText>
          <Box component="form">
            <Grid container spacing={2} sx={{ mt: "10px" }}>
              <Grid item xs={12} sm={3}>
                <FormLabel sx={{ textAlign: "left" }}>Employee</FormLabel>
              </Grid>
              <Grid item xs={9}>
                <Autocomplete
                  id="employee"
                  options={employeeList}
                  getOptionLabel={(option) => option.name}
                  value={employee}
                  onChange={handleEmployeeChange}
                  renderInput={(params) => <TextField {...params} />}
                />
              </Grid>
              <Grid item xs={12} sm={3}>
                <FormLabel sx={{ textAlign: "left" }}>Location</FormLabel>
              </Grid>
              <Grid item xs={12} sm={9}>
                <Autocomplete
                  id="location"
                  options={locationList}
                  getOptionLabel={(option) => option.name}
                  value={locations}
                  onChange={handleLocationChange}
                  renderInput={(params) => <TextField {...params} />}
                />
              </Grid>

              <Grid item xs={12} sm={3}>
                <FormLabel sx={{ textAlign: "left" }}>Position</FormLabel>
              </Grid>
              <Grid item xs={12} sm={9}>
                <Autocomplete
                  id="position"
                  options={positionList}
                  getOptionLabel={(option) => option.name}
                  value={positions}
                  onChange={handlePositionChange}
                  renderInput={(params) => <TextField {...params} />}
                />
              </Grid>

              <Grid item xs={12}>
                <Divider />
              </Grid>
            </Grid>

            {clockTime &&
              clockTime.length > 0 &&
              clockTime.map((clock, index) => (
                <ClockTime
                  key={clock.id}
                  removeHandler={handleRemoveClock}
                  clockTime={clock}
                  id={clock.id}
                  dateChangeHandler={handleDateChange}
                  dateValue={dateValue}
                  addBreakHandler={handleAddBreak}
                  removeBreakHandler={handleRemoveBreak}
                  hideRemoveClockButton={index === 0 ? true : false}
                />
              ))}

            <Box>
              <Grid container spacing={2} sx={{ mt: "10px" }}>
                <Grid item xs={12} sm={3}>
                  <FormLabel sx={{ textAlign: "left" }}>Total Hours</FormLabel>
                </Grid>
                <Grid item xs={9}>
                  <FormLabel sx={{ textAlign: "left" }}>
                    {totalHours > 0 && formattedTotalHours
                      ? formattedTotalHours
                      : ""}
                  </FormLabel>
                </Grid>
              </Grid>
            </Box>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={props.closeHandler}
            variant="outlined"
            color={"primary"}
            onClick={handleAddClock}
          >
            Add Clock
          </Button>
          <Button
            onClick={props.closeHandler}
            variant="contained"
            sx={{ backgroundColor: "#616161" }}
          >
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            variant="contained"
            color={"secondary"}
            type="submit"
          >
            Save
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default AddTimeSheet;
