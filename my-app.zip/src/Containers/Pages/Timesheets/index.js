import React, { useState } from "react";
import {
  Tabs,
  Tab,
  Box,
  Button,
  Stack,
  Container,
  Typography,
  TextField,
  Paper,
  IconButton,
  Tooltip,
} from "@mui/material";
import SwipeableViews from "react-swipeable-views";
import ReportHeader from "../../../Components/ReportHeader";
import { useTheme } from "@mui/material/styles";
import TabPanel from "../../../Components/TabPanel";
import {
  Check,
  Delete,
  Edit,
  History,
  IosShare,
  Print,
  Settings,
} from "@mui/icons-material";
import AddTimeSheet from "./AddTimesheet";
import CollapsibleTable from "../../../Components/CustomCollapsibleTable";
import CustomDataTable from "../../../Components/CustomDataTable";
import { GridActionsCellItem } from "@mui/x-data-grid";

// const Columns = [
//   "Date",
//   "Emp ID",
//   "Emp Name",
//   "Location",
//   "Position",
//   "Groups",
//   "Tags",
//   "Shift Start",
//   "Shift End",
//   "Clock In",
//   "Clock Out",
//   "Break",
//   "Actual",
//   "Status",
//   "Actions",
// ];

// const rowData = [
//   {
//     id: "123456",
//     Date: "04-11-2021",
//     "Emp ID": "123456",
//     "Emp Name": "Vinoth S",
//     Location: "xyz",
//     Position: "Senior Executive",
//     Groups: "-",
//     Tags: "-",
//     "Shift Start": "9.00 am",
//     "Shift End": "06:30 pm",
//     "Clock In": "09:00 am",
//     "Clock Out": "06:30 pm",
//     Break: "30 mins",
//     Actual: "9:00",
//     Status: "Pending",
//     Actions: "",
//   },
//   {
//     id: "234567",
//     Date: "05-11-2021",
//     "Emp ID": "234567",
//     "Emp Name": "Vinoth S",
//     Location: "xyz",
//     Position: "Senior Executive",
//     Groups: "-",
//     Tags: "-",
//     "Shift Start": "9.00 am",
//     "Shift End": "06:30 pm",
//     "Clock In": "09:00 am",
//     "Clock Out": "06:30 pm",
//     Break: "30 mins",
//     Actual: "9:00",
//     Status: "Pending",
//     Actions: "",
//   },
// ];

const groupByOptions = [
  { label: "Date", value: "date", defaultChecked: true },
  { label: "Employees", value: "employees" },
  { label: "Positions", value: "position" },
];

const filterOptions = [
  {
    name: "Locations",
    filters: [
      { name: "xyz", label: "xyz" },
      { name: "abc", label: "ABC" },
    ],
  },
  {
    name: "Positions",
    filters: [
      { name: "generalmanager", label: "General Manager" },
      { name: "seniorexecutive", label: "Senior Executive" },
    ],
  },
  {
    name: "Groups",
    filters: [
      { name: "hr", label: "HR" },
      { name: "it", label: "IT" },
    ],
  },
  {
    name: "Employees",
    filters: [{ name: "Vinoth S", label: "Vinoth S" }],
  },
  {
    name: "Tags",
    filters: [
      { name: "test", label: "Test" },
      { name: "notag", label: "No Tags" },
    ],
  },
  {
    name: "Status",
    filters: [
      { name: "none", label: "None" },
      { name: "pending", label: "Pending" },
      { name: "approved", label: "Approved" },
    ],
  },
];

const Timesheet = () => {
  const theme = useTheme();
  const [tabsValue, setTabsValue] = useState(0);
  const [showTimeSheet, setShowTimeSheet] = useState(false);

  const handleChange = (event, newValue) => {
    setTabsValue(newValue);
  };

  const handleOpenTimeSheet = () => {
    setShowTimeSheet(true);
  };

  const handleCloseTimeSheet = () => {
    setShowTimeSheet(false);
  };

  const handleChangeIndex = (index) => {
    setTabsValue(index);
  };

  const deleteTimesheet = (id) => {
    return;
  };

  const editTimesheet = (id) => {
    return;
  };

  const viewHistory = (id) => {
    return;
  };

  const approveTimesheet = (id) => {
    return;
  };

  const TimesheetColumns = [
    { field: "date", headerName: "Date", flex: 1 },
    { field: "employeeID", headerName: "Employee ID", flex: 1 },
    { field: "employeeName", headerName: "Employee Name", flex: 1 },
    {
      field: "position",
      headerName: "Position",
      flex: 1,
    },
    { field: "location", headerName: "Location", flex: 1 },
    { field: "groups", headerName: "Groups", flex: 1 },
    { field: "tags", headerName: "Tags", flex: 1 },
    { field: "shiftStart", headerName: "Shift Start", flex: 1 },
    { field: "shiftEnd", headerName: "Shift End", flex: 1 },
    { field: "clockedIn", headerName: "Clocked In", flex: 1 },
    { field: "clockedOut", headerName: "Clocked Out", flex: 1 },
    { field: "break", headerName: "Break", flex: 1 },
    { field: "actual", headerName: "Actual", flex: 1 },
    // { field: "scheduled", headerName: "Scheduled", flex: 1 },
    // { field: "difference", headerName: "Difference", flex: 1 },

    {
      field: "actions",
      type: "actions",
      width: 80,
      getActions: (params) => [
        <GridActionsCellItem
          icon={<Edit />}
          label="Edit"
          onClick={editTimesheet(params.id)}
        />,
        <GridActionsCellItem
          icon={<Delete />}
          label="Delete"
          onClick={deleteTimesheet(params.id)}
          showInMenu
        />,
        <GridActionsCellItem
          icon={<History />}
          label="View History"
          onClick={viewHistory(params.id)}
          showInMenu
        />,
        <GridActionsCellItem
          icon={<Check />}
          label="Approve"
          onClick={approveTimesheet(params.id)}
          showInMenu
        />,
      ],
    },
  ];

  const TimesheetData = [
    {
      id: Math.random().toString(),
      date: "04-11-2021",
      employeeName: "Vinoth",
      employeeID: "29083",
      position: "Executive",
      location: "ABC",
      groups: "HR",
      tags: "",
      shiftStart: "9.00 am",
      shiftEnd: "06:30 pm",
      clockedIn: "09:00 am",
      clockedOut: "06:30 pm",
      break: "30 mins",
      actual: "9:00",
      status: "Pending",
      actions: "",
    },
    {
      id: Math.random().toString(),
      date: "05-11-2021",
      employeeName: "Rakesh",
      employeeID: "31855",
      position: "Senior Executive",
      location: "XYZ",
      groups: "HR",
      tags: "",
      shiftStart: "9.00 am",
      shiftEnd: "06:30 pm",
      clockedIn: "09:00 am",
      clockedOut: "06:30 pm",
      break: "30 mins",
      actual: "9:00",
      status: "Pending",
      actions: "",
    },
  ];

  return (
    <Box sx={{ flexGrow: 1 }}>
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "flex-start",
        }}
        component={Paper}
      >
        <Box>
          <Tabs
            value={tabsValue}
            onChange={handleChange}
            indicatorColor="secondary"
            textColor="secondary"
            sx={{
              backgroundColor: "white",
            }}
          >
            <Tab label="Time Sheets" />
          </Tabs>
        </Box>
        <Box sx={{ marginLeft: "auto" }}>
          <Stack spacing={2} direction="row">
            <Box>
              <Stack
                spacing={2}
                direction="row"
                sx={{ border: "dashed 1px gainsboro", mt: "2px" }}
              >
                <Tooltip title="Export">
                  <IconButton>
                    <IosShare />
                  </IconButton>
                </Tooltip>
                <Tooltip title="Print">
                  <IconButton>
                    <Print />
                  </IconButton>
                </Tooltip>
                <Tooltip title="Settings">
                  <IconButton>
                    <Settings />
                  </IconButton>
                </Tooltip>
              </Stack>
            </Box>
            <Button
              variant="contained"
              color="secondary"
              onClick={handleOpenTimeSheet}
            >
              Create Timesheet
            </Button>
          </Stack>
        </Box>
      </Box>

      <Box
        sx={{
          borderRadius: "5px",
          padding: "10px",
          mt: "2px",
          backgroundColor: "white",
        }}
      >
        <ReportHeader groupBy={groupByOptions} filters={filterOptions} />
      </Box>

      <SwipeableViews
        axis={theme.direction === "rtl" ? "x-reverse" : "x"}
        index={tabsValue}
        onChangeIndex={handleChangeIndex}
      >
        <TabPanel value={tabsValue} index={0} dir={theme.direction}>
          {/* <CollapsibleTable columns={Columns} rows={rowData} /> */}
          <CustomDataTable
            title="Employees"
            columns={TimesheetColumns}
            rows={TimesheetData}
            elevation={6}
          />
        </TabPanel>
      </SwipeableViews>

      {showTimeSheet && (
        <AddTimeSheet
          open={showTimeSheet}
          closeHandler={handleCloseTimeSheet}
        />
      )}
    </Box>
  );
};

export default Timesheet;
