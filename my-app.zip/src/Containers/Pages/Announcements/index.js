import React, { useState } from "react";
import CustomDataTable from "../../../Components/CustomDataTable";
import SubHeader from "../../../Components/SubHeader";

import { Delete, Visibility } from "@mui/icons-material";
import { GridActionsCellItem } from "@mui/x-data-grid";
import { Grid, TextField, Box } from "@mui/material";
import CustomAutoComplete from "../../../Components/CustomAutoComplete";

const AnnouncementsList = (props) => {
  const [recipients, setRecipients] = useState([
    { label: "EveryOne" },
    { label: "Ramesh" },
  ]);

  const viewAnnouncements = (id) => {
    return;
  };

  const deleteAnnouncements = (id) => {
    return;
  };

  const AnnouncementColumns = [
    { field: "announcement", headerName: "Announcement", flex: 1 },
    { field: "created", headerName: "Created", flex: 1 },
    { field: "read", headerName: "Read", flex: 1 },
    {
      field: "actions",
      type: "actions",
      width: 80,
      getActions: (params) => [
        <GridActionsCellItem
          icon={<Visibility />}
          label="Edit"
          onClick={viewAnnouncements(params.id)}
        />,
        <GridActionsCellItem
          icon={<Delete />}
          label="Delete"
          onClick={deleteAnnouncements(params.id)}
          showInMenu
        />,
      ],
    },
  ];

  const AnnouncementData = [
    {
      id: Math.random().toString(),
      announcement: "New leave procedures effect from Oct 1, 2021!. Check out",
      created: "September 30, 2021 14:50.",
      read: "12 / 25",
    },
    {
      id: Math.random().toString(),
      announcement: "List of holidays for Oct will be circulated shortly.",
      created: "September 30, 2021 14:55.",
      read: "27 / 150",
    },
  ];

  const DialogContent = () => {
    return (
      <Box component="form" noValidate sx={{ mt: 3 }}>
        <Grid container spacing={2}>
          <Grid item xs={12}>
            <CustomAutoComplete
              id="recipients"
              options={recipients}
              inputLabel="Recipients"
              autofocus
            />
          </Grid>

          <Grid item xs={12}>
            <TextField
              autoComplete="announcement"
              name="announcement"
              required
              fullWidth
              id="announcement"
              label="Announcement"
              multiline
              rows={5}
            />
          </Grid>
        </Grid>
      </Box>
    );
  };

  return (
    <>
      <SubHeader
        heading={"1 Announcement"}
        buttonText="Announcement"
        ButtonType="dialog"
        dialogContent={<DialogContent />}
      />
       <br />
      <CustomDataTable
        title="Announcement"
        columns={AnnouncementColumns}
        rows={AnnouncementData}
        elevation={6}
      />
    </>
  );
};

export default AnnouncementsList;
