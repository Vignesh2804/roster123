import React from "react";
import CustomDataTable from "../../../Components/CustomDataTable";
import SubHeader from "../../../Components/SubHeader";

import { Delete, Edit, Mail, NoAccounts } from "@mui/icons-material";
import { GridActionsCellItem } from "@mui/x-data-grid";

const LocationsList = (props) => {
  const editLocations = (id) => {
    return;
  };

  const archiveLocations = (id) => {
    return;
  };

  const LocationColumns = [
    { field: "name", headerName: "Name", flex: 1 },
    { field: "address", headerName: "Address", flex: 1 },
    { field: "timezone", headerName: "Timezone", flex: 1 },

    { field: "noOfEmployees", headerName: "No of Employees", flex: 1 },

    {
      field: "actions",
      type: "actions",
      width: 80,
      getActions: (params) => [
        <GridActionsCellItem
          icon={<Edit />}
          label="Edit"
          onClick={editLocations(params.id)}
        />,
        <GridActionsCellItem
          icon={<Delete />}
          label="Delete"
          onClick={archiveLocations(params.id)}
          showInMenu
        />,
      ],
    },
  ];

  const LocationData = [
    {
      id: Math.random().toString(),
      name: "Chennai",
      noOfEmployees: 1,
      address: "147, Nethaji Road",
      timezone: "Asia/Kolkatta",
    },
    {
      id: Math.random().toString(),
      name: "Bangalore",
      noOfEmployees: 25,
      address: "32, Sipcot Industrial Complex",
      timezone: "Asia/Kolkatta",
    },
  ];

  return (
    <>
      <SubHeader
        heading={"2 Location"}
        buttonText="Location"
        navigateTo="/dashboard/addlocation"
        ButtonType="navigation"
      />
       <br />
      <CustomDataTable
        title="Locations"
        columns={LocationColumns}
        rows={LocationData}
        elevation={6}
        checkboxNeeded
      />
    </>
  );
};

export default LocationsList;
