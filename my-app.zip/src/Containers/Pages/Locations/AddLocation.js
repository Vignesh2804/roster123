import React, { useState } from "react";

import {
  Button,
  CssBaseline,
  TextField,
  Grid,
  Box,
  Container,
  FormLabel,
  Switch,
  Breadcrumbs,
  Link,
  IconButton,
  InputAdornment,
} from "@mui/material";
import { useHistory } from "react-router";
import CustomAutoComplete from "../../../Components/CustomAutoComplete";
import { ArrowBack } from "@material-ui/icons";
import { MoreVert } from "@mui/icons-material";
import CountrySelector from "../../../Components/CountrySelector";
import SelectTimezoneMaterialUi from "select-timezone-material-ui";
import AddPagesHeader from "../../../Components/AddPagesHeader";

const AddLocation = (props) => {
  const history = useHistory();
  const [timezone, setTimeZone] = useState({});

  const [employees, setEmployees] = useState([
    { label: "Vinoth" },
    { label: "Ramesh" },
  ]);

  const handleTimeZoneChange = (timezoneName, timezoneOffset) => {
    console.log(timezoneName);
    setTimeZone(timezoneName);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    console.log("data", data);
    history.push("/dashboard/locations");
  };

  const handleBackClick = (e) => {
    e.preventDefault();
    history.push("/dashboard/locations");
  };

  const RenderForm = () => {
    return (
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <Box component="form" noValidate onSubmit={handleSubmit} sx={{ mt: 3 }}>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <TextField
                autoComplete="locationname"
                name="locationname"
                required
                fullWidth
                id="locationname"
                label="Location Name"
                autoFocus
              />
            </Grid>

            <Grid item xs={12}>
              <TextField
                autoComplete="address"
                name="address"
                required
                fullWidth
                id="address"
                label="Address"
              />
            </Grid>

            <Grid item xs={12} sm={5}>
              <CountrySelector required />
            </Grid>
            <Grid item xs={12} sm={7}>
              <TextField
                required
                fullWidth
                id="phoneNumber"
                label="Phone Number"
                name="phoneNumber"
                autoComplete="phoneNumber"
                type="number"
              />
            </Grid>

            <Grid item xs={12}>
              <div style={{ textAlign: "left" }}>
                <SelectTimezoneMaterialUi
                  label="Timezone"
                  helperText="Please select a timezone from the list"
                  onChange={handleTimeZoneChange}
                  showTimezoneOffset={true}
                />
              </div>
            </Grid>

            <Grid item xs={12} sm={4}>
              <FormLabel component="p" sx={{ textAlign: "left" }}>
                Employees
              </FormLabel>
            </Grid>
            <Grid item xs={12} sm={8}>
              <CustomAutoComplete
                id="employees"
                options={employees}
                inputLabel=""
              />
            </Grid>

            <Grid item xs={12} sm={6}>
              <FormLabel component="p" sx={{ textAlign: "left" }}>
                External Id
              </FormLabel>
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                autoComplete="externalId"
                name="externalId"
                fullWidth
                id="externalId"
                helperText="External data used in reports"
              />
            </Grid>

            <Grid item xs={12} sm={6}>
              <FormLabel component="p" sx={{ textAlign: "left" }}>
                Hide from your schedule
              </FormLabel>
            </Grid>
            <Grid item xs={12} sm={6} sx={{ textAlign: "right" }}>
              <Switch defaultChecked />
            </Grid>

            <Grid item xs={12} sm={6}>
              <FormLabel component="p" sx={{ textAlign: "left" }}>
                Projected Sales
              </FormLabel>
            </Grid>
            <Grid item xs={12} sm={6} container spacing={1}>
              <Grid item xs={12} sm={12}>
                <TextField
                  autoComplete="monday"
                  name="monday"
                  fullWidth
                  id="monday"
                  label="Monday"
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">$</InputAdornment>
                    ),
                  }}
                  size="small"
                />
              </Grid>
              <Grid item xs={12} sm={12}>
                <TextField
                  autoComplete="tuesday"
                  name="tuesday"
                  fullWidth
                  id="tuesday"
                  label="Tuesday"
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">$</InputAdornment>
                    ),
                  }}
                  size="small"
                />
              </Grid>
              <Grid item xs={12} sm={12}>
                <TextField
                  autoComplete="wednesday"
                  name="wednesday"
                  fullWidth
                  id="wednesday"
                  label="Wednesday"
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">$</InputAdornment>
                    ),
                  }}
                  size="small"
                />
              </Grid>
              <Grid item xs={12} sm={12}>
                <TextField
                  autoComplete="thursday"
                  name="thursday"
                  fullWidth
                  id="thursday"
                  label="Thursday"
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">$</InputAdornment>
                    ),
                  }}
                  size="small"
                />
              </Grid>
              <Grid item xs={12} sm={12}>
                <TextField
                  autoComplete="friday"
                  name="friday"
                  fullWidth
                  id="friday"
                  label="Friday"
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">$</InputAdornment>
                    ),
                  }}
                  size="small"
                />
              </Grid>
              <Grid item xs={12} sm={12}>
                <TextField
                  autoComplete="saturday"
                  name="saturday"
                  fullWidth
                  id="saturday"
                  label="Saturday"
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">$</InputAdornment>
                    ),
                  }}
                  size="small"
                />
              </Grid>
              <Grid item xs={12} sm={12}>
                <TextField
                  autoComplete="sunday"
                  name="sunday"
                  fullWidth
                  id="sunday"
                  label="Sunday"
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">$</InputAdornment>
                    ),
                  }}
                  size="small"
                />
              </Grid>
              <Grid item xs={12} sm={12}>
                <TextField
                  autoComplete="total"
                  name="total"
                  fullWidth
                  id="total"
                  label="Total"
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">$</InputAdornment>
                    ),
                  }}
                  size="small"
                />
              </Grid>
            </Grid>

            <Grid item xs={12} sm={6}>
              <FormLabel component="p" sx={{ textAlign: "left" }}>
                Maximum Labor Budget per week
              </FormLabel>
            </Grid>
            <Grid item xs={12} sm={6} container spacing={1}>
              <Grid item xs={12} sm={12}>
                <TextField
                  autoComplete="maxbudget"
                  name="maxbudget"
                  fullWidth
                  id="maxbudget"
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">$</InputAdornment>
                    ),
                  }}
                />
              </Grid>
            </Grid>

            <Grid item xs={12} sm={6}>
              <FormLabel component="p" sx={{ textAlign: "left" }}>
                Maximum Labor Hours per week
              </FormLabel>
            </Grid>
            <Grid item xs={12} sm={6} container spacing={1}>
              <Grid item xs={12} sm={12}>
                <TextField
                  autoComplete="maxbudget"
                  name="maxbudget"
                  fullWidth
                  id="maxbudget"
                  type="number"
                />
              </Grid>
            </Grid>

            <Grid item xs={12} sm={6}>
              <Button
                fullWidth
                variant="contained"
                sx={{ mt: 3, mb: 2, backgroundColor: "#616161" }}
                onClick={handleBackClick}
              >
                Cancel
              </Button>
            </Grid>

            <Grid item xs={12} sm={6}>
              <Button
                type="submit"
                fullWidth
                variant="contained"
                sx={{ mt: 3, mb: 2 }}
                color={"secondary"}
              >
                Save
              </Button>
            </Grid>
          </Grid>
        </Box>
      </Box>
    );
  };

  return (
    <Grid
      container
      sx={{ display: "flex", flexDirection: "column", alignItems: "center" }}
    >
      <Grid
        item
        xs={8}
        sx={{
          mt: "15px",
          width: "100%",
          backgroundColor: "#ffffff",
          borderRadius: "10px",
        }}
      >
        <AddPagesHeader
          firstLink="Location"
          secondLink="Add Location"
          navigateTo="/dashboard/locations"
        />
      </Grid>

      <Grid item xs={12}>
        <Container component="main" maxWidth="sm">
          <CssBaseline />
          <RenderForm />
        </Container>
      </Grid>
    </Grid>
  );
};

export default AddLocation;
