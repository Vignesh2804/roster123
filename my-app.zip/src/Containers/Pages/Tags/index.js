import React from "react";
import CustomDataTable from "../../../Components/CustomDataTable";
import SubHeader from "../../../Components/SubHeader";

import { Delete, Edit, Mail, NoAccounts } from "@mui/icons-material";
import { GridActionsCellItem } from "@mui/x-data-grid";

const TagsList = (props) => {
  const editTags = (id) => {
    return;
  };

  const deleteTags = (id) => {
    return;
  };

  const TagColumns = [
    { field: "name", headerName: "Name", flex: 1 },
    { field: "description", headerName: "Description", flex: 1 },

    {
      field: "actions",
      type: "actions",
      width: 80,
      getActions: (params) => [
        <GridActionsCellItem
          icon={<Edit />}
          label="Edit"
          onClick={editTags(params.id)}
        />,
        <GridActionsCellItem
          icon={<Delete />}
          label="Delete"
          onClick={deleteTags(params.id)}
          showInMenu
        />,
      ],
    },
  ];

  const TagData = [
    {
      id: Math.random().toString(),
      name: "GPC Shift 1",
      description: "Shift for GPC labour category 1",
    },
    {
      id: Math.random().toString(),
      name: "GPC Shift 2",
      description: "Shift for GPC labour category 2",
    },
  ];

  return (
    <>
      <SubHeader
        heading={"1 Tag"}
        buttonText="Tag"
        navigateTo="/dashboard/addtag"
        ButtonType="navigation"
      />
      <br />
      <CustomDataTable
        title="Tag"
        columns={TagColumns}
        rows={TagData}
        elevation={6}
        checkboxNeeded
      />
    </>
  );
};

export default TagsList;
