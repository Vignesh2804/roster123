import * as React from "react";

const Schedules = (props) => {
  return <p>Schedules</p>;
};

export default Schedules;
