import React, { useState } from "react";

import {
  Button,
  CssBaseline,
  TextField,
  Grid,
  Box,
  Container,
  FormLabel,
  Switch,
  IconButton,
} from "@mui/material";
import { useHistory } from "react-router";
import CustomAutoComplete from "../../../Components/CustomAutoComplete";
import { MoreVert } from "@mui/icons-material";

import { CirclePicker } from "react-color";
import AddPagesHeader from "../../../Components/AddPagesHeader";

const AddPosition = (props) => {
  const history = useHistory();

  const [employees, setEmployees] = useState([
    { label: "Vinoth" },
    { label: "Ramesh" },
  ]);

  const handleSubmit = (event) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    console.log("data", data);
    history.push("/dashboard/positions");
  };

  const handleBackClick = (e) => {
    e.preventDefault();
    history.push("/dashboard/positions");
  };

  const RenderForm = () => {
    return (
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <Box component="form" noValidate onSubmit={handleSubmit} sx={{ mt: 3 }}>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <TextField
                autoComplete="name"
                name="positionname"
                required
                fullWidth
                id="positionname"
                label="Position Name"
                autoFocus
              />
            </Grid>

            <Grid item xs={12} sm={4}>
              <FormLabel component="p" sx={{ textAlign: "left" }}>
                Employees
              </FormLabel>
            </Grid>
            <Grid item xs={12} sm={8}>
              <CustomAutoComplete
                id="employees"
                options={employees}
                inputLabel=""
              />
            </Grid>

            <Grid item xs={12} sm={4}>
              <FormLabel component="p" sx={{ textAlign: "left" }}>
                Choose Color
              </FormLabel>
            </Grid>
            <Grid item xs={12} sm={8} sx={{ textAlign: "center" }}>
              <CirclePicker width="400px" />
            </Grid>

            <Grid item xs={12} sm={4}>
              <FormLabel component="p" sx={{ textAlign: "left" }}>
                External Id
              </FormLabel>
            </Grid>
            <Grid item xs={12} sm={8}>
              <TextField
                autoComplete="externalId"
                name="externalId"
                fullWidth
                id="externalId"
                helperText="External data used in reports"
              />
            </Grid>

            <Grid item xs={12} sm={8}>
              <FormLabel component="p" sx={{ textAlign: "left" }}>
                Hide from your schedule
              </FormLabel>
            </Grid>
            <Grid item xs={12} sm={4} sx={{ textAlign: "right" }}>
              <Switch defaultChecked />
            </Grid>

            <Grid item xs={12} sm={4}>
              <FormLabel component="p" sx={{ textAlign: "left" }}>
                Wages
              </FormLabel>
            </Grid>
            <Grid item xs={12} sm={8} container spacing={1}>
              <Grid item xs={12} sm={3}>
                <TextField
                  autoComplete="basewage"
                  name="basewage"
                  fullWidth
                  id="basewage"
                />
              </Grid>
              <Grid item xs={12} sm={7}>
                <TextField
                  autoComplete="basewage"
                  name="basewage"
                  fullWidth
                  type="date"
                  id="basewage"
                />
              </Grid>
              <Grid item xs={12} sm={2}>
                <IconButton>
                  <MoreVert fontSize="large" />
                </IconButton>
              </Grid>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Button
                fullWidth
                variant="contained"
                sx={{ mt: 3, mb: 2, backgroundColor: "#616161" }}
                onClick={handleBackClick}
              >
                Cancel
              </Button>
            </Grid>

            <Grid item xs={12} sm={6}>
              <Button
                type="submit"
                fullWidth
                variant="contained"
                sx={{ mt: 3, mb: 2 }}
                color={"secondary"}
              >
                Save
              </Button>
            </Grid>
          </Grid>
        </Box>
      </Box>
    );
  };

  return (
    <Grid
      container
      sx={{ display: "flex", flexDirection: "column", alignItems: "center" }}
    >
      <Grid
        item
        xs={8}
        sx={{
          mt: "15px",
          width: "100%",
          backgroundColor: "#ffffff",
          borderRadius: "10px",
        }}
      >
        <AddPagesHeader
          firstLink="Positions"
          secondLink="Add Position"
          navigateTo="/dashboard/positions"
        />
      </Grid>

      <Grid item xs={12}>
        <Container component="main" maxWidth="sm">
          <CssBaseline />
          <RenderForm />
        </Container>
      </Grid>
    </Grid>
  );
};

export default AddPosition;
