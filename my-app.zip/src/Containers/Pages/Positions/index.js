import React from "react";
import CustomDataTable from "../../../Components/CustomDataTable";
import SubHeader from "../../../Components/SubHeader";

import { Delete, Edit, Mail, NoAccounts } from "@mui/icons-material";
import { GridActionsCellItem } from "@mui/x-data-grid";

const PositionsList = (props) => {
  const editPositions = (id) => {
    return;
  };

  const deletePositions = (id) => {
    return;
  };

  const PositionColumns = [
    { field: "name", headerName: "Name", flex: 1 },
    { field: "noOfEmployees", headerName: "No. of Employees", flex: 1 },
    {
      field: "actions",
      type: "actions",
      width: 80,
      getActions: (params) => [
        <GridActionsCellItem
          icon={<Edit />}
          label="Edit"
          onClick={editPositions(params.id)}
        />,
        <GridActionsCellItem
          icon={<Delete />}
          label="Delete"
          onClick={deletePositions(params.id)}
          showInMenu
        />,
      ],
    },
  ];

  const PositionData = [
    {
      id: Math.random().toString(),
      name: "General Manager",
      noOfEmployees: 1,
    },
    {
      id: Math.random().toString(),
      name: "Senior Executive",
      noOfEmployees: 25,
    },
  ];

  return (
    <>
      <SubHeader
        heading={"3 Positions"}
        buttonText="Position"
        navigateTo="/dashboard/addposition"
        ButtonType="navigation"
      />
       <br />
      <CustomDataTable
        title="Positions"
        columns={PositionColumns}
        rows={PositionData}
        elevation={6}
        checkboxNeeded
      />
    </>
  );
};

export default PositionsList;
