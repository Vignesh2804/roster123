import {
  FormLabel,
  Grid,
  Typography,
  Switch,
  TextField,
  InputAdornment,
  Divider,
} from "@mui/material";
import React, { useState } from "react";

const OvertimeSection = (props) => {
  const [weeklyOverTime, setWeeklyOverTime] = useState(false);
  const [weeklyOTAfter, setWeeklyOTAfter] = useState("");
  const [weeklyPayRate, setWeeklyPayRate] = useState(1.5);
  const [dailyOverTime, setDailyOverTime] = useState(false);
  const [dailyOTAfter, setDailyOTAfter] = useState("");
  const [dailyPayRate, setDailyPayRate] = useState(1.5);
  const [dailyDoubleTime, setDailyDoubleTime] = useState(false);

  const handleWeeklyOvertimeChange = (e) => {
    setWeeklyOverTime(e.target.checked);
  };

  const handleDailyOvertimeChange = (e) => {
    setDailyOverTime(e.target.checked);
  };

  const handleWeeklyOTAfterChange = (e) => {
    setWeeklyOTAfter(e.target.value);
  };

  const handledilyOTAfterChange = (e) => {
    setDailyOTAfter(e.target.value);
  };

  const handleWeeklyPayRateChange = (e) => {
    setWeeklyPayRate(e.target.value);
  };

  const handleDailyPayRateChange = (e) => {
    setDailyPayRate(e.target.value);
  };

  const handleDailyDoubleTimeChange = (e) => {
    setDailyDoubleTime(e.target.checked);
  };

  return (
    <Grid
      item
      id="overtime"
      xs={12}
      sx={{
        textAlign: "left",
      }}
      container
      spacing={2}
    >
      <Grid item xs={12}>
        <Typography variant="h6" gutterBottom component="div" color="secondary">
          Overtime
        </Typography>
        <Divider />
      </Grid>

      <Grid item xs={6}>
        <FormLabel>Weekly Overtime</FormLabel>
      </Grid>
      <Grid item xs={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleWeeklyOvertimeChange}
          checked={weeklyOverTime}
        />
      </Grid>

      {weeklyOverTime && (
        <>
          <Grid item xs={6}>
            <FormLabel>Overtime Starts after</FormLabel>
          </Grid>
          <Grid item xs={6} sx={{ textAlign: "left" }}>
            <>
              <TextField
                fullWidth
                id="afterOTHour"
                name="afterOTHour"
                type="number"
                value={weeklyOTAfter}
                onChange={handleWeeklyOTAfterChange}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">hours</InputAdornment>
                  ),
                }}
              />
            </>
          </Grid>

          <Grid item xs={6}>
            <FormLabel>Pay Rate x</FormLabel>
          </Grid>
          <Grid item xs={6} sx={{ textAlign: "left" }}>
            <TextField
              fullWidth
              type="number"
              id="weeklyPayRate"
              name="weeklyPayRate"
              value={weeklyPayRate}
              onChange={handleWeeklyPayRateChange}
            />
          </Grid>
        </>
      )}

      <Grid item xs={6}>
        <FormLabel>Daily Overtime</FormLabel>
      </Grid>
      <Grid item xs={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleDailyOvertimeChange}
          checked={dailyOverTime}
        />
      </Grid>

      {dailyOverTime && (
        <>
          <Grid item xs={6}>
            <FormLabel>Overtime Starts after</FormLabel>
          </Grid>
          <Grid item xs={6} sx={{ textAlign: "left" }}>
            <TextField
              fullWidth
              id="dailyOTafterHour"
              name="dailyOTafterHour"
              value={dailyOTAfter}
              onChange={handledilyOTAfterChange}
              type="number"
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">hours</InputAdornment>
                ),
              }}
            />
          </Grid>

          <Grid item xs={6}>
            <FormLabel>Pay Rate x</FormLabel>
          </Grid>
          <Grid item xs={6} sx={{ textAlign: "left" }}>
            <TextField
              fullWidth
              type="number"
              id="dailyPayRate"
              name="dailyPayRate"
              value={dailyPayRate}
              onChange={handleDailyPayRateChange}
            />
          </Grid>
        </>
      )}

      <Grid item xs={6}>
        <FormLabel>Daily Double Overtime (Pay Rate @ 2x)</FormLabel>
      </Grid>
      <Grid item xs={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleDailyDoubleTimeChange}
          checked={dailyDoubleTime}
        />
      </Grid>
    </Grid>
  );
};

export default OvertimeSection;
