import React from "react";
import SettingsLayout from "../../../Layouts/SettingsLayout";
import GeneralSection from "./GeneralSection";
import HolidayPaySection from "./HolidayPaySection";
import LaborCostAccessSection from "./LaborCostAccessSection";
import LaborPercentageSection from "./LaborPercentageSection";
import OvertimeSection from "./OverTimeSection";
import SpreadHoursSection from "./SpreadHoursSection";

const LaborCostSettings = (props) => {
  const anchors = [
    { label: "General", value: "general" },
    { label: "Overtime", value: "overtime" },
    { label: "Holiday Pay", value: "holidaypay" },
    { label: "Spread of Hours", value: "spreadhours" },
    { label: "Labor %", value: "labor" },
    { label: "Labor Cost Access", value: "laborcost" },
  ];

  const Contents = (props) => {
    return (
      <>
        <GeneralSection />
        <OvertimeSection />
        <HolidayPaySection />
        <SpreadHoursSection />
        <LaborPercentageSection />
        <LaborCostAccessSection />
      </>
    );
  };

  return <SettingsLayout anchors={anchors} contents={<Contents />} />;
};

export default LaborCostSettings;
