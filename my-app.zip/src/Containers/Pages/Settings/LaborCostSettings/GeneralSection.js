import {
  FormLabel,
  Grid,
  Typography,
  Switch,
  TextField,
  Divider,
} from "@mui/material";
import React, { useState } from "react";
import CurrencySelector from "../../../../Components/CurrencySelector";
import ScheduleIntervalSelector from "../../../../Components/ScheduleIntervalSelector";

const GeneralSection = () => {
  const [currency, setCurrency] = useState("USD");
  const [scheduleInterval, setSsheduleInterval] = useState("monthly");
  const [payrollStartDate, setPayrollStartDate] = useState("");
  const [employeeWagesView, setEmployeeWagesView] = useState(false);

  const handleCurrencyChange = (e) => {
    setCurrency(e.target.value);
  };

  const handleScheduleIntervalChange = (e) => {
    setSsheduleInterval(e.target.value);
  };

  const handlePayrollStartDateChange = (e) => {
    setPayrollStartDate(e.target.value);
  };

  const handleEmployeeWagesViewChange = (e) => {
    setEmployeeWagesView(e.target.checked);
  };

  return (
    <Grid
      item
      id="general"
      xs={12}
      sx={{
        textAlign: "left",
      }}
      container
      spacing={2}
    >
      <Grid item xs={12}>
        <Typography variant="h6" gutterBottom component="div" color="secondary">
          General
        </Typography>
        <Divider />
      </Grid>

      <Grid item xs={6}>
        <FormLabel>Currency</FormLabel>
      </Grid>
      <Grid item xs={6} sx={{ textAlign: "left" }}>
        <CurrencySelector
          id="currencySelector"
          value={currency}
          onChange={handleCurrencyChange}
          name="currencySelector"
          size="small"
        />
      </Grid>

      <Grid item xs={6}>
        <FormLabel>Payroll Period</FormLabel>
      </Grid>
      <Grid item xs={6} sx={{ textAlign: "left" }}>
        <ScheduleIntervalSelector
          id="scheduleInterval"
          value={scheduleInterval}
          onChange={handleScheduleIntervalChange}
          name="scheduleInterval"
          size="small"
        />
      </Grid>

      <Grid item xs={6}>
        <FormLabel>Start Date</FormLabel>
      </Grid>
      <Grid item xs={6} sx={{ textAlign: "left" }}>
        <TextField
          fullWidth
          type="date"
          id="payrollStartDate"
          value={payrollStartDate}
          onChange={handlePayrollStartDateChange}
          name="scheduleInterval"
          size="small"
        />
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>Let employees see their wages</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleEmployeeWagesViewChange}
          checked={employeeWagesView}
        />
      </Grid>
    </Grid>
  );
};

export default GeneralSection;
