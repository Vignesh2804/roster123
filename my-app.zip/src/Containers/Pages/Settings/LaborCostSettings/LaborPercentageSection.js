import {
  FormLabel,
  Grid,
  Typography,
  Switch,
  TextField,
  Divider,
  InputAdornment,
} from "@mui/material";
import React, { useState } from "react";

const LaborPercentageSection = (props) => {
  const [compare, setCompare] = useState(false);
  const [upperLimit, setUpperLimit] = useState(25);

  const handleComparisonChange = (e) => {
    setCompare(e.target.checked);
  };

  const handleUpperLimit = (e) => {
    setUpperLimit(e.target.value);
  };

  return (
    <Grid
      item
      id="labor"
      xs={12}
      sx={{
        textAlign: "left",
      }}
      container
      spacing={2}
    >
      <Grid item xs={12}>
        <Typography variant="h6" gutterBottom component="div" color="secondary">
          Labor %
        </Typography>
        <Divider />
      </Grid>

      <Grid item xs={6}>
        <FormLabel>Compare your labor spending against your sales</FormLabel>
      </Grid>
      <Grid item xs={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleComparisonChange}
          checked={compare}
        />
      </Grid>

      {compare && (
        <>
          <Grid item xs={6}>
            <FormLabel>Labor % goal upper limit</FormLabel>
          </Grid>
          <Grid item xs={6} sx={{ textAlign: "left" }}>
            <TextField
              fullWidth
              type="number"
              id="upperlimit"
              name="upperlimit"
              value={upperLimit}
              onChange={handleUpperLimit}
              InputProps={{
                endAdornment: <InputAdornment position="end">%</InputAdornment>,
              }}
            />
          </Grid>
        </>
      )}
    </Grid>
  );
};

export default LaborPercentageSection;
