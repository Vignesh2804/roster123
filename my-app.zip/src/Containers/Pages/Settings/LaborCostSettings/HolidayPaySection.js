import {
  FormLabel,
  Grid,
  Typography,
  Switch,
  TextField,
  Divider,
} from "@mui/material";
import React, { useState } from "react";

const HolidayPaySection = (props) => {
  const [higherRate, seteHigherRate] = useState(false);
  const [holidayPayRate, setHolidayPayRate] = useState(1.5);

  const handleHigherRateChange = (e) => {
    seteHigherRate(e.target.checked);
  };

  const handleholidayPayRateChange = (e) => {
    setHolidayPayRate(e.target.value);
  };

  return (
    <Grid
      item
      id="holidaypay"
      xs={12}
      sx={{
        textAlign: "left",
      }}
      container
      spacing={2}
    >
      <Grid item xs={12}>
        <Typography variant="h6" gutterBottom component="div" color="secondary">
          Holiday Pay
        </Typography>
        <Divider />
      </Grid>

      <Grid item xs={6}>
        <FormLabel>Set higher rate</FormLabel>
      </Grid>
      <Grid item xs={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleHigherRateChange}
          checked={higherRate}
        />
      </Grid>

      {higherRate && (
        <>
          <Grid item xs={6}>
            <FormLabel>Pay Rate x</FormLabel>
          </Grid>
          <Grid item xs={6} sx={{ textAlign: "left" }}>
            <TextField
              fullWidth
              type="number"
              id="holidayPayRate"
              name="holidayPayRate"
              value={holidayPayRate}
              onChange={handleholidayPayRateChange}
            />
          </Grid>
        </>
      )}
    </Grid>
  );
};

export default HolidayPaySection;
