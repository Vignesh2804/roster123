import {
  FormLabel,
  Grid,
  Typography,
  Switch,
  TextField,
  Divider,
  InputAdornment,
} from "@mui/material";
import React, { useState } from "react";

const SpreadHoursSection = (props) => {
  const [payHourExtra, setPayHourExtra] = useState(false);
  const [spreadAmount, setSpreadAmount] = useState(0);

  const handlePayHourExtraChange = (e) => {
    setPayHourExtra(e.target.checked);
  };

  const handleSpreadAmountChange = (e) => {
    setSpreadAmount(e.target.value);
  };

  return (
    <Grid
      item
      id="spreadhours"
      xs={12}
      sx={{
        textAlign: "left",
      }}
      container
      spacing={2}
    >
      <Grid item xs={12}>
        <Typography variant="h6" gutterBottom component="div" color="secondary">
          Spread of Hours
        </Typography>
        <Divider />
      </Grid>

      <Grid item xs={6}>
        <FormLabel>Pay an hour charge if work exceeds 10 hours</FormLabel>
      </Grid>
      <Grid item xs={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handlePayHourExtraChange}
          checked={payHourExtra}
        />
      </Grid>

      {payHourExtra && (
        <>
          <Grid item xs={6}>
            <FormLabel>Amount</FormLabel>
          </Grid>
          <Grid item xs={6} sx={{ textAlign: "left" }}>
            <TextField
              fullWidth
              type="number"
              id="spreadAmount"
              name="spreadAmount"
              value={spreadAmount}
              onChange={handleSpreadAmountChange}
              InputProps={{
                endAdornment: <InputAdornment position="end">$</InputAdornment>,
              }}
            />
          </Grid>
        </>
      )}
    </Grid>
  );
};

export default SpreadHoursSection;
