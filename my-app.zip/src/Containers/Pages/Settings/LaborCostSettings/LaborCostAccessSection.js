import {
  FormLabel,
  Grid,
  Typography,
  Switch,
  TextField,
  Divider,
  InputAdornment,
} from "@mui/material";
import React, { useState } from "react";
import CustomAutoComplete from "../../../../Components/CustomAutoComplete";

const LaborCostAccessSection = (props) => {
  const [managers, setManagers] = useState([
    { label: "Vinoth" },
    { label: "Ramesh" },
  ]);

  return (
    <Grid
      item
      id="laborcost"
      xs={12}
      sx={{
        textAlign: "left",
      }}
      container
      spacing={2}
    >
      <Grid item xs={12}>
        <Typography variant="h6" gutterBottom component="div" color="secondary">
          Labor Cost Access
        </Typography>
        <Divider />
      </Grid>

      <Grid item xs={6}>
        <FormLabel>Allow Access to</FormLabel>
      </Grid>
      <Grid item xs={6} sx={{ textAlign: "right" }}>
        <CustomAutoComplete
          id="managersList"
          options={managers}
          inputLabel=""
        />
      </Grid>
    </Grid>
  );
};

export default LaborCostAccessSection;
