import {
    FormLabel,
    Grid,
    Typography,
    Switch,
    Divider,
  } from "@mui/material";
  import React, { useState } from "react";

const FeedsEnabled = (props) => {
    const [allowCreatePages, setAllowCreatepages] = useState(true);

    const handleAllowCreatePages = (e) => {
        setAllowCreatepages(e.target.checked);
      };
    
  return (
    <>
      <Grid item xs={12} md={6}>
        <FormLabel>Allows employee to create page</FormLabel>
      </Grid>

      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleAllowCreatePages}
          checked={allowCreatePages}
        />
      </Grid>
    </>
  );
};

const CompanyFeedsSection = (props) => {

    const [feedsEnable, setFeedsEnable] = useState(true);

    
    const handleFeedsEnable = (e) => {
        setFeedsEnable(e.target.checked);
      };
    

  return (
    <Grid
      item
      id="feeds"
      xs={12}
      sx={{ textAlign: "left", mt: "15px" }}
      container
    >
      <Grid item xs={12}>
        <Typography variant="h6" gutterBottom component="div" color="secondary">
          Feeds
        </Typography>
        <Divider />
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>Enable</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch
          defaultChecked
          size="large"
          color="secondary"
          onChange={handleFeedsEnable}
          checked={feedsEnable}
        />
      </Grid>

      {feedsEnable && <FeedsEnabled />}
    </Grid>
  );
};

export default CompanyFeedsSection;
