import React, { useState } from "react";
import SettingsLayout from "../../../Layouts/SettingsLayout";
import CompanyFeedsSection from "./FeedsSection";
import CompanyMessagesSection from "./MessagesSection";
import RestrictionsSection from "./RestrictionsSection";
import CompanyTasksSection from "./TasksSection";

const CompanySettings = (props) => {
  const anchors = [
    { label: "Restrictions", value: "restrictions" },
    { label: "Messages", value: "messages" },
    { label: "Feeds", value: "feeds" },
    { label: "Tasks", value: "tasks" },
  ];

  const Contents = () => {
    return (
      <>
        <RestrictionsSection />
        <CompanyMessagesSection />
        <CompanyFeedsSection />
        <CompanyTasksSection />
      </>
    );
  };

  return <SettingsLayout anchors={anchors} contents={<Contents />} />;
};

export default CompanySettings;
