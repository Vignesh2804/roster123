import { FormLabel, Grid, Typography, Switch, Divider } from "@mui/material";
import React, { useState } from "react";

const RestrictionsSection = () => {
  const [allowContactView, setAllowContactView] = useState(true);

  const handleAllowContactView = (e) => {
    setAllowContactView(e.target.checked);
  };

  return (
    <Grid item id="restrictions" xs={12} sx={{ textAlign: "left" }} container>
      <Grid item xs={12}>
        <Typography variant="h6" gutterBottom component="div" color="secondary">
          Restrictions
        </Typography>
        <Divider />
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>Allow employees to see others contact</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleAllowContactView}
          checked={allowContactView}
        />
      </Grid>
    </Grid>
  );
};

export default RestrictionsSection;
