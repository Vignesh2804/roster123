import {
    FormLabel,
    Grid,
    Typography,
    Switch,
    Divider,
  } from "@mui/material";
  import React, { useState } from "react";

const CompanyTasksSection = (props) => {
    const [assignTasks, setAssignTasks] = useState(true);

    const handleTasksAssign = (e) => {
        setAssignTasks(e.target.checked);
      };
  return (
    <Grid
      item
      id="tasks"
      xs={12}
      sx={{ textAlign: "left", mt: "15px" }}
      container
    >
      <Grid item xs={12}>
        <Typography variant="h6" gutterBottom component="div" color="secondary">
          Tasks
        </Typography>
        <Divider />
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>Assign tasks to shifts?</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleTasksAssign}
          checked={assignTasks}
        />
      </Grid>
    </Grid>
  );
};

export default CompanyTasksSection;
