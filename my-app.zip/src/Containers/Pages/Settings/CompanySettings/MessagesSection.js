import {
    FormControl,
    FormLabel,
    Grid,
    MenuItem,
    Select,
    Typography,
    Switch,
    Divider,
  } from "@mui/material";
  import React, { useState } from "react";
  
const MessagesEnabled = (props) => {
    const [chatMode, setChatMode] = useState("both");

    const handleChatMode = (e) => {
        setChatMode(e.target.value);
      };
    
  return (
    <>
      <Grid item xs={12} md={6}>
        <FormLabel>Allow employees to chat in</FormLabel>
      </Grid>

      <Grid item xs={12} md={6} sx={{ textAlign: "left" }}>
        <FormControl fullWidth>
          <Select
            id="chatmode"
            value={chatMode}
            onChange={handleChatMode}
            name="chatmode"
            size="small"
          >
            <MenuItem value={"both"}>Both Group and Private Chat</MenuItem>
            <MenuItem value={"private"}>Only Private Chat</MenuItem>
          </Select>
        </FormControl>
      </Grid>
    </>
  );
};

const CompanyMessagesSection = (props) => {
    const [messagesEnable, setMessagesEnable] = useState(true);

    const handleMessagesEnable = (e) => {
        setMessagesEnable(e.target.checked);
      };

  return (
    <Grid
      item
      id="messages"
      xs={12}
      sx={{ textAlign: "left", mt: "15px" }}
      container
    >
      <Grid item xs={12}>
        <Typography variant="h6" gutterBottom component="div" color="secondary">
          Messages
        </Typography>
        <Divider />
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>Enable</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch
          defaultChecked
          size="large"
          color="secondary"
          onChange={handleMessagesEnable}
          checked={messagesEnable}
        />
      </Grid>

      {messagesEnable && <MessagesEnabled />}
    </Grid>
  );
};

export default CompanyMessagesSection;
