import {
  FormLabel,
  Grid,
  Typography,
  Switch,
  TextField,
  Divider,
} from "@mui/material";
import React, { useState } from "react";

const RequestSection = (props) => {
  const [allowRequest, setAllowRequest] = useState(true);
  const [managersApproval, setManagersApproval] = useState(true);
  const [advanceRequest, setAdvanceRequest] = useState(true);
  const [advanceDays, setAdvanceDays] = useState(1);
  const [comments, setComments] = useState(true);

  const handleAllowRequestChange = (e) => {
    setAllowRequest(e.target.checked);
  };

  const handleManagersApproval = (e) => {
    setManagersApproval(e.target.checked);
  };

  const handleAdvanceRequestChange = (e) => {
    setAdvanceRequest(e.target.checked);
  };

  const handleCommentsChange = (e) => {
    setComments(e.target.setComments);
  };

  const handleAdvanceDaysChange = (e) => {
    setAdvanceDays(e.target.value);
  };

  return (
    <Grid
      item
      id="requests"
      xs={12}
      sx={{ textAlign: "left" }}
      container
      spacing={2}
    >
      <Grid item xs={12}>
        <Typography variant="h6" gutterBottom component="div" color="secondary">
          Requests
        </Typography>
        <Divider />
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>Allow employees to request</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleAllowRequestChange}
          checked={allowRequest}
        />
      </Grid>

      {allowRequest && (
        <>
          <Grid item xs={12} md={6}>
            <FormLabel>Require Managers Approval</FormLabel>
          </Grid>
          <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
            <Switch
              size="large"
              color="secondary"
              onChange={handleManagersApproval}
              checked={managersApproval}
            />
          </Grid>

          <Grid item xs={12} md={6}>
            <FormLabel>Request in advance</FormLabel>
          </Grid>
          <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
            <Switch
              size="large"
              color="secondary"
              onChange={handleAdvanceRequestChange}
              checked={advanceRequest}
            />
          </Grid>

          {advanceRequest && (
            <>
              <Grid item xs={12} md={6}>
                <FormLabel>Number of days in advance</FormLabel>
              </Grid>
              <Grid item xs={12} md={3} sx={{ textAlign: "right" }}>
                <TextField
                  id="advanceDays"
                  name="advanceDays"
                  value={advanceDays}
                  onChange={handleAdvanceDaysChange}
                />
              </Grid>
            </>
          )}
        </>
      )}

      <Grid item xs={12} md={6}>
        <FormLabel>Require Comments</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleCommentsChange}
          checked={comments}
        />
      </Grid>
    </Grid>
  );
};

export default RequestSection;
