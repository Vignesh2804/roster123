import {
  FormLabel,
  Grid,
  Typography,
  Switch,
  TextField,
  Divider,
} from "@mui/material";
import React, { useState } from "react";

const PaidOffSection = (props) => {
  const [enablePaidoff, setPaidOff] = useState(false);

  const handleEnablePaidoffChange = (e) => {
    setPaidOff(e.target.checked);
  };

  return (
    <Grid
      item
      id="paidoff"
      xs={12}
      sx={{ textAlign: "left" }}
      container
      spacing={2}
    >
      <Grid item xs={12}>
        <Typography variant="h6" gutterBottom component="div" color="secondary">
          Paid Off
        </Typography>
        <Divider />
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>Enable</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleEnablePaidoffChange}
          checked={enablePaidoff}
        />
      </Grid>
    </Grid>
  );
};

export default PaidOffSection;
