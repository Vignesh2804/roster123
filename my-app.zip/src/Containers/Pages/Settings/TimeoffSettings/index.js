import React, { useState } from "react";

import SettingsLayout from "../../../Layouts/SettingsLayout";

import PaidOffSection from "./PaidOffSection";
import RequestSection from "./RequestSection";

const TimeOffSettings = (props) => {
  const anchors = [
    { label: "Requests", value: "requests" },
    { label: "Paid Off", value: "paidoff" },
  ];

  const Contents = () => {
    return (
      <>
        <RequestSection />
        <PaidOffSection />
      </>
    );
  };

  return <SettingsLayout anchors={anchors} contents={<Contents />} />;
};

export default TimeOffSettings;
