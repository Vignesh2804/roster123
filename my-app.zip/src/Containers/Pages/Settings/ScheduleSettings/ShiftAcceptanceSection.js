import {
  FormLabel,
  Grid,
  Typography,
  Switch,
  Divider,
  FormControl,
  Select,
  MenuItem,
} from "@mui/material";
import React, { useState } from "react";

const ShiftAcceptanceSection = () => {
  const [shiftAcceptance, setShiftAcceptance] = useState(true);

  const handleShiftAcceptance = (e) => {
    setShiftAcceptance(e.target.checked);
  };
  return (
    <Grid
      item
      id="shiftacceptance"
      xs={12}
      sx={{ textAlign: "left" }}
      container
      spacing={2}
    >
      <Grid item xs={12}>
        <Typography variant="h6" gutterBottom component="div" color="secondary">
          Shifts Acceptance
        </Typography>
        <Divider />
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>Let employees confirm their schedule.</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleShiftAcceptance}
          checked={shiftAcceptance}
        />
      </Grid>
    </Grid>
  );
};

export default ShiftAcceptanceSection;
