import { FormLabel, Grid, Typography, Switch, Divider } from "@mui/material";
import React, { useState } from "react";

const UnavailabilitySection = (props) => {
  const [unavailabilityEdit, setUnavailabilityEdit] = useState(false);
  const [managersApproval, setManagersApproval] = useState(false);

  const handleUnavailabilityEdit = (e) => {
    setUnavailabilityEdit(e.target.checked);
  };

  const handleManagersApprovalChange = (e) => {
    setManagersApproval(e.target.checked);
  };

  return (
    <Grid
      item
      id="unavilability"
      xs={12}
      sx={{ textAlign: "left" }}
      container
      spacing={2}
    >
      <Grid item xs={12}>
        <Typography variant="h6" gutterBottom component="div" color="secondary">
          Unavailability
        </Typography>
        <Divider />
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>Allow set/edit</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleUnavailabilityEdit}
          checked={unavailabilityEdit}
        />
      </Grid>

      {unavailabilityEdit && (
        <>
          <Grid item xs={12} md={6}>
            <FormLabel>Requires Managers Approval</FormLabel>
          </Grid>
          <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
            <Switch
              size="large"
              color="secondary"
              onChange={handleManagersApprovalChange}
              checked={managersApproval}
            />
          </Grid>
        </>
      )}
    </Grid>
  );
};

export default UnavailabilitySection;
