import {
  FormLabel,
  Grid,
  Typography,
  Switch,
  Divider,
  FormControl,
  Select,
  MenuItem,
} from "@mui/material";
import React, { useState } from "react";

const BreaksSection = (props) => {
  const [breakTime, setBreakTime] = useState(true);
  const [breakType, setBreakType] = useState("unpaid");
  const [breakDuration, setBreakDuration] = useState("30");

  const handleBreakTimeChange = (e) => {
    setBreakTime(e.target.checked);
  };

  const handleBreakTypeChange = (e) => {
    setBreakType(e.target.value);
  };

  const handleBreakDurationChange = (e) => {
    setBreakDuration(e.target.value);
  };

  return (
    <Grid
      item
      id="breaks"
      xs={12}
      sx={{ textAlign: "left" }}
      container
      spacing={2}
    >
      <Grid item xs={12}>
        <Typography variant="h6" gutterBottom component="div" color="secondary">
          Breaks
        </Typography>
        <Divider />
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>Enable break time</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleBreakTimeChange}
          checked={breakTime}
        />
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>Break Type</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "left" }}>
        <FormControl fullWidth>
          <Select
            id="breakType"
            value={breakType}
            onChange={handleBreakTypeChange}
            name="breakType"
            size="small"
          >
            <MenuItem value={"unpaid"}>Un Paid</MenuItem>
            <MenuItem value={"paid"}>Paid</MenuItem>
          </Select>
        </FormControl>
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>Break Duration</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "left" }}>
        <FormControl fullWidth>
          <Select
            id="breakDuration"
            value={breakDuration}
            onChange={handleBreakDurationChange}
            name="breakDuration"
            size="small"
          >
            <MenuItem value={"no"}>No Break</MenuItem>
            <MenuItem value={"10"}>10 Minutes</MenuItem>
            <MenuItem value={"20"}>20 Minutes</MenuItem>
            <MenuItem value={"30"}>30 Minutes</MenuItem>
            <MenuItem value={"40"}>40 Minutes</MenuItem>
            <MenuItem value={"50"}>50 Minutes</MenuItem>
            <MenuItem value={"60"}>60 Minutes</MenuItem>
          </Select>
        </FormControl>
      </Grid>
    </Grid>
  );
};

export default BreaksSection;
