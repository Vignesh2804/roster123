import {
    FormLabel,
    Grid,
    Typography,
    Switch,
    Divider,
  } from "@mui/material";
  import React, { useState } from "react";

 const ShiftExchangesSection = (props) => {
    const [giveAwayShifts, setGiveAwayShifts] = useState(true);
    const [swapShifts, setSwapShifts] = useState(false);
    const [restrictSwaps, setRestrictSwaps] = useState(true);
    const [autoApprove, setAutoApprove] = useState(false);

    const handleGiveAwayShifts = (e) => {
        setGiveAwayShifts(e.target.checked);
      };
    
      const handleRestrictSwapsChange = (e) => {
        setRestrictSwaps(e.target.checked);
      };
    
      const handleSwapShiftsChange = (e) => {
        setSwapShifts(e.target.checked);
      };
    
      const handleAutoApproveChange = (e) => {
        setAutoApprove(e.target.checked);
      };

    return (
      <Grid
        item
        id="shiftexchanges"
        xs={12}
        sx={{ textAlign: "left" }}
        container
        spacing={2}
      >
        <Grid item xs={12}>
          <Typography
            variant="h6"
            gutterBottom
            component="div"
            color="secondary"
          >
            Shift Exchanges
          </Typography>
          <Divider />
        </Grid>

        <Grid item xs={12} md={6}>
          <FormLabel>Let employees give away their shifts</FormLabel>
        </Grid>
        <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
          <Switch
            size="large"
            color="secondary"
            onChange={handleGiveAwayShifts}
            checked={giveAwayShifts}
          />
        </Grid>

        <Grid item xs={12} md={6}>
          <FormLabel>Let employees swap their shifts</FormLabel>
        </Grid>
        <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
          <Switch
            size="large"
            color="secondary"
            onChange={handleSwapShiftsChange}
            checked={swapShifts}
          />
        </Grid>

        <Grid item xs={12} md={6}>
          <FormLabel>
            Restrict offers and swaps by location and position
          </FormLabel>
        </Grid>
        <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
          <Switch
            size="large"
            color="secondary"
            onChange={handleRestrictSwapsChange}
            checked={restrictSwaps}
          />
        </Grid>

        <Grid item xs={12} md={6}>
          <FormLabel>Auto Approve</FormLabel>
        </Grid>
        <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
          <Switch
            size="large"
            color="secondary"
            onChange={handleAutoApproveChange}
            checked={autoApprove}
          />
        </Grid>
      </Grid>
    );
  };


  export default ShiftExchangesSection;