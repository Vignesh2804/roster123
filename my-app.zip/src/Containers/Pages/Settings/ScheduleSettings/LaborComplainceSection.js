import {
  FormLabel,
  Grid,
  Typography,
  Switch,
  TextField,
  InputAdornment,
  Divider,
} from "@mui/material";

import React, { useState } from "react";

const LaborComplainceSection = () => {
  const [restTime, setRestTime] = useState(false);
  const [restHours, setRestHours] = useState("");

  const handleRestTimeChange = (e) => {
    setRestTime(e.target.checked);
  };

  const handleRestHourChange = (e) => {
    setRestHours(e.target.value);
  };

  return (
    <Grid
      item
      id="labor"
      xs={12}
      sx={{ textAlign: "left" }}
      container
      spacing={2}
    >
      <Grid item xs={12}>
        <Typography variant="h6" gutterBottom component="div" color="secondary">
          Labor Complaince
        </Typography>
        <Divider />
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>Ensure adequate rest time between shifts</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleRestTimeChange}
          checked={restTime}
        />
      </Grid>

      {restTime && (
        <>
          <Grid item xs={12} md={6}>
            <FormLabel>Rest Hours</FormLabel>
          </Grid>
          <Grid item xs={12} md={6} sx={{ textAlign: "left" }}>
            <TextField
              fullWidth
              id="restHours"
              name="restHours"
              value={restHours}
              onChange={handleRestHourChange}
              type="number"
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">hours</InputAdornment>
                ),
              }}
            />
          </Grid>
        </>
      )}
    </Grid>
  );
};

export default LaborComplainceSection;
