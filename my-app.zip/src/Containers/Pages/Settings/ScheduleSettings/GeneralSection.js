import {
  FormControl,
  FormLabel,
  Grid,
  MenuItem,
  Select,
  Typography,
  Switch,
  Divider,
} from "@mui/material";
import React, { useState } from "react";

import DaysOfWeekSelector from "../../../../Components/DaysOfWeekSelector";
import TimeSelector from "../../../../Components/TimeSelector";

const OtherEmployeesScheduleView = (props) => {
  const [scheduleMode, setScheduleMode] = useState("all");
  const [otherEmployeesTimeoff, setOtherEmployeesTimeoff] = useState(true);

  const handleScheduleModeChange = (e) => {
    setScheduleMode(e.target.value);
  };

  const handleOtherEmployeeTimeoff = (e) => {
    setOtherEmployeesTimeoff(e.target.checked);
  };

  return (
    <>
      <Grid item xs={12} md={6}>
        <FormLabel>View Schedule for</FormLabel>
      </Grid>

      <Grid item xs={12} md={6} sx={{ textAlign: "left" }}>
        <FormControl fullWidth>
          <Select
            id="scheduleMode"
            value={scheduleMode}
            onChange={handleScheduleModeChange}
            name="scheduleMode"
            size="small"
          >
            <MenuItem value={"all"}>All positions</MenuItem>
            <MenuItem value={"position"}>Only for their position</MenuItem>
          </Select>
        </FormControl>
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>View other employees time off and unavailability.</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleOtherEmployeeTimeoff}
          checked={otherEmployeesTimeoff}
        />
      </Grid>
    </>
  );
};

const ScheduleGeneralSection = (props) => {
  const [firstDay, setFirstDay] = useState("monday");
  const [fromTime, setFromTime] = useState("10:00");
  const [toTime, setToTime] = useState("18:00");
  const [overnightCutoff, setOvernightCutoff] = useState(false);
  const [otherEmployeesScheduleView, setOtherEmployeesScheduleView] =
    useState(true);

  const [managersAccess, setManagersAccess] = useState(true);

  const handleFirstDayChange = (e) => {
    setFirstDay(e.target.value);
  };

  const handleFromTimeChange = (e) => {
    setFromTime(e.target.value);
  };

  const handleToTimeChange = (e) => {
    setToTime(e.target.value);
  };

  const handleOvernightCutoff = (e) => {
    setOvernightCutoff(e.target.checked);
  };

  const handleOtherEmployeesScheduleView = (e) => {
    setOtherEmployeesScheduleView(e.target.checked);
  };

  const handleManagersAccessChange = (e) => {
    setManagersAccess(e.target.checked);
  };

  return (
    <Grid
      item
      id="general"
      xs={12}
      sx={{ textAlign: "left" }}
      container
      spacing={2}
    >
      <Grid item xs={12}>
        <Typography variant="h6" gutterBottom component="div" color="secondary">
          General
        </Typography>
        <Divider />
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>First Day of week</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "left" }}>
        <DaysOfWeekSelector
          id="firstDay"
          value={firstDay}
          onChange={handleFirstDayChange}
          name="firstDay"
          size="small"
        ></DaysOfWeekSelector>
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>Operational Hours</FormLabel>
      </Grid>
      <Grid item xs={12} md={3} sx={{ textAlign: "left" }}>
        <TimeSelector
          id="fromTime"
          value={fromTime}
          onChange={handleFromTimeChange}
          name="fromTime"
          size="small"
        ></TimeSelector>
      </Grid>
      <Grid item xs={12} md={3} sx={{ textAlign: "left" }}>
        <TimeSelector
          id="toTime"
          value={toTime}
          onChange={handleToTimeChange}
          name="toTime"
          size="small"
        ></TimeSelector>
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>Overnight hours cutoff time</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleOvernightCutoff}
          checked={overnightCutoff}
        />
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>
          Allow employees to view other employees schedules.
        </FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleOtherEmployeesScheduleView}
          checked={otherEmployeesScheduleView}
        />
      </Grid>

      {otherEmployeesScheduleView && <OtherEmployeesScheduleView />}

      <Grid item xs={12} md={6}>
        <FormLabel>
          Allow managers to view other locations' schedules.
        </FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleManagersAccessChange}
          checked={managersAccess}
        />
      </Grid>
    </Grid>
  );
};

export default ScheduleGeneralSection;
