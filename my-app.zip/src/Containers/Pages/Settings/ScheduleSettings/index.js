import React, { useState } from "react";

import SettingsLayout from "../../../Layouts/SettingsLayout";
import BreaksSection from "./BreakSection";
import ScheduleGeneralSection from "./GeneralSection";
import LaborComplainceSection from "./LaborComplainceSection";
import ShiftAcceptanceSection from "./ShiftAcceptanceSection";
import ShiftExchangesSection from "./ShiftExchangesSection";
import UnavailabilitySection from "./UnavailabilitySection";

const ScheduleSettings = (props) => {
  const anchors = [
    { label: "General", value: "general" },
    { label: "Breaks", value: "breaks" },
    { label: "Shift acceptance", value: "shiftacceptance" },
    { label: "Shift exchanges", value: "shiftexchanges" },
    { label: "Unavailability", value: "unavilability" },
    { label: "Labor Complaince", value: "labor" },
  ];

  const Contents = () => {
    return (
      <>
        <ScheduleGeneralSection />
        <BreaksSection />
        <ShiftAcceptanceSection />
        <ShiftExchangesSection />
        <UnavailabilitySection />
        <LaborComplainceSection />
      </>
    );
  };

  return <SettingsLayout anchors={anchors} contents={<Contents />} />;
};

export default ScheduleSettings;
