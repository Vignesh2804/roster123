import { FormLabel, Grid, Typography, Switch, Divider } from "@mui/material";
import React, { useState } from "react";

const OtherSection = (props) => {
  const [enableSoundEffects, setEnableSoundEffects] = useState(true);
  const [showOthers, setShowOthers] = useState(true);
  const [googleCalendarSync, setGoogleCalendarSync] = useState(true);

  const handleEnableSoundEffectsChange = (e) => {
    setEnableSoundEffects(e.target.checked);
  };

  const handleShowOthersChange = (e) => {
    setShowOthers(e.target.checked);
  };

  const handleGoogleCalendarSyncChange = (e) => {
    setGoogleCalendarSync(e.target.checked);
  };

  return (
    <Grid
      item
      id="other"
      xs={12}
      sx={{ textAlign: "left" }}
      container
      spacing={2}
    >
      <Grid item xs={12}>
        <Typography variant="h6" gutterBottom component="div" color="secondary">
          Other Preference
        </Typography>
        <Divider />
      </Grid>
      <Grid item xs={12} md={6}>
        <FormLabel>Enable Sound Effects</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleEnableSoundEffectsChange}
          checked={enableSoundEffects}
        />
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>Show others when I am typing</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleShowOthersChange}
          checked={showOthers}
        />
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>Google Calendar Synchronization</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleGoogleCalendarSyncChange}
          checked={googleCalendarSync}
        />
      </Grid>
    </Grid>
  );
};

export default OtherSection;
