import React, { useState } from "react";
import SettingsLayout from "../../../Layouts/SettingsLayout";
import DisplaySection from "./DisplaySection";
import OtherSection from "./OtherSection";

const PreferencesSettings = (props) => {
  const anchors = [
    { label: "Display Preferences", value: "display" },
    { label: "Other Preferences", value: "other" },
  ];

  const Contents = () => {
    return (
      <>
        <DisplaySection />
        <OtherSection />
      </>
    );
  };

  return <SettingsLayout anchors={anchors} contents={<Contents />} />;
};

export default PreferencesSettings;
