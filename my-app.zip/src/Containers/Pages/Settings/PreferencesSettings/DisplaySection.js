import { SettingsBackupRestore } from "@material-ui/icons";
import {
  FormLabel,
  Grid,
  Typography,
  Switch,
  Stack,
  Box,
  IconButton,
  Divider,
} from "@mui/material";
import React, { useState } from "react";
import CustomToggleButton from "../../../../Components/CustomToggleButton";
import TimeFormat from "../../../../Components/TimeFormat";
import NameFormat from "../../../../Components/NameFormat";
import ShiftAppearance from "../../../../Components/ShiftAppearance";

const DisplaySection = (props) => {
  const [timeFormat, setTimeFormat] = useState("12");
  const [timeformatHelperText, setTimeformatHelperText] =
    useState("format: 02:30 PM");

  const [nameFormat, setNameFormat] = useState("fnf");
  const [nameFormatHelperText, setNameFormatHelperText] =
    useState("ex) Bob Smith");

  const [shiftAppearance, setShiftAppearance] = useState("day");

  const handleTimeFormatChange = (e) => {
    setTimeFormat(e.target.value);
    setTimeformatHelperText(
      e.target.value === "12" ? "format: 02:30 PM" : "format: 14:30"
    );
  };

  const handleNameFormatChange = (e) => {
    setNameFormat(e.target.value);
    setNameFormatHelperText(
      e.target.value === "fnf" ? "ex) Bob Smith" : "ex) Smith Bob"
    );
  };

  const handleShiftAppearance = (e, newvalue) => {
    setShiftAppearance(newvalue);
  };

  return (
    <Grid
      item
      id="display"
      xs={12}
      sx={{ textAlign: "left" }}
      container
      spacing={2}
    >
      <Grid item xs={12}>
        <Typography variant="h6" gutterBottom component="div" color="secondary">
          Display Preference
        </Typography>
        <Divider />
      </Grid>
      <Grid item xs={12} md={6}>
        <FormLabel>Time Format</FormLabel>
      </Grid>
      <Grid item xs={12} md={6}>
        <TimeFormat
          id="timeformatselect"
          value={timeFormat}
          onChange={handleTimeFormatChange}
          name="timeformat"
          helperText={timeformatHelperText}
        ></TimeFormat>
      </Grid>
      <Grid item xs={12} md={6}>
        <FormLabel>Name Format</FormLabel>
      </Grid>
      <Grid item xs={12} md={6}>
        <NameFormat
          labelId="nameformat"
          id="nameformatselect"
          value={nameFormat}
          label=""
          onChange={handleNameFormatChange}
          name="nameformat"
          helperText={nameFormatHelperText}
        ></NameFormat>
      </Grid>
      <Grid item xs={12} md={6}>
        <FormLabel>World clock</FormLabel>
        <br />
        <FormLabel>Enable employees local time zone?</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch defaultChecked size="large" color="secondary" />
      </Grid>
      <Grid item xs={12} container spacing={2}>
        <Grid item xs={12} md={6} sx={{ textAlign: "left" }}>
          <FormLabel>Shift Appearance</FormLabel>
          <br />
          <FormLabel></FormLabel>
          <br />
          <Stack sx={{ textAlign: "left", fontSize: "10px" }}>
            <p
              style={{
                backgroundColor: "white",
                width: "30px",
                border: "solid 1px gray",
                padding: "2px",
              }}
            >
              TIME
            </p>

            <p
              style={{
                backgroundColor: "white",
                width: "60px",
                border: "solid 1px gray",
                padding: "2px",
              }}
            >
              DURATION
            </p>

            <p
              style={{
                backgroundColor: "white",
                width: "50px",
                border: "solid 1px gray",
                padding: "2px",
              }}
            >
              ASIGNEE
            </p>

            <p
              style={{
                backgroundColor: "white",
                width: "55px",
                border: "solid 1px gray",
                padding: "2px",
              }}
            >
              POSITION
            </p>

            <p
              style={{
                backgroundColor: "white",
                width: "55px",
                border: "solid 1px gray",
                padding: "2px",
              }}
            >
              LOCATION
            </p>

            <p
              style={{
                backgroundColor: "white",
                width: "25px",
                border: "solid 1px gray",
                padding: "2px",
              }}
            >
              TAG
            </p>
          </Stack>
        </Grid>
        <Grid
          item
          xs={12}
          md={6}
          sx={{
            textAlign: "right",
          }}
        >
          <Box
            sx={{
              display: "flex",
              direction: "row",
              alignItems: "center",
              justifyContent: "end",
            }}
            component="div"
          >
            <CustomToggleButton
              value={shiftAppearance}
              exclusive
              onChange={handleShiftAppearance}
              aria-label="shift appearance"
              color="secondary"
              size="small"
              buttonList={[
                { label: "Day", value: "day" },
                { label: "Week", value: "week" },
                { label: "Month", value: "month" },
              ]}
            ></CustomToggleButton>

            <IconButton>
              <SettingsBackupRestore />
            </IconButton>
          </Box>
          <br />
          <ShiftAppearance view={shiftAppearance} />
        </Grid>
      </Grid>
    </Grid>
  );
};

export default DisplaySection;
