import {
  FormLabel,
  Grid,
  Typography,
  Switch,
  TextField,
  Divider,
} from "@mui/material";
import React, { useState } from "react";
import CustomToggleButton from "../../../../Components/CustomToggleButton";
import GpsDistanceUnit from "../../../../Components/GpsDistanceUnit";

const GeofencingSection = (props) => {
  const [ensureEmployeesLocation, setEnsureEmployeesLocation] = useState(false);
  const [geofencingFor, setGeofencingFor] = useState(() => [
    "clockin",
    "clockout",
  ]);
  const [enableGps, setEnableGPs] = useState(false);
  const [gpsDistance, setGpsDistance] = useState("100");
  const [gpsDistanceUnit, setGpsDistanceUnit] = useState("ft");
  const [clockInOutsideRadius, setClockInOutsideRadius] = useState(false);
  const [locationWifi, setLocationWifi] = useState(false);

  const [distanceHelperText, setDistanceHelperText] = useState(
    "Not more than 330 feet"
  );

  const handleEnsureEmployeesLocationChange = (e) => {
    setEnsureEmployeesLocation(e.target.checked);
    setGeofencingFor((prevValue) => {
      return prevValue.length == 0 ? ["clockin", "clockout"] : prevValue;
    });
  };

  const handleGeoFencingForChange = (e, newvalue) => {
    setGeofencingFor(newvalue);
    if (newvalue.length == 0) {
      setEnsureEmployeesLocation(false);
    }
  };

  const handleEnableGpsChange = (e) => {
    setEnableGPs(e.target.checked);
  };

  const handleGpsDistanceChange = (e) => {
    setGpsDistance(e.target.value);
  };

  const handleGpsDistanceUnitChange = (e) => {
    setGpsDistanceUnit(e.target.value);
    setDistanceHelperText(
      e.target.value === "ft"
        ? "Not more than 330 feet"
        : "Not more than 100 meters"
    );
  };

  const handleClockInOutsideRadius = (e) => {
    setClockInOutsideRadius(e.target.checked);
  };

  const handleLocationWifi = (e) => {
    setLocationWifi(e.target.checked);
  };

  return (
    <Grid
      item
      id="geofencing"
      xs={12}
      sx={{ textAlign: "left" }}
      container
      spacing={2}
    >
      <Grid item xs={12}>
        <Typography variant="h6" gutterBottom component="div" color="secondary">
          Geofencing
        </Typography>
        <Divider />
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>
          Ensure employees are in the right place when they are clocking in and
          out.
        </FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleEnsureEmployeesLocationChange}
          checked={ensureEmployeesLocation}
        />
      </Grid>

      {ensureEmployeesLocation && (
        <>
          <Grid item xs={12} md={6}>
            <FormLabel>Turn on geofencing for</FormLabel>
          </Grid>
          <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
            <CustomToggleButton
              value={geofencingFor}
              onChange={handleGeoFencingForChange}
              color="secondary"
              size="small"
              buttonList={[
                { label: "Clock In", value: "clockin" },
                { label: "Clock Out", value: "clockout" },
              ]}
            ></CustomToggleButton>
          </Grid>

          <Grid item xs={12} md={6}>
            <FormLabel>Enable GPS</FormLabel>
          </Grid>
          <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
            <Switch
              size="large"
              color="secondary"
              onChange={handleEnableGpsChange}
              checked={enableGps}
            />
          </Grid>

          {enableGps && (
            <>
              <Grid item xs={12} md={6}>
                <FormLabel>Clock In/Out distance</FormLabel>
              </Grid>
              <Grid item xs={12} md={3} sx={{ textAlign: "right" }}>
                <TextField
                  id="gpsDistance"
                  name="gpsDistance"
                  value={gpsDistance}
                  onChange={handleGpsDistanceChange}
                  helperText={distanceHelperText}
                />
              </Grid>
              <Grid item xs={12} md={3} sx={{ textAlign: "left" }}>
                <GpsDistanceUnit
                  id="gpsDistanceUnit"
                  name="gpsDistanceUnit"
                  value={gpsDistanceUnit}
                  onChange={handleGpsDistanceUnitChange}
                />
              </Grid>

              <Grid item xs={12} md={6}>
                <FormLabel>Allow clock in/out outside the radius</FormLabel>
              </Grid>
              <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
                <Switch
                  size="large"
                  color="secondary"
                  onChange={handleClockInOutsideRadius}
                  checked={clockInOutsideRadius}
                />
              </Grid>
            </>
          )}

          <Grid item xs={12} md={6}>
            <FormLabel>Connected to location Wi-Fi</FormLabel>
          </Grid>
          <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
            <Switch
              size="large"
              color="secondary"
              onChange={handleLocationWifi}
              checked={locationWifi}
            />
          </Grid>
        </>
      )}
    </Grid>
  );
};

export default GeofencingSection;
