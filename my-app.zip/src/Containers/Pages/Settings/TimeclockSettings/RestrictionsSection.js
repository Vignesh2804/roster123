import {
  FormLabel,
  Grid,
  Typography,
  Switch,
  TextField,
  Divider,
  InputAdornment,
} from "@mui/material";
import React, { useState } from "react";

const RestrictionsSection = () => {
  const [allowEarlyClockIn, setAllowEarlyClockIn] = useState(false);
  const [earlyClockInTime, setEarlyClockInTime] = useState("10");
  const [clockInWithoutShifts, setClockInWithoutShifts] = useState(false);

  const handleAllowEarlyClockInChange = (e) => {
    setAllowEarlyClockIn(e.target.checked);
  };

  const handleEarlyClockInTime = (e) => {
    setEarlyClockInTime(e.target.value);
  };

  const handleClockInWithoutShiftsChange = (e) => {
    setClockInWithoutShifts(e.target.checked);
  };

  return (
    <Grid
      item
      id="restrictions"
      xs={12}
      sx={{ textAlign: "left" }}
      container
      spacing={2}
    >
      <Grid item xs={12}>
        <Typography variant="h6" gutterBottom component="div" color="secondary">
          Restrictions
        </Typography>
        <Divider />
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>AllowEarlyClockIn</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleAllowEarlyClockInChange}
          checked={allowEarlyClockIn}
        />
      </Grid>

      {allowEarlyClockIn && (
        <>
          <Grid item xs={12} md={6}>
            <FormLabel>Early Clock In Time</FormLabel>
          </Grid>
          <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
            <TextField
              fullWidth
              id="earlyClockInTime"
              name="earlyClockInTime"
              value={earlyClockInTime}
              onChange={handleEarlyClockInTime}
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">minutes</InputAdornment>
                ),
              }}
            />
          </Grid>
        </>
      )}

      <Grid item xs={12} md={6}>
        <FormLabel>Allow clock-in without shifts</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleClockInWithoutShiftsChange}
          checked={clockInWithoutShifts}
        />
      </Grid>
    </Grid>
  );
};

export default RestrictionsSection;
