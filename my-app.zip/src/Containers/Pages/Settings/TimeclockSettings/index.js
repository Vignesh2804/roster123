import React, { useState } from "react";

import SettingsLayout from "../../../Layouts/SettingsLayout";

import AttendanceSection from "./AttendanceSection";
import TimeclockGeneralSection from "./GeneralSection";
import GeofencingSection from "./GeofencingSection";
import RestrictionsSection from "./RestrictionsSection";
import TimeSheetSection from "./TimesheetSection";

const TimeclockSettings = (props) => {
  const [allowApps, setAllowApps] = useState(true);
  const [generalGridHeight, setGeneralGridHeight] = useState("325px");

  const handleAllowAppsChange = async (value) => {
    setAllowApps(value);
    setGeneralGridHeight(value ? "325px" : "100px");
  };

  const anchors = [
    { label: "General", value: "general" },
    { label: "Attendance", value: "attendance" },
    { label: "Time Sheets", value: "timesheets" },
    { label: "Restrictions", value: "restrictions" },
    { label: "Geofencing", value: "geofencing" },
  ];

  const Contents = () => {
    return (
      <>
        <TimeclockGeneralSection
          allowApps={allowApps}
          handleAllowAppsChange={handleAllowAppsChange}
          GridHeight={generalGridHeight}
        />

        {allowApps && (
          <>
            <AttendanceSection />
            <TimeSheetSection />
            <RestrictionsSection />
            <GeofencingSection />
          </>
        )}
      </>
    );
  };

  return <SettingsLayout anchors={anchors} contents={<Contents />} />;
};

export default TimeclockSettings;
