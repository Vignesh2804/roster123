import { FormLabel, Grid, Typography, Switch, Divider } from "@mui/material";
import React, { useState } from "react";

const AttendanceSection = (props) => {
  const [trackLateArrival, setTrackLateArrival] = useState(false);

  const handleTrackLateArrivalChange = (e) => {
    setTrackLateArrival(e.target.checked);
  };

  return (
    <Grid item id="attendance" xs={12} container spacing={2}>
      <Grid item xs={12}>
        <Typography variant="h6" gutterBottom component="div" color="secondary">
          Attendance
        </Typography>
        <Divider />
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>Track Late Arrival</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleTrackLateArrivalChange}
          checked={trackLateArrival}
        />
      </Grid>
    </Grid>
  );
};

export default AttendanceSection;
