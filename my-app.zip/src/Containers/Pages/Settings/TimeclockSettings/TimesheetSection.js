import { FormLabel, Grid, Typography, Switch, Divider } from "@mui/material";
import React, { useState } from "react";

const TimeSheetSection = (props) => {
  const [timeSheetEdit, setTimeSheetEdit] = useState(false);

  const handleTimeSheetEditChange = (e) => {
    setTimeSheetEdit(e.target.checked);
  };

  return (
    <Grid
      item
      id="timesheets"
      xs={12}
      sx={{ textAlign: "left" }}
      container
      spacing={2}
    >
      <Grid item xs={12}>
        <Typography variant="h6" gutterBottom component="div" color="secondary">
          Time Sheets
        </Typography>
        <Divider />
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>Allow Timesheet edit</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleTimeSheetEditChange}
          checked={timeSheetEdit}
        />
      </Grid>
    </Grid>
  );
};

export default TimeSheetSection;
