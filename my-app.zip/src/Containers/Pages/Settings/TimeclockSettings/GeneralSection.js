import {
  FormLabel,
  Grid,
  Typography,
  Switch,
  TextField,
  InputAdornment,
  Divider,
} from "@mui/material";
import React, { useState } from "react";
import ClockRoundTimeSelector from "../../../../Components/ClockRoundTimeSelector";

const TimeclockGeneralSection = (props) => {
  const [kiosk, setKiosk] = useState(false);
  const [roundClockTime, setRoundClockTime] = useState("00");
  const [autoClockOut, setAutoClockOut] = useState(false);
  const [clockOutMinutes, setClockOutMinutes] = useState("10");

  const handleAllowAppsChange = (e) => {
    props.handleAllowAppsChange(e.target.checked);
  };

  const handleEnableKioskCange = (e) => {
    setKiosk(e.target.checked);
  };

  const handleRoundClockTimeChange = (e) => {
    setRoundClockTime(e.target.value);
  };

  const handleAutoClockOut = (e) => {
    setAutoClockOut(e.target.checked);
  };

  const handleClockOutMinutesChange = (e) => {
    setClockOutMinutes(e.target.value);
  };

  return (
    <Grid
      item
      id="general"
      xs={12}
      sx={{
        textAlign: "left",
        height: props.GridHeight,
        display: "flex",
        direction: "column",
        alignItems: "flex-start",
      }}
      container
      spacing={2}
    >
      <Grid item xs={12}>
        <Typography variant="h6" gutterBottom component="div" color="secondary">
          General
        </Typography>
        <Divider />
      </Grid>

      <Grid item xs={12} container>
        <Grid item xs={6}>
          <FormLabel>Allow mobile/web apps to clock in/out</FormLabel>
        </Grid>
        <Grid item xs={6} sx={{ textAlign: "right" }}>
          <Switch
            size="large"
            color="secondary"
            onChange={handleAllowAppsChange}
            checked={props.allowApps}
          />
        </Grid>

        <Grid item xs={12} md={6} sx={{ pt: "10px", pb: "10px" }}>
          <FormLabel>Enable Kiosks</FormLabel>
        </Grid>
        <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
          <Switch
            size="large"
            color="secondary"
            onChange={handleEnableKioskCange}
            checked={kiosk}
          />
        </Grid>
      </Grid>

      {props.allowApps && (
        <>
          <Grid item xs={12} md={6}>
            <FormLabel>Round clock timings</FormLabel>
          </Grid>
          <Grid item xs={12} md={6} sx={{ textAlign: "left" }}>
            <ClockRoundTimeSelector
              id="roundClockTimer"
              value={roundClockTime}
              onChange={handleRoundClockTimeChange}
              name="roundClockTimer"
              size="small"
            />
          </Grid>

          <Grid item xs={12} md={6}>
            <FormLabel>Enable Auto Clock Out</FormLabel>
          </Grid>
          <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
            <Switch
              size="large"
              color="secondary"
              onChange={handleAutoClockOut}
              checked={autoClockOut}
            />
          </Grid>

          {autoClockOut && (
            <>
              <Grid item xs={12} md={6}>
                <FormLabel>Auto Clock Out after</FormLabel>
              </Grid>
              <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
                <TextField
                  fullWidth
                  id="clockOutMinutes"
                  name="clockOutMinutes"
                  value={clockOutMinutes}
                  onChange={handleClockOutMinutesChange}
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">minutes</InputAdornment>
                    ),
                  }}
                />
              </Grid>
            </>
          )}
        </>
      )}
    </Grid>
  );
};

export default TimeclockGeneralSection;
