import React from "react";

import SettingsLayout from "../../../Layouts/SettingsLayout";
import DailyReportSection from "./DailyReportSection";
import DashboardSection from "./DashboardSection";
import FeedsSection from "./FeedsSection";
import MessagesSection from "./MessagesSection";

import ShiftAlarmsSection from "./ShiftAlarmsSection";
import TimeClockSection from "./TimeClockSection";

const NotificationsSettings = (props) => {
  const anchors = [
    { label: "Shift Alarms", value: "shift" },
    { label: "Dashboard", value: "dashboard" },
    { label: "Messages", value: "messages" },
    { label: "Feeds", value: "feeds" },
    { label: "Daily Report", value: "dailyreport" },
    { label: "Timeclock", value: "timeclock" },
  ];

  const Contents = () => {
    return (
      <>
        <ShiftAlarmsSection />
        <DashboardSection />
        <MessagesSection />
        <FeedsSection />
        <DailyReportSection />
        <TimeClockSection />
      </>
    );
  };

  return <SettingsLayout anchors={anchors} contents={<Contents />} />;
};

export default NotificationsSettings;
