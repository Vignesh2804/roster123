import { FormLabel, Grid, Typography, Switch, Divider } from "@mui/material";
import React, { useState } from "react";
import AlertsWhenSelector from "../../../../Components/AlertsWhenSelector";
import CustomToggleButton from "../../../../Components/CustomToggleButton";

const FeedsEnabled = () => {
  const [feedsNotificationType, setFeedsNotificationType] = useState(() => [
    "email",
  ]);

  const [sendFeedsAlertWhen, setSendFeedsAlertWhen] = useState("always");

  const handleFeedsNotificationType = (e, newvalues) => {
    setFeedsNotificationType(newvalues);
  };

  const handleSendFeedsAlertWhen = (e) => {
    setSendFeedsAlertWhen(e.target.value);
  };

  return (
    <>
      <Grid item xs={12} md={6}>
        <FormLabel>Send alerts when</FormLabel>
      </Grid>

      <Grid item xs={12} md={6} sx={{ textAlign: "left" }}>
        <AlertsWhenSelector
          id="feedsalertswhen"
          value={sendFeedsAlertWhen}
          onChange={handleSendFeedsAlertWhen}
          name="feedsalertswhen"
          size="small"
          itemsList={[
            { label: "Always", value: "always" },
            { label: "Only when Iam mentioned", value: "mentioned" },
          ]}
        ></AlertsWhenSelector>
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>Send notification via</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right", mt: "15px" }}>
        <CustomToggleButton
          value={feedsNotificationType}
          onChange={handleFeedsNotificationType}
          aria-label="Feeds Notification Type"
          color="secondary"
          size="small"
          buttonList={[
            { label: "Email", value: "email" },
            { label: "Mobile", value: "mobile" },
            { label: "Web", value: "web" },
          ]}
        ></CustomToggleButton>
      </Grid>
    </>
  );
};

const FeedsSection = () => {
  const [feedsEnable, setFeedsEnable] = useState(true);

  const handleFeedsEnable = (e) => {
    setFeedsEnable(e.target.checked);
  };

  return (
    <Grid
      item
      id="feeds"
      xs={12}
      sx={{ textAlign: "left", mt: "15px" }}
      container
      spacing={2}
    >
      <Grid item xs={12}>
        <Typography variant="h6" gutterBottom component="div" color="secondary">
          Feeds
        </Typography>
        <Divider />
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>Enable</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleFeedsEnable}
          checked={feedsEnable}
        />
      </Grid>

      {feedsEnable && <FeedsEnabled />}
    </Grid>
  );
};

export default FeedsSection;
