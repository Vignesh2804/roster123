import { FormLabel, Grid, Typography, Switch, Divider } from "@mui/material";
import React, { useState } from "react";
import AlertsWhenSelector from "../../../../Components/AlertsWhenSelector";
import LateTimeSelector from "../../../../Components/LateTimeSelector";

const ClockOutLate = () => {
  const [clockOutLateTime, setClockOutLateTime] = useState("30");

  const handleclockOutLateTime = (e) => {
    setClockOutLateTime(e.target.value);
  };

  return (
    <>
      <Grid item xs={12} md={6}>
        <FormLabel>Late in minutes</FormLabel>
      </Grid>

      <Grid item xs={12} md={6} sx={{ textAlign: "left", mt: "10px" }}>
        <LateTimeSelector
          id="clockoutlate"
          value={clockOutLateTime}
          onChange={handleclockOutLateTime}
          name="clockinlate"
          size="small"
        ></LateTimeSelector>
      </Grid>
    </>
  );
};

const ClockInLate = () => {
  const [clockInLateTime, setClockInLateTime] = useState("15");

  const handleclockInLateTime = (e) => {
    setClockInLateTime(e.target.value);
  };

  return (
    <>
      <Grid item xs={12} md={6}>
        <FormLabel>Late in minutes</FormLabel>
      </Grid>

      <Grid item xs={12} md={6} sx={{ textAlign: "left", mt: "10px" }}>
        <LateTimeSelector
          id="clockinlate"
          value={clockInLateTime}
          onChange={handleclockInLateTime}
          name="clockinlate"
          size="small"
        ></LateTimeSelector>
      </Grid>
    </>
  );
};

const TimeClockSection = () => {
  const [clockInAlertWhen, setClockInAlertWhen] = useState("late/forget");

  const [clockOutAlertWhen, setClockOutAlertWhen] = useState("late/forget");

  const handleClockInAlertWhen = (e) => {
    setClockInAlertWhen(e.target.value);
  };

  const handleClockOutAlertWhen = (e) => {
    setClockOutAlertWhen(e.target.value);
  };

  return (
    <Grid
      item
      id="timeclock"
      xs={12}
      sx={{ textAlign: "left", mt: "15px" }}
      container
      spacing={2}
    >
      <Grid item xs={12}>
        <Typography variant="h6" gutterBottom component="div" color="secondary">
          Timeclock
        </Typography>
        <Divider />
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>Send clockin alerts when</FormLabel>
      </Grid>

      <Grid item xs={12} md={6} sx={{ textAlign: "left" }}>
        <AlertsWhenSelector
          id="clockinalertwhen"
          value={clockInAlertWhen}
          onChange={handleClockInAlertWhen}
          name="clockinalertwhen"
          size="small"
          itemsList={[
            { label: "Always", value: "always" },
            { label: "Late or Forget", value: "late/forget" },
            { label: "Never", value: "never" },
          ]}
        ></AlertsWhenSelector>
      </Grid>

      {clockInAlertWhen !== "never" && <ClockInLate />}

      <Grid item xs={12} md={6}>
        <FormLabel>Send clockout alerts when</FormLabel>
      </Grid>

      <Grid item xs={12} md={6} sx={{ textAlign: "left", mt: "10px" }}>
        <AlertsWhenSelector
          id="clockoutalertwhen"
          value={clockOutAlertWhen}
          onChange={handleClockOutAlertWhen}
          name="clockoutalertwhen"
          size="small"
          itemsList={[
            { label: "Always", value: "always" },
            { label: "Late or Forget", value: "late/forget" },
            { label: "Never", value: "never" },
          ]}
        ></AlertsWhenSelector>
      </Grid>

      {clockOutAlertWhen !== "never" && <ClockOutLate />}
    </Grid>
  );
};

export default TimeClockSection;
