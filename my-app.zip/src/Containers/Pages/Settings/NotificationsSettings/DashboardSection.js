import { FormLabel, Grid, Typography, Switch, Divider } from "@mui/material";
import React, { useState } from "react";
import CustomToggleButton from "../../../../Components/CustomToggleButton";

const DashboardEnabled = (props) => {
  const [dashboardNotificationType, setDashboardNotificationType] = useState(
    () => ["email", "mobile"]
  );

  const handleDashboardNotificationType = (e, newvalues) => {
    setDashboardNotificationType(newvalues);
  };

  return (
    <>
      <Grid item xs={12} md={6}>
        <FormLabel>Send notification via</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right", mt: "15px" }}>
        <CustomToggleButton
          value={dashboardNotificationType}
          onChange={handleDashboardNotificationType}
          aria-label="Dashboard Notification Type"
          color="secondary"
          size="small"
          buttonList={[
            { label: "Email", value: "email" },
            { label: "Mobile", value: "mobile" },
          ]}
        ></CustomToggleButton>
      </Grid>
    </>
  );
};

const DashboardSection = (props) => {
  const [dashboardEnable, setDashboardEnable] = useState(true);

  const handleDashboardEnable = (e) => {
    setDashboardEnable(e.target.checked);
  };

  return (
    <Grid
      item
      id="dashboard"
      xs={12}
      sx={{ textAlign: "left", mt: "15px" }}
      container
      spacing={2}
    >
      <Grid item xs={12}>
        <Typography variant="h6" gutterBottom component="div" color="secondary">
          Dashboard
        </Typography>
        <Divider />
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>Enable</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleDashboardEnable}
          checked={dashboardEnable}
        />
      </Grid>

      {dashboardEnable && <DashboardEnabled />}
    </Grid>
  );
};

export default DashboardSection;
