import { FormLabel, Grid, Typography, Switch, Divider } from "@mui/material";
import React, { useState } from "react";
import AlertsWhenSelector from "../../../../Components/AlertsWhenSelector";
import CustomToggleButton from "../../../../Components/CustomToggleButton";

const MessagesEnabled = (props) => {
  const [messagesNotificationType, setMessagesNotificationType] = useState(
    () => ["email", "mobile"]
  );

  const [sendMessagesAlertWhen, setSendMessagesAlertWhen] = useState("always");

  const handleMessagesNotificationType = (e, newvalues) => {
    setMessagesNotificationType(newvalues);
  };

  const handleSendMessagesAlertWhen = (e) => {
    setSendMessagesAlertWhen(e.target.value);
  };

  return (
    <>
      <Grid item xs={12} md={6}>
        <FormLabel>Send alerts when</FormLabel>
      </Grid>

      <Grid item xs={12} md={6} sx={{ textAlign: "left" }}>
        <AlertsWhenSelector
          id="messagesalertswhen"
          value={sendMessagesAlertWhen}
          onChange={handleSendMessagesAlertWhen}
          name="messagesalertswhen"
          size="small"
          itemsList={[
            { label: "Always", value: "always" },
            { label: "Only when Iam mentioned", value: "mentioned" },
          ]}
        ></AlertsWhenSelector>
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>Send notification via</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right", mt: "15px" }}>
        <CustomToggleButton
          value={messagesNotificationType}
          onChange={handleMessagesNotificationType}
          aria-label="Messages Notification Type"
          color="secondary"
          size="small"
          buttonList={[
            { label: "Email", value: "email" },
            { label: "Mobile", value: "mobile" },
            { label: "Web", value: "web" },
          ]}
        ></CustomToggleButton>
      </Grid>
    </>
  );
};

const MessagesSection = (props) => {
  const [messagesEnable, setMessagesEnable] = useState(true);

  const handleMessagesEnable = (e) => {
    setMessagesEnable(e.target.checked);
  };

  return (
    <Grid
      item
      id="messages"
      xs={12}
      sx={{ textAlign: "left", mt: "15px" }}
      container
      spacing={2}
    >
      <Grid item xs={12}>
        <Typography variant="h6" gutterBottom component="div" color="secondary">
          Messages
        </Typography>
        <Divider />
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>Enable</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleMessagesEnable}
          checked={messagesEnable}
        />
      </Grid>

      {messagesEnable && <MessagesEnabled />}
    </Grid>
  );
};

export default MessagesSection;
