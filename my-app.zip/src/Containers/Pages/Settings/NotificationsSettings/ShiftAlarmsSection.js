import { FormLabel, Grid, Typography, Switch, Divider } from "@mui/material";
import React, { useState } from "react";
import CustomToggleButton from "../../../../Components/CustomToggleButton";
import TimeInterval from "../../../../Components/TimeInterval";

const ShiftAlarmEnabled = (props) => {
  const [shiftAlertBefore, setShiftAlertBefore] = useState("30");
  const [shiftAlertBeforeUnit, setShiftAlertBeforeUnit] = useState("m");
  const [shiftAlarmNotificationType, setShiftAlarmNotificationType] = useState(
    () => ["email", "mobile"]
  );

  const handleAlertBefore = (e) => {
    setShiftAlertBefore(e.target.value);
  };

  const handleAlertBeforeUnit = (e) => {
    setShiftAlertBeforeUnit(e.target.value);
  };

  const handleShiftAlarmNotificationType = (e, newvalues) => {
    setShiftAlarmNotificationType(newvalues);
  };

  return (
    <>
      <Grid item xs={12} md={6}>
        <FormLabel>Send Dashboard Notifications before</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "left" }}>
        <TimeInterval
          id="shiftAlertBefore"
          value={shiftAlertBefore}
          onChange={handleAlertBefore}
          name="shiftAlertBefore"
          size="small"
          unitId="shiftAlertBeforeUnit"
          unitValue={shiftAlertBeforeUnit}
          unitOnChange={handleAlertBeforeUnit}
          unitName="shiftAlertBeforeUnit"
          unitSize="small"
        ></TimeInterval>
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>Send notification via</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right", mt: "15px" }}>
        <CustomToggleButton
          value={shiftAlarmNotificationType}
          onChange={handleShiftAlarmNotificationType}
          aria-label="Shift Alarm Notification Type"
          color="secondary"
          size="small"
          buttonList={[
            { label: "SMS", value: "sms" },
            { label: "Email", value: "email" },
            { label: "Mobile", value: "mobile" },
          ]}
        ></CustomToggleButton>
      </Grid>
    </>
  );
};

const ShiftAlarmsSection = (props) => {
  const [shiftAlarmEnable, setShiftAlarmEnable] = useState(true);

  const handleShiftAlarmEnableChange = (e) => {
    setShiftAlarmEnable(e.target.checked);
  };

  return (
    <Grid
      item
      id="shift"
      xs={12}
      sx={{ textAlign: "left" }}
      container
      spacing={2}
    >
      <Grid item xs={12}>
        <Typography variant="h6" gutterBottom component="div" color="secondary">
          Shift Alarms
        </Typography>
        <Divider />
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>Enable</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleShiftAlarmEnableChange}
          checked={shiftAlarmEnable}
        />
      </Grid>

      {shiftAlarmEnable && <ShiftAlarmEnabled />}
    </Grid>
  );
};

export default ShiftAlarmsSection;
