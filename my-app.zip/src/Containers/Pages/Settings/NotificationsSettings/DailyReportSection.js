import { FormLabel, Grid, Typography, Switch, Divider } from "@mui/material";
import React, { useState } from "react";
import CustomToggleButton from "../../../../Components/CustomToggleButton";
import TimeSelector from "../../../../Components/TimeSelector";

const DailyReportEnabled = (props) => {
  const [dailyReportTime, setDailyReporttime] = useState("08:00");

  const [dailyReportNotificationType, setDailyReportNotificationType] =
    useState(() => ["email"]);

  const handleDailyReportTime = (e) => {
    setDailyReporttime(e.target.value);
  };

  const handleDailyReportNotificationType = (e, newvalues) => {
    setDailyReportNotificationType(newvalues);
  };

  return (
    <>
      <Grid item xs={12} md={6}>
        <FormLabel>Report deliver time</FormLabel>
      </Grid>

      <Grid item xs={12} md={6} sx={{ textAlign: "left" }}>
        <TimeSelector
          id="dailyreport"
          value={dailyReportTime}
          onChange={handleDailyReportTime}
          name="dailyreport"
          size="small"
        ></TimeSelector>
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>Send notification via</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right", mt: "15px" }}>
        <CustomToggleButton
          value={dailyReportNotificationType}
          onChange={handleDailyReportNotificationType}
          aria-label="Feeds Notification Type"
          color="secondary"
          size="small"
          buttonList={[
            { label: "Email", value: "email" },
            { label: "Mobile", value: "mobile" },
            { label: "Web", value: "web" },
          ]}
        ></CustomToggleButton>
      </Grid>
    </>
  );
};

const DailyReportSection = (props) => {
  const [dailyReportEnable, setDailyReportEnable] = useState(true);

  const handleDailyReportEnable = (e) => {
    setDailyReportEnable(e.target.checked);
  };

  return (
    <Grid
      item
      id="dailyreport"
      xs={12}
      sx={{ textAlign: "left", mt: "15px" }}
      container
      spacing={2}
    >
      <Grid item xs={12}>
        <Typography variant="h6" gutterBottom component="div" color="secondary">
          Daily Report
        </Typography>
        <Divider />
      </Grid>

      <Grid item xs={12} md={6}>
        <FormLabel>Send report daily</FormLabel>
      </Grid>
      <Grid item xs={12} md={6} sx={{ textAlign: "right" }}>
        <Switch
          size="large"
          color="secondary"
          onChange={handleDailyReportEnable}
          checked={dailyReportEnable}
        />
      </Grid>

      {dailyReportEnable && <DailyReportEnabled />}
    </Grid>
  );
};

export default DailyReportSection;
