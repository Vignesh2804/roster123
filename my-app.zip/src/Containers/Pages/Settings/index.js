import React from "react";
import SwipeableViews from "react-swipeable-views";
import TabPanel from "../../../Components/TabPanel";
import { useTheme } from "@mui/material/styles";
import { Tabs, Tab, Container } from "@mui/material";
import LaborCostSettings from "./LaborCostSettings";
import PreferencesSettings from "./PreferencesSettings";
import NotificationsSettings from "./NotificationsSettings";
import CompanySettings from "./CompanySettings";
import ScheduleSettings from "./ScheduleSettings";
import TimeclockSettings from "./TimeclockSettings";
import TimeOffSettings from "./TimeoffSettings";

const Settings = (props) => {
  const theme = useTheme();
  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const handleChangeIndex = (index) => {
    setValue(index);
  };

  return (
    <Container component="main" sx={{ mt: "15px", textAlign: "center" }}>
      <Tabs
        value={value}
        onChange={handleChange}
        indicatorColor="secondary"
        textColor="secondary"
        aria-label="wages category wise"
        sx={{
          backgroundColor: "white",
        }}
        centered
        variant="fullWidth"
      >
        <Tab label="Preferences" />
        <Tab label="Notifications" />
        <Tab label="Company" />
        <Tab label="Schedule" />
        <Tab label="Time Clock" />
        <Tab label="Labor Cost" />
        <Tab label="Time off" />
      </Tabs>

      <SwipeableViews
        axis={theme.direction === "rtl" ? "x-reverse" : "x"}
        index={value}
        onChangeIndex={handleChangeIndex}
      >
        <TabPanel value={value} index={0} dir={theme.direction}>
          <PreferencesSettings />
        </TabPanel>
        <TabPanel value={value} index={1} dir={theme.direction}>
          <NotificationsSettings />
        </TabPanel>
        <TabPanel value={value} index={2} dir={theme.direction}>
          <CompanySettings />
        </TabPanel>
        <TabPanel value={value} index={3} dir={theme.direction}>
          <ScheduleSettings />
        </TabPanel>
        <TabPanel value={value} index={4} dir={theme.direction}>
          <TimeclockSettings />
        </TabPanel>
        <TabPanel value={value} index={5} dir={theme.direction}>
          <LaborCostSettings />
        </TabPanel>
        <TabPanel value={value} index={6} dir={theme.direction}>
          <TimeOffSettings />
        </TabPanel>
      </SwipeableViews>
    </Container>
  );
};

export default Settings;
