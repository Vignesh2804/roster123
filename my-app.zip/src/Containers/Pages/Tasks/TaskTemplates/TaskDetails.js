import React, { useEffect, useState } from "react";

import {
  Close,
  ContentCopy,
  Delete,
  TaskAltOutlined,
} from "@mui/icons-material";
import {
  Grid,
  Button,
  Divider,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Box,
  Typography,
  Stack,
  Tooltip,
} from "@mui/material";

const TaskDetailsDialog = (props) => {
  const handleTaskEdit = (e) => {
    props.editHandler(props.task);
    props.closeHandler();
  };

  const handleTaskCopy = (e) => {
    props.copyHandler(props.task);
    props.closeHandler();
  };

  const handleTaskDelete = (e) => {
    props.deleteHandler(props.task);
    props.closeHandler();
  };

  return (
    <div>
      <Dialog open={props.open} onClose={props.handleClose}>
        <DialogTitle sx={{ display: "flex", alignItems: "center" }}>
          <TaskAltOutlined
            sx={{ width: "32px", height: "32px", paddingRight: "5px" }}
          />
          Template Details
          <Box sx={{ marginLeft: "auto" }}>
            <Stack direction="row" spacing={2}>
              <Tooltip title="Copy Template" key="copy">
                <ContentCopy
                  sx={{ cursor: "pointer" }}
                  onClick={handleTaskCopy}
                />
              </Tooltip>
              <Tooltip title="Delete Template" key="delete">
                <Delete sx={{ cursor: "pointer" }} onClick={handleTaskDelete} />
              </Tooltip>
              <Tooltip title="Close" key="close">
                <Close
                  sx={{ cursor: "pointer" }}
                  onClick={props.closeHandler}
                />
              </Tooltip>
            </Stack>
          </Box>
        </DialogTitle>
        <DialogContent>
          <DialogContentText>
            <Divider />
          </DialogContentText>
          <Box component="form" sx={{ mt: "10px" }}>
            <Grid container spacing={3}>
              <Grid item xs={3}>
                <Typography variant="body2">Title:</Typography>
              </Grid>
              <Grid item xs={9}>
                <Typography variant="body2">{props.task.title}</Typography>
              </Grid>

              <Grid item xs={3}>
                <Typography variant="body2">Description:</Typography>
              </Grid>
              <Grid item xs={9}>
                <Typography variant="body2">
                  {props.task.description}
                </Typography>
              </Grid>

              <Grid item xs={3}>
                <Typography variant="body2">Sub Tasks:</Typography>
              </Grid>
              <Grid item xs={9}>
                {props.task &&
                  props.task.subTask &&
                  props.task.subTask.length > 0 &&
                  props.task.subTask.map((subtask) => (
                    <Typography variant="body2">{subtask.value}</Typography>
                  ))}
              </Grid>
            </Grid>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={props.closeHandler}
            variant="contained"
            sx={{ backgroundColor: "#616161" }}
            size="small"
          >
            Close
          </Button>
          <Button
            onClick={handleTaskEdit}
            variant="contained"
            color={"secondary"}
            type="submit"
            size="small"
          >
            Edit Template
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default TaskDetailsDialog;
