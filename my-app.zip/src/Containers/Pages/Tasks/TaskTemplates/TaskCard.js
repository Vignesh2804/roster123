import TaskMenu from "./TasksMenu";
import styles from "../Tasks.module.css";
import { TaskAltOutlined } from "@mui/icons-material";
import { Grid, Typography, Box } from "@mui/material";
import React, { useState } from "react";

const TaskCard = (props) => {
  const handleTitleClick = () => {
    props.openDetailsHandler(props.task);
  };

  const handleEdit = () => {
    props.editHandler(props.task);
  };

  const handleCopy = () => {
    props.copyHandler(props.task);
  };

  const handleDelete = () => {
    props.deleteHandler(props.task);
  };

  return (
    <Grid
      container
      sx={{
        backgroundColor: "white",
        borderRadius: "5px",
        padding: "10px",
        mt: "1px",
      }}
    >
      <Grid
        item
        xs={10}
        sx={{
          textAlign: "left",
          paddingTop: "5px",
        }}
      >
        <Typography
          variant="body1"
          className={styles.title}
          onClick={handleTitleClick}
        >
          {props.task.title}{" "}
        </Typography>
      </Grid>
      <Grid
        item
        xs={2}
        sx={{
          display: "flex",
          alignItems: "top",
          justifyContent: "flex-end",
          paddingTop: "5px",
        }}
      >
        <Typography variant="body1">{props.task.subTask.length}</Typography>
        <TaskAltOutlined />
        <Box>
          {" "}
          <TaskMenu
            editHandler={handleEdit}
            copyHandler={handleCopy}
            deleteHandler={handleDelete}
          />
        </Box>
      </Grid>
    </Grid>
  );
};

export default TaskCard;
