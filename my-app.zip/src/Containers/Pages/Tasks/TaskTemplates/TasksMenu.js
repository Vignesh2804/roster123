import React, { useState } from "react";
import { Menu, Box, MenuItem } from "@mui/material";
import MoreVertIcon from "@mui/icons-material/MoreVert";

const options = ["Edit", "Copy", "Delete"];

const ITEM_HEIGHT = 48;

export default function TaskMenu(props) {
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = (e) => {
    if (e.target.textContent === "Edit") {
      props.editHandler();
    }
    if (e.target.textContent === "Copy") {
      props.copyHandler();
    }
    if (e.target.textContent === "Delete") {
      props.deleteHandler();
    }

    setAnchorEl(null);
  };

  return (
    <Box>
      <MoreVertIcon onClick={handleClick} sx={{ cursor: "pointer" }} />
      <Menu
        id="long-menu"
        MenuListProps={{
          "aria-labelledby": "long-button",
        }}
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        PaperProps={{
          style: {
            maxHeight: ITEM_HEIGHT * 4.5,
            width: "20ch",
          },
        }}
      >
        {options.map((option) => (
          <MenuItem
            key={option}
            selected={option === "Pyxis"}
            onClick={handleClose}
          >
            {option}
          </MenuItem>
        ))}
      </Menu>
    </Box>
  );
}
