import React from "react";
import TasksTabs from "./TasksTabs";

const Task = () => {
  return <TasksTabs />;
};

export default Task;
