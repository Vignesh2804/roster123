import React, { useState } from "react";
import CustomAccordion from "../../../../Components/CustomAccordion";
import ShiftTaskCard from "./ShiftTaskCard";
import { Box, Container } from "@mui/material";
import ShiftTaskDetails from "./ShiftTaskDetails";
import EditShiftTasks from "./EditShiftTasks";

const taskCategory = {
  assigned: "Assigned",
  available: "Available",
  unassigned: "Unassigned",
};

const taskCategoryColors = {
  assigned: "#f06292",
  available: "Green",
  unassigned: "#2196f3",
};

const ShiftTasks = (props) => {
  const [openTaskDetails, setOpenTaskDetails] = useState(false);
  const [openTaskEdit, setOpenTaskEdit] = useState(false);

  const [taskDetails, setTaskDetails] = useState(null);
  const [category, setCategory] = useState(null);
  const [editTask, setEditTask] = useState(null);

  const [shiftTasks, setShiftTasks] = useState({
    assigned: [
      {
        title: "Task 1",
        description: "Assigned Task 1",
        subTask: ["Sub Task 1", "Sub Task 2"],
        subTasksCompleted: [],
        shift: [
          {
            assignee: "Employee 1",
            timeSlot: "9:00 AM - 12:00 PM",
          },
        ],
        shiftDate: new Date(),
        position: "Senior Executive",
        location: "Location 1",
      },
      {
        title: "Task 2",
        description: "Assigned Task 2",
        subTask: ["Sub Task 1", "Sub Task 2"],
        subTasksCompleted: [],
        shift: [
          {
            assignee: "Employee 1",
            timeSlot: "9:00 AM - 12:00 PM",
          },
        ],
        shiftDate: new Date(),
        position: "Senior Executive",
        location: "Location 1",
      },
    ],
    available: [
      {
        title: "Task 3",
        description: "Available Task 1",
        subTask: ["Sub Task 1", "Sub Task 2"],
        subTasksCompleted: [],
        shift: [
          {
            assignee: "Employee 1",
            timeSlot: "9:00 AM - 12:00 PM",
          },
        ],
        shiftDate: new Date(),
        position: "Senior Executive",
        location: "Location 1",
      },
    ],
    unassigned: [
      {
        title: "Task 2",
        description: "Unassigned Task 1",
        subTask: ["Sub Task 1", "Sub Task 2"],
        subTasksCompleted: [],
        shift: [
          {
            assignee: "Employee 1",
            timeSlot: "9:00 AM - 12:00 PM",
          },
        ],
        shiftDate: new Date(),
        position: "Junior Executive",
        location: "Location 2",
      },
    ],
  });

  const updateCategory = (category) => {
    setCategory(category);
  };

  const updateShiftTask = (category, task) => {
    let allTasks = { ...shiftTasks };
    let tasks = allTasks[category];

    tasks.map((item) => {
      if (item.title === task.title) {
        return task;
      }
      return item;
    });

    setShiftTasks(allTasks);
  };

  const handleSubmitTasks = (category, task) => {
    updateShiftTask(category, task);
  };

  const handleEditDialogClose = () => {
    setOpenTaskEdit(false);
  };

  const handleOpenTaskDetails = (task) => {
    setOpenTaskDetails(true);
    setTaskDetails(task);
  };

  const handleCloseTaskDetails = () => {
    setOpenTaskDetails(false);
  };

  const handleEditTemplate = (task) => {
    setOpenTaskDetails(false);
    setEditTask(task);
    setOpenTaskEdit(true);
  };

  const handleDeleteTemplate = (category, task) => {
    setOpenTaskDetails(false);
    let tasks = { ...shiftTasks };
    let item = tasks[category].filter((stasks) => {
      return stasks.title !== task.title;
    });
    tasks[category] = item;
    setShiftTasks(tasks);
  };

  const handleTaskComplete = (task, mode, category) => {
    if (mode === "Complete") {
      task.subTasksCompleted = [...task.subTask];
    }

    if (mode === "Reopen") {
      task.subTasksCompleted = [];
    }

    updateShiftTask(category, task);

    handleCloseTaskDetails();
  };

  return (
    <Container>
      {shiftTasks &&
        Object.keys(shiftTasks).map((value, index) => {
          return (
            <CustomAccordion
              key={value}
              title={taskCategory[value]}
              color={taskCategoryColors[value]}
            >
              {shiftTasks[value].map((task) => (
                <Box key={task.title}>
                  <ShiftTaskCard
                    task={task}
                    borderColor={taskCategoryColors[value]}
                    openDetailsHandler={handleOpenTaskDetails}
                    category={value}
                    editHandler={handleEditTemplate}
                    deleteHandler={handleDeleteTemplate}
                    updateCategory={updateCategory}
                    completeHandler={handleTaskComplete}
                  />
                </Box>
              ))}
            </CustomAccordion>
          );
        })}
      {openTaskDetails && (
        <ShiftTaskDetails
          task={taskDetails}
          open={openTaskDetails}
          closeHandler={handleCloseTaskDetails}
          editHandler={handleEditTemplate}
          deleteHandler={handleDeleteTemplate}
          updateShiftTask={updateShiftTask}
          completeHandler={handleTaskComplete}
          category={category}
        />
      )}
      {openTaskEdit && (
        <EditShiftTasks
          open={openTaskEdit}
          handleClose={handleEditDialogClose}
          handleSubmitTasks={handleSubmitTasks}
          editTask={editTask}
          category={category}
        />
      )}
    </Container>
  );
};

export default ShiftTasks;
