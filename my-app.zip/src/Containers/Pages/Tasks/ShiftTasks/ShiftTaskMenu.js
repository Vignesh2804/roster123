import React, { useEffect, useState } from "react";
import { Menu, Box, MenuItem } from "@mui/material";
import MoreVertIcon from "@mui/icons-material/MoreVert";

const options = ["View", "Edit", "Delete"];

const ITEM_HEIGHT = 48;

export default function ShiftTaskMenu(props) {
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);

  useEffect(() => {
    if (props.mode) {
      if (props.mode === "Complete" && options.indexOf("Reopen") !== -1) {
        let index = options.indexOf("Reopen");
        options.splice(index, 1);
      }

      if (props.mode === "Reopen" && options.indexOf("Complete") !== -1) {
        let index = options.indexOf("Complete");
        options.splice(index, 1);
      }

      if (options.indexOf(props.mode) === -1) {
        options.push(props.mode);
      }
    }
  }, [props.mode]);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = (e) => {
    if (e.target.textContent === "Edit") {
      props.editHandler();
    }
    if (e.target.textContent === "Delete") {
      props.deleteHandler();
    }
    if (
      e.target.textContent === "Complete" ||
      e.target.textContent === "Reopen"
    ) {
      props.completeHandler();
    }
    if (e.target.textContent === "View") {
      props.openHandler();
    }
    setAnchorEl(null);
  };

  return (
    <Box>
      <MoreVertIcon onClick={handleClick} sx={{ cursor: "pointer" }} />
      <Menu
        id="long-menu"
        MenuListProps={{
          "aria-labelledby": "long-button",
        }}
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        PaperProps={{
          style: {
            maxHeight: ITEM_HEIGHT * 4.5,
            width: "20ch",
          },
        }}
      >
        {options.map((option) => (
          <MenuItem
            key={option}
            selected={option === "Pyxis"}
            onClick={handleClose}
          >
            {option}
          </MenuItem>
        ))}
      </Menu>
    </Box>
  );
}
