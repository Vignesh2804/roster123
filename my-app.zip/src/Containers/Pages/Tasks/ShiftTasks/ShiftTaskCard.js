import styles from "../Tasks.module.css";
import { TaskAltOutlined } from "@mui/icons-material";
import { Grid, Typography, Box, Stack } from "@mui/material";
import React, { useEffect, useState } from "react";
import ShiftTaskMenu from "./ShiftTaskMenu";
import moment from "moment";

const ShiftTaskCard = (props) => {
  const [mode, setMode] = useState("Complete");

  const handleTitleClick = () => {
    props.openDetailsHandler(props.task);
    props.updateCategory(props.category);
  };

  const handleEdit = () => {
    props.editHandler(props.task);
    props.updateCategory(props.category);
  };

  const handleDelete = () => {
    props.deleteHandler(props.category, props.task);
    props.updateCategory(props.category);
  };

  const handleComplete = () => {
    props.updateCategory(props.category);
    props.completeHandler(props.task, mode, props.category);
  };

  useEffect(() => {
    if (props.task) {
      if (props.task.subTask.length === props.task.subTasksCompleted.length) {
        setMode("Reopen");
      } else {
        setMode("Complete");
      }
    }
  }, [props.task, props.task.subTask, props.task.subTasksCompleted]);

  return (
    <Grid
      container
      sx={{
        borderRadius: "5px",
        padding: "10px",
        borderStyle: "Dashed",
        borderTopStyle: "solid",
        borderColor: props.borderColor,
        "&:hover": {
          backgroundColor: "#e0e0e0",
        },
      }}
    >
      <Grid
        item
        xs={10}
        sx={{
          textAlign: "left",
          paddingTop: "5px",
        }}
      >
        <Typography
          variant="body1"
          className={styles.title}
          onClick={handleTitleClick}
        >
          {props.task.title}{" "}
        </Typography>
        <Typography variant="caption" onClick={handleTitleClick}>
          {props.task.position}
          {" - "}
          {props.task.location}
        </Typography>
      </Grid>
      <Grid item xs={2} sx={{ display: "flex", justifyContent: "flex-end" }}>
        <Stack direction="row" spacing={1}>
          <Box>
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                justifyContent: "flex-end",
              }}
            >
              <Typography variant="body1">
                {props.task.subTasksCompleted.length +
                  " / " +
                  props.task.subTask.length}{" "}
              </Typography>
              <TaskAltOutlined />
            </Box>
            <Box>
              <Typography variant="caption" onClick={handleTitleClick}>
                {moment(props.task.shiftDate).format("MMM DD, YYYY")}
              </Typography>
            </Box>
          </Box>
          <Box sx={{ border: "solid 1px gainsboro", paddingTop: "12px" }}>
            <ShiftTaskMenu
              editHandler={handleEdit}
              deleteHandler={handleDelete}
              completeHandler={handleComplete}
              openHandler={handleTitleClick}
              mode={mode}
            />
          </Box>
        </Stack>
      </Grid>
    </Grid>
  );
};

export default ShiftTaskCard;
