import React, { useEffect, useState } from "react";

import {
  AddCircleOutlined,
  Close,
  RemoveCircle,
  RemoveCircleOutlined,
  TaskAltOutlined,
} from "@mui/icons-material";
import {
  Grid,
  Button,
  TextField,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Box,
  Divider,
} from "@mui/material";

const SubTask = (props) => {
  const handleRemoveSTasks = () => {
    props.handleRemoveSubtasks(props.id);
  };

  const handleSubTask = (e) => {
    props.handleSubTaskOnChange(props.id, e.target.value);
  };

  return (
    <Box sx={{ display: "flex", alignItems: "center" }}>
      <TextField
        autoFocus
        margin="dense"
        id={props.id}
        value={props.value}
        fullWidth
        variant="outlined"
        onChange={handleSubTask}
        size="small"
      />
      {props.index !== 0 && (
        <RemoveCircleOutlined
          onClick={handleRemoveSTasks}
          sx={{ cursor: "pointer" }}
        />
      )}
    </Box>
  );
};

const EditShiftTasks = (props) => {
  const [noOfSubTasks, setNoOfSubTasks] = useState([
    { id: "subTask1", value: "" },
  ]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");

  const handleSubTaskOnChange = (id, value) => {
    let newArr = [...noOfSubTasks];

    let item = newArr.filter((arr) => arr.id === id);
    item[0].value = value;

    setNoOfSubTasks(newArr);
  };

  const handleAddSubtasks = () => {
    let id =
      "subTask" +
      (+noOfSubTasks[noOfSubTasks.length - 1].id.match(/\d+/)[0] + 1);
    setNoOfSubTasks((oldArray) => [...oldArray, { id: id, value: "" }]);
  };

  const handleRemoveSubtasks = (id) => {
    setNoOfSubTasks((oldtask) => oldtask.filter((task) => task.id !== id));
  };

  const handleTitleChange = (e) => {
    setTitle(e.target.value);
  };

  const handleDescriptionChange = (e) => {
    setDescription(e.target.value);
  };

  const handleTaskSubmit = (e) => {
    props.editTask.description = description;
    props.editTask.subTask = noOfSubTasks.map((subtask) => subtask.value);

    console.log("form ===> ", props.editTask);

    props.handleSubmitTasks(props.category, props.editTask);
    props.handleClose();
  };

  useEffect(() => {
    if (props.editTask) {
      setTitle(props.editTask.title);
      setDescription(props.editTask.description);

      let subTask = [...props.editTask.subTask];
      let newSubTasks = subTask.map((stask, index) => {
        let hdr = "subTask" + (index + 1);
        return { id: hdr, value: stask };
      });
      setNoOfSubTasks(newSubTasks);
    }
  }, [props.editTask]);

  return (
    <div>
      <Dialog open={props.open} onClose={props.handleClose}>
        <DialogTitle sx={{ display: "flex", alignItems: "center" }}>
          <TaskAltOutlined
            sx={{ width: "32px", height: "32px", paddingRight: "5px" }}
          />{" "}
          Edit Task
          <Close
            sx={{ marginLeft: "auto", cursor: "pointer" }}
            onClick={props.handleClose}
          />
        </DialogTitle>
        <DialogContent>
          <DialogContentText>
            <Divider />
          </DialogContentText>
          <Box component="form">
            <Grid container spacing={2}>
              <Grid item xs={12}>
                {" "}
                <TextField
                  autoFocus
                  margin="dense"
                  id="title"
                  label="Title"
                  fullWidth
                  variant="outlined"
                  value={title}
                  onChange={handleTitleChange}
                />
              </Grid>
              <Grid item xs={12}>
                {" "}
                <TextField
                  autoFocus
                  margin="dense"
                  id="description"
                  label="Description"
                  fullWidth
                  variant="outlined"
                  value={description}
                  onChange={handleDescriptionChange}
                />
              </Grid>

              <Grid item xs={3}>
                Sub Tasks
              </Grid>
              <Grid item xs={9}>
                {noOfSubTasks &&
                  noOfSubTasks.length > 0 &&
                  noOfSubTasks.map((subtask, index) => (
                    <SubTask
                      id={subtask.id}
                      index={index}
                      key={subtask.id}
                      value={subtask.value}
                      handleRemoveSubtasks={handleRemoveSubtasks}
                      handleSubTaskOnChange={handleSubTaskOnChange}
                    />
                  ))}
                <Button
                  onClick={handleAddSubtasks}
                  variant="contained"
                  color={"secondary"}
                  variant="text"
                  startIcon={<AddCircleOutlined />}
                  sx={{ marginLeft: "auto" }}
                >
                  Add Subtask
                </Button>
              </Grid>
            </Grid>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={props.handleClose}
            variant="contained"
            sx={{ backgroundColor: "#616161" }}
          >
            Cancel
          </Button>
          <Button
            onClick={handleTaskSubmit}
            variant="contained"
            color={"secondary"}
            type="submit"
          >
            Save
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default EditShiftTasks;
