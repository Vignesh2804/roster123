import React, { useEffect, useState } from "react";

import { Close, Delete, TaskAltOutlined } from "@mui/icons-material";
import {
  Grid,
  Button,
  Divider,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Box,
  Typography,
  Stack,
  Tooltip,
  FormControlLabel,
  Checkbox,
} from "@mui/material";
import moment from "moment";

const ShiftTaskDetails = (props) => {
  const [checkedState, setCheckedState] = useState(null);
  const [buttonText, setButtonText] = useState("Complete");

  useEffect(() => {
    if (props.task.subTask && props.task.subTask.length > 0) {
      setCheckedState(
        props.task.subTask.map((subTask) => {
          let isCompleted = props.task.subTasksCompleted.filter(
            (completedTask) => completedTask === subTask
          );

          return {
            [subTask]: isCompleted && isCompleted.length > 0 ? true : false,
          };
        })
      );
    }
  }, [props.task.subTask]);

  useEffect(() => {
    if (
      props.task.subTasksCompleted &&
      props.task.subTasksCompleted.length > 0 &&
      props.task.subTask &&
      props.task.subTask.length > 0
    ) {
      if (props.task.subTask.length === props.task.subTasksCompleted.length) {
        setButtonText("Reopen");
      } else {
        setButtonText("Complete");
      }
    }
  }, [props.task.subTasksCompleted]);

  const handleTaskEdit = (e) => {
    props.editHandler(props.task);
    props.closeHandler();
  };

  // const handleTaskCopy = (e) => {
  //   props.copyHandler(props.task);
  //   props.closeHandler();
  // };

  const handleTaskDelete = (e) => {
    props.deleteHandler(props.category, props.task);
    props.closeHandler();
  };

  const handleCheckedChange = (e) => {
    let checkState = [...checkedState];
    let item = checkState.filter((el) => el.hasOwnProperty(e.target.name));
    item[0][e.target.name] = e.target.checked;
    setCheckedState(checkState);

    let task = props.task;
    // task.subTasksCompleted += e.target.checked ? 1 : -1;

    if (e.target.checked) {
      if (task.subTasksCompleted.indexOf(e.target.name) === -1) {
        task.subTasksCompleted.push(e.target.name);
        props.updateShiftTask(props.category, task);
      }
    } else {
      let index = task.subTasksCompleted.indexOf(e.target.name);
      if (index !== -1) {
        task.subTasksCompleted.splice(index, 1);
        props.updateShiftTask(props.category, task);
      }
    }

    if (props.task.subTask.length === props.task.subTasksCompleted.length) {
      setButtonText("Reopen");
    } else {
      setButtonText("Complete");
    }
  };

  const handleTaskComplete = () => {
    let mode = buttonText === "Complete" ? buttonText : "Open";
    props.completeHandler(props.task, mode, props.category);
  };

  return (
    <div>
      <Dialog open={props.open} onClose={props.handleClose}>
        <DialogTitle sx={{ display: "flex", alignItems: "center" }}>
          <TaskAltOutlined
            sx={{ width: "32px", height: "32px", paddingRight: "5px" }}
          />
          {props.task.title}
          <Box sx={{ marginLeft: "auto" }}>
            <Stack direction="row" spacing={2}>
              {/* <Tooltip title="Copy Template" key="copy">
                <ContentCopy
                  sx={{ cursor: "pointer" }}
                  onClick={handleTaskCopy}
                />
              </Tooltip> */}
              <Tooltip title="Delete Template" key="delete">
                <Delete sx={{ cursor: "pointer" }} onClick={handleTaskDelete} />
              </Tooltip>
              <Tooltip title="Close" key="close">
                <Close
                  sx={{ cursor: "pointer" }}
                  onClick={props.closeHandler}
                />
              </Tooltip>
            </Stack>
          </Box>
        </DialogTitle>
        <DialogContent>
          <DialogContentText>
            <Divider />
          </DialogContentText>
          <Box component="form" sx={{ mt: "10px" }}>
            <Grid container spacing={3}>
              <Grid item xs={3}>
                <Typography variant="body2">Date:</Typography>
              </Grid>
              <Grid item xs={9}>
                <Typography variant="body2">
                  {moment(props.task.shiftDate).format("MMM DD, YYYY")}
                </Typography>
              </Grid>

              <Grid item xs={3}>
                <Typography variant="body2">Shift:</Typography>
              </Grid>
              <Grid item xs={9}>
                {props.task.shift &&
                  props.task.shift.length > 0 &&
                  props.task.shift.map((shift) => (
                    <Typography variant="body2" key={shift.assignee}>
                      {shift.assignee + " - " + shift.timeSlot}
                    </Typography>
                  ))}
              </Grid>

              <Grid item xs={3}>
                <Typography variant="body2">Description:</Typography>
              </Grid>
              <Grid item xs={9}>
                <Typography variant="body2">
                  {props.task.description}
                </Typography>
              </Grid>

              <Grid item xs={3}>
                <Typography variant="body2">Sub Tasks:</Typography>
              </Grid>
              <Grid item xs={9}>
                <Stack>
                  {props.task &&
                    props.task.subTask &&
                    props.task.subTask.length > 0 &&
                    props.task.subTask.map((subtask, index) => {
                      let isChecked =
                        checkedState && checkedState.length > 0
                          ? checkedState[index][subtask]
                          : false;
                      return (
                        <FormControlLabel
                          label={subtask}
                          key={subtask}
                          name={subtask}
                          control={
                            <Checkbox
                              checked={isChecked}
                              onChange={(e) => {
                                handleCheckedChange(e);
                              }}
                            />
                          }
                        />
                      );
                    })}
                </Stack>
              </Grid>
            </Grid>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={handleTaskComplete}
            variant="contained"
            color="primary"
            size="small"
          >
            {buttonText}
          </Button>
          <Button
            onClick={handleTaskEdit}
            variant="contained"
            color={"secondary"}
            type="submit"
            size="small"
          >
            Edit
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default ShiftTaskDetails;
