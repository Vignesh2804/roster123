import React, { useEffect, useState } from "react";
import SwipeableViews from "react-swipeable-views";
import TabPanel from "../../../Components/TabPanel";
import { useTheme } from "@mui/material/styles";
import {
  Tabs,
  Tab,
  Box,
  Button,
  Stack,
  Container,
  Typography,
  TextField,
  Paper,
} from "@mui/material";
import SearchBar from "../../../Components/SearchBar";
import { Edit } from "@mui/icons-material";
import CreateTemplateDialog from "./TaskTemplates/CreateTemplateDialog";
import TaskCard from "./TaskTemplates/TaskCard";
import TaskDetailsDialog from "./TaskTemplates/TaskDetails";
import CustomPopover from "../../../Components/CustomPopover";
import ReportHeader from "../../../Components/ReportHeader";
import ShiftTasks from "./ShiftTasks";

const sortByOptions = [
  { label: "Date", value: "date", defaultChecked: true },
  { label: "Status", value: "status" },
];

const groupByOptions = [
  { label: "None", value: "none", defaultChecked: true },
  { label: "Status", value: "status" },
];

const filterOptions = [
  {
    name: "Status",
    filters: [
      { name: "completed", label: "Completed" },
      { name: "notcompleted", label: "Not Completed" },
    ],
  },
  {
    name: "State",
    filters: [
      { name: "assigned", label: "Assigned" },
      { name: "available", label: "Available" },
      { name: "unassigned", label: "Unassigned" },
    ],
  },
];

const RenderFeedback = (props) => {
  const [feedback, setFeedback] = useState(null);

  const handleFeedbackChange = (e) => {
    setFeedback(e.target.value);
  };

  return (
    <Box sx={{ mt: "10px", p: "15px", width: "350px" }}>
      <Stack spacing={2}>
        <Typography variant="subtitle1">Feedback</Typography>
        <TextField
          id="feedback"
          label="Your Suggestions & feedback"
          multiline
          rows={4}
          value={feedback}
          onChange={handleFeedbackChange}
          variant="outlined"
        />
        <Button
          onClick={props.handleOpen}
          variant="contained"
          color={"secondary"}
          size="small"
        >
          Share
        </Button>
      </Stack>
    </Box>
  );
};

const TasksTabs = () => {
  const theme = useTheme();
  const [value, setValue] = useState(0);

  const [openCreateDialog, setOpenCreateDialog] = useState(false);
  const [tasks, setTasks] = useState([
    {
      title: "Task 1",
      description: "Test Description",
      subTask: ["Sub Task 1", "Sub Task 2"],
    },
    {
      title: "Task 2",
      description: "Test Description",
      subTask: ["Sub Task 1", "Sub Task 2"],
    },
  ]);

  const [openTaskDetails, setOpenTaskDetails] = useState(false);
  const [taskDetails, setTaskDetails] = useState(null);
  const [editTask, setEditTask] = useState(null);
  const [copyTask, setCopyTask] = useState(null);

  //popper
  const [open, setOpen] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);

  const canBeOpen = open && Boolean(anchorEl);
  const id = canBeOpen ? "feedbackpopover" : undefined;

  const togglePopOver = (event) => {
    setAnchorEl(event.currentTarget);
    setOpen((previousOpen) => !previousOpen);
  };
  //

  const handleCreateDialogClickOpen = () => {
    setOpenCreateDialog(true);
  };

  const handleCreateDialogClose = () => {
    setOpenCreateDialog(false);
  };

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const handleChangeIndex = (index) => {
    setValue(index);
  };

  const handleSubmitTasks = (task) => {
    if (editTask) {
      let taskCopy = [...tasks];

      setTasks(
        taskCopy.map((tasks) => {
          if (tasks.title === task.title) {
            tasks = task;
            return tasks;
          }
          return tasks;
        })
      );

      setEditTask(null);
    } else {
      let alreadyExists = tasks.filter((item) => item.title === task.title);
      if (alreadyExists && alreadyExists.length > 0) {
        return;
      }
      if (copyTask) {
        setCopyTask(null);
      }
      setTasks((oldTasks) => [...oldTasks, task]);
    }
  };

  const handleOpenTaskDetails = (task) => {
    setOpenTaskDetails(true);
    setTaskDetails(task);
  };

  const handleCloseTaskDetails = () => {
    setOpenTaskDetails(false);
  };

  const handleEditTemplate = (task) => {
    setOpenTaskDetails(false);
    setEditTask(task);
    setOpenCreateDialog(true);
  };

  const handleCopyTemplate = (task) => {
    setOpenTaskDetails(false);
    setCopyTask(task);
    setOpenCreateDialog(true);
  };

  const handleDeleteTemplate = (task) => {
    setTasks(tasks.filter((item) => item.title !== task.title));
  };

  return (
    <Box sx={{ flexGrow: 1 }}>
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "flex-start",
        }}
        component={Paper}
      >
        <Box>
          <Tabs
            value={value}
            onChange={handleChange}
            indicatorColor="secondary"
            textColor="secondary"
            sx={{
              backgroundColor: "white",
            }}
          >
            <Tab label="Shift Taks" />
            <Tab label="Tasks Templates" />
          </Tabs>
        </Box>
        <Box sx={{ marginLeft: "auto" }}>
          <Stack spacing={2} direction="row">
            <SearchBar />
            <Button
              variant="contained"
              endIcon={<Edit />}
              color="nuetral"
              onClick={togglePopOver}
            >
              Share Feedback
            </Button>
            {value === 1 && (
              <Button
                variant="contained"
                color="secondary"
                onClick={handleCreateDialogClickOpen}
              >
                Create Template
              </Button>
            )}
          </Stack>
        </Box>
      </Box>
      {value === 0 && (
        <Box
          sx={{
            borderRadius: "5px",
            padding: "10px",
            mt: "2px",
            backgroundColor: "white",
          }}
        >
          <ReportHeader
            sortBy={sortByOptions}
            groupBy={groupByOptions}
            filters={filterOptions}
          />
        </Box>
      )}

      <SwipeableViews
        axis={theme.direction === "rtl" ? "x-reverse" : "x"}
        index={value}
        onChangeIndex={handleChangeIndex}
      >
        <TabPanel value={value} index={0} dir={theme.direction}>
          <ShiftTasks />
        </TabPanel>
        <TabPanel value={value} index={1} dir={theme.direction}>
          <Container>
            {tasks &&
              tasks.length > 0 &&
              tasks.map((task) => (
                <TaskCard
                  task={task}
                  key={task.title}
                  openDetailsHandler={handleOpenTaskDetails}
                  editHandler={handleEditTemplate}
                  copyHandler={handleCopyTemplate}
                  deleteHandler={handleDeleteTemplate}
                />
              ))}
          </Container>
        </TabPanel>
      </SwipeableViews>
      {openCreateDialog && (
        <CreateTemplateDialog
          open={openCreateDialog}
          handleClose={handleCreateDialogClose}
          handleSubmitTasks={handleSubmitTasks}
          editTask={editTask}
          copyTask={copyTask}
        />
      )}
      {openTaskDetails && (
        <TaskDetailsDialog
          task={taskDetails}
          open={openTaskDetails}
          closeHandler={handleCloseTaskDetails}
          editHandler={handleEditTemplate}
          copyHandler={handleCopyTemplate}
          deleteHandler={handleDeleteTemplate}
        />
      )}
      {open && (
        <CustomPopover
          open={open}
          anchorEl={anchorEl}
          id={id}
          handleClose={togglePopOver}
          anchorOrigin={{
            vertical: "bottom",
            horizontal: "left",
          }}
          transformOrigin={{
            vertical: "top",
            horizontal: "right",
          }}
        >
          <RenderFeedback handleOpen={togglePopOver} />
        </CustomPopover>
      )}
    </Box>
  );
};

export default TasksTabs;
