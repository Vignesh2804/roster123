import React, { useState } from "react";

import {
  Button,
  CssBaseline,
  TextField,
  Grid,
  Box,
  Container,
  FormLabel,
  Switch,
  Breadcrumbs,
  Link,
  IconButton,
} from "@mui/material";
import { useHistory } from "react-router";
import CustomAutoComplete from "../../../Components/CustomAutoComplete";
import { ArrowBack } from "@material-ui/icons";
import AddPagesHeader from "../../../Components/AddPagesHeader";

const AddGroup = (props) => {
  const history = useHistory();

  const [employees, setEmployees] = useState([
    { label: "Vinoth" },
    { label: "Ramesh" },
  ]);

  const handleSubmit = (event) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    console.log("data", data);
    history.push("/dashboard/groups");
  };

  const handleBackClick = (e) => {
    e.preventDefault();
    history.push("/dashboard/groups");
  };

  const RenderForm = () => {
    return (
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <Box component="form" noValidate onSubmit={handleSubmit} sx={{ mt: 3 }}>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <TextField
                autoComplete="groupname"
                name="groupname"
                required
                fullWidth
                id="groupname"
                label="Group Name"
                autoFocus
              />
            </Grid>

            <Grid item xs={12} sm={4}>
              <FormLabel component="p" sx={{ textAlign: "left" }}>
                Employees
              </FormLabel>
            </Grid>
            <Grid item xs={12} sm={8}>
              <CustomAutoComplete
                id="employees"
                options={employees}
                inputLabel=""
              />
            </Grid>

            <Grid item xs={12} sm={6}>
              <FormLabel component="p" sx={{ textAlign: "left" }}>
                Hide from your schedule
              </FormLabel>
            </Grid>
            <Grid item xs={12} sm={6} sx={{ textAlign: "right" }}>
              <Switch defaultChecked />
            </Grid>

            <Grid item xs={12} sm={6}>
              <Button
                fullWidth
                variant="contained"
                sx={{ mt: 3, mb: 2, backgroundColor: "#616161" }}
                onClick={handleBackClick}
              >
                Cancel
              </Button>
            </Grid>

            <Grid item xs={12} sm={6}>
              <Button
                type="submit"
                fullWidth
                variant="contained"
                sx={{ mt: 3, mb: 2 }}
                color={"secondary"}
              >
                Save
              </Button>
            </Grid>
          </Grid>
        </Box>
      </Box>
    );
  };

  return (
    <Grid
      container
      sx={{ display: "flex", flexDirection: "column", alignItems: "center" }}
    >
      <Grid
        item
        xs={8}
        sx={{
          mt: "15px",
          width: "100%",
          backgroundColor: "#ffffff",
          borderRadius: "10px",
        }}
      >
        <AddPagesHeader
          firstLink="Group"
          secondLink="Add Group"
          navigateTo="/dashboard/groups"
        />
      </Grid>

      <Grid item xs={12}>
        <Container component="main" maxWidth="sm">
          <CssBaseline />
          <RenderForm />
        </Container>
      </Grid>
    </Grid>
  );
};

export default AddGroup;
