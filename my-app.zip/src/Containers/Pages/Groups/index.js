import React from "react";
import CustomDataTable from "../../../Components/CustomDataTable";
import SubHeader from "../../../Components/SubHeader";

import { Delete, Edit, Mail, NoAccounts } from "@mui/icons-material";
import { GridActionsCellItem } from "@mui/x-data-grid";

const GroupsList = (props) => {
  const editGroups = (id) => {
    return;
  };

  const deleteGroups = (id) => {
    return;
  };

  const GroupColumns = [
    { field: "name", headerName: "Name", flex: 1 },
    { field: "noOfEmployees", headerName: "No of Employees", flex: 1 },

    {
      field: "actions",
      type: "actions",
      width: 80,
      getActions: (params) => [
        <GridActionsCellItem
          icon={<Edit />}
          label="Edit"
          onClick={editGroups(params.id)}
        />,
        <GridActionsCellItem
          icon={<Delete />}
          label="Delete"
          onClick={deleteGroups(params.id)}
          showInMenu
        />,
      ],
    },
  ];

  const GroupData = [
    {
      id: Math.random().toString(),
      name: "HR",
      noOfEmployees: 1,
    },
    {
      id: Math.random().toString(),
      name: "IT",
      noOfEmployees: 25,
    },
  ];

  return (
    <>
      <SubHeader
        heading={"1 Group"}
        buttonText="Group"
        navigateTo="/dashboard/addgroup"
        ButtonType="navigation"
      />
       <br />
      <CustomDataTable
        title="Group"
        columns={GroupColumns}
        rows={GroupData}
        elevation={6}
        checkboxNeeded
      />
    </>
  );
};

export default GroupsList;
