import { ClearAll, DateRangeOutlined } from "@mui/icons-material";

import { Box, Tabs, Tab, Paper, colors, Tooltip } from "@mui/material";
import React from "react";
import CustomList from "../../../Components/CustomList";
import Styles from "./Dashboard.module.css";
import { dashNotifications } from "../../../DummyData/tentativeData";
import TabPanel from "../../../Components/TabPanel";
import SwipeableViews from "react-swipeable-views";
import { useTheme } from "@mui/material/styles";

const DashboardPage = (props) => {
  const theme = useTheme();
  const [value, setValue] = React.useState(0);
  const purple = colors.purple[500];

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  const handleChangeIndex = (index) => {
    setValue(index);
  };

  return (
    <Box component="main">
      <Box
        component={Paper}
        sx={{
          width: "100%",
          mt: 2,
          height: "50px",
          bgcolor: purple,
          color: "white",
          display: "flex",
          direction: "column",
          alignItems: "center",
          p: 2,
        }}
      >
        <DateRangeOutlined />
        <span style={{ paddingLeft: "2px" }}>
          You dont have any shifts today.
        </span>
      </Box>
      <Box component={Paper} sx={{ width: "100%", mt: 2 }} elevation={6}>
        <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
          <Tabs
            value={value}
            onChange={handleChange}
            aria-label="notification tab"
            sx={{
              p: "10px",
              color: "rgba(0, 140, 255, 0.966)",
            }}
            textColor="secondary"
            indicatorColor="secondary"
          >
            <Tab label="Notifications" />
            <Tab label="Roster" />
          </Tabs>
        </Box>
        <SwipeableViews
          axis={theme.direction === "rtl" ? "x-reverse" : "x"}
          index={value}
          onChangeIndex={handleChangeIndex}
        >
          <TabPanel value={value} index={0}>
            <Box
              sx={{
                bgcolor: "rgba(0, 140, 255, 0.966)",
                color: "white",
                p: "5px",
                borderRadius: "5px",
              }}
            >
              <p className={Styles.notificationHeader}>
                Need your attention for the following items
                <span className={Styles.notificationHeaderIcon}>
                  <Tooltip title="Clear all notifications">
                    <ClearAll />
                  </Tooltip>
                </span>
              </p>
            </Box>
            {dashNotifications && <CustomList items={dashNotifications} />}
          </TabPanel>
          <TabPanel value={value} index={1}>
            Roaster
          </TabPanel>
        </SwipeableViews>
      </Box>
    </Box>
  );
};

export default DashboardPage;
