import React, { useState } from "react";

import {
  CssBaseline,
  TextField,
  Grid,
  Box,
  Container,
  MenuItem,
  InputLabel,
  FormControl,
  Select,
  FormLabel,
  Switch,
  RadioGroup,
  FormControlLabel,
  Divider,
  Radio,
  Button,
} from "@mui/material";
import { useHistory } from "react-router";
import AddPagesHeader from "../../../../Components/AddPagesHeader";

const AddFeed = (props) => {
  const history = useHistory();

  const [whoCanSeeValue, setWhoCanSeeValue] = useState("");
  const [follow, setFollow] = useState(false);
  const [selectedRestriction, setSelectedRestriction] = useState("");

  const handleSubmit = (event) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    console.log(data);

    props.handleShowAdd(false);
  };

  const handleBackClick = (e) => {
    e.preventDefault();
    props.handleShowAdd(false);
  };

  const handleWhoCanSeeChange = (e) => {
    setWhoCanSeeValue(e.target.value);
  };

  const handleSelectedRestrictionChange = (e) => {
    setSelectedRestriction(e.target.value);
  };

  const handleFollowChange = (e) => {
    setFollow(e.target.checked);
  };

  const RenderForm = () => {
    return (
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <Box component="form" noValidate onSubmit={handleSubmit} sx={{ mt: 3 }}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={12}>
              <TextField
                autoComplete="feedname"
                name="feedname"
                required
                fullWidth
                id="feedname"
                label="feedname"
                autoFocus
              />
            </Grid>
            <Grid item xs={12} sm={12}>
              <TextField
                required
                fullWidth
                id="description"
                label="description"
                name="description"
                autoComplete="description"
              />
            </Grid>

            <Grid item xs={12} style={{ textAlign: "left" }}>
              <FormLabel>Who can see this page?</FormLabel>
            </Grid>

            <Grid item xs={12} sm={12} style={{ textAlign: "left" }}>
              <FormControl component="fieldset">
                <RadioGroup
                  row
                  name="whocansee"
                  value={whoCanSeeValue}
                  onChange={handleWhoCanSeeChange}
                >
                  <FormControlLabel
                    value="everyone"
                    control={<Radio />}
                    label="Every One"
                  />
                  <FormControlLabel
                    value="members"
                    control={<Radio />}
                    label="Selected Members"
                  />
                </RadioGroup>
              </FormControl>
            </Grid>

            <Grid item xs={12} sm={6} style={{ textAlign: "left" }}>
              <FormLabel>Members should follow?</FormLabel>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Switch
                size="large"
                color="secondary"
                onChange={handleFollowChange}
                checked={follow}
              />
            </Grid>
            <Grid item xs={12} sm={12}>
              <Divider />
            </Grid>

            <Grid item xs={12} sm={12}>
              <FormControl fullWidth>
                <InputLabel id="RestrictionsLabel">Restrictions</InputLabel>
                <Select
                  labelId="RestrictionsLabel"
                  id="restrictions"
                  value={selectedRestriction}
                  label="Restrictions"
                  onChange={handleSelectedRestrictionChange}
                >
                  <MenuItem value={"everyone"}>Everyone can post</MenuItem>
                  <MenuItem value={"members"}>Only members</MenuItem>
                </Select>
              </FormControl>
            </Grid>

            <Grid item xs={12} sm={6}>
              <Button
                fullWidth
                variant="contained"
                sx={{ mt: 3, mb: 2, backgroundColor: "#616161" }}
                onClick={handleBackClick}
              >
                Cancel
              </Button>
            </Grid>

            <Grid item xs={12} sm={6}>
              <Button
                type="submit"
                fullWidth
                variant="contained"
                sx={{ mt: 3, mb: 2 }}
                color={"secondary"}
              >
                Save
              </Button>
            </Grid>
          </Grid>
        </Box>
      </Box>
    );
  };

  return (
    <Grid
      container
      sx={{ display: "flex", flexDirection: "column", alignItems: "center" }}
    >
      <Grid
        item
        xs={8}
        sx={{
          mt: "15px",
          width: "100%",
          backgroundColor: "#ffffff",
          borderRadius: "10px",
        }}
      >
        <AddPagesHeader
          firstLink="Feed"
          secondLink="Add Feed"
          navigateTo="/feeds"
        />
      </Grid>

      <Grid item xs={12}>
        <Container component="main" maxWidth="sm">
          <CssBaseline />
          <RenderForm />
        </Container>
      </Grid>
    </Grid>
  );
};

export default AddFeed;
