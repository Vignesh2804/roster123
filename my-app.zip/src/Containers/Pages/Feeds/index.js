import React, { useState } from "react";
import AddFeed from "./AddFeed/AddFeed";
import AllFeeds from "./AllFeeds";
import FeedDetails from "./FeedDetails/FeedDetails";

const Feed = () => {
  const PagesList = ["Page 1", "Page 2", "Page 3", "Page 4"];

  const [showAdd, setShowAdd] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [selectedPage, setSelectedPage] = useState("");

  const handleShowAdd = (value) => {
    setShowAdd(value);
  };

  const handleShowDetails = (value, page) => {
    setShowDetails(value);
    setSelectedPage(page);
  };

  return (
    <>
      {(PagesList && PagesList.length === 0) ||
        (showAdd && !showDetails && <AddFeed handleShowAdd={handleShowAdd} />)}

      {PagesList && PagesList.length > 0 && !showAdd && !showDetails && (
        <AllFeeds
          PagesList={PagesList}
          handleShowAdd={handleShowAdd}
          handleShowDetails={handleShowDetails}
        />
      )}

      {showDetails && (
        <FeedDetails
          PagesList={PagesList}
          selectedPage={selectedPage}
          handleShowDetails={handleShowDetails}
        />
      )}
    </>
  );
};

export default Feed;
