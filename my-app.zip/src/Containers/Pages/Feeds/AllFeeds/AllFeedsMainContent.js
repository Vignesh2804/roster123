import {
  Grid,
  Box,
  Divider,
  Paper,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
} from "@mui/material";
import React from "react";
import TextEditor from "../../../../Components/TextEditor";
import DisplayPage from "../FeedDetails/DisplayPage";

const AllFeedsMainContent = (props) => {
  const [postTo, setPostTo] = React.useState("");

  const handlePostToChange = (event) => {
    setPostTo(event.target.value);
  };

  return (
    <Box sx={{ flexGrow: 1 }}>
      <Grid container spacing={2}>
        <Grid
          item
          xs={12}
          sx={{
            textAlign: "left",
          }}
        >
          <Box component={Paper}>
            <Box sx={{ p: "10px" }}>
              <FormControl>
                <InputLabel id="postTo-label">Post to</InputLabel>
                <Select
                  labelId="postTo-label"
                  id="postTo-select"
                  value={postTo}
                  label="Post to"
                  onChange={handlePostToChange}
                  sx={{ width: "200px", height: "40px" }}
                >
                  {props.PagesList &&
                    props.PagesList.length > 0 &&
                    props.PagesList.map((page) => (
                      <MenuItem key={page} value={page}>
                        {page}
                      </MenuItem>
                    ))}
                </Select>
              </FormControl>
            </Box>
            <TextEditor />
          </Box>
        </Grid>
        <Grid item xs={12}>
          <Divider>20-10-2021</Divider>
        </Grid>
        <Grid item xs={12}>
          <DisplayPage />
        </Grid>
      </Grid>
    </Box>
  );
};

export default AllFeedsMainContent;
