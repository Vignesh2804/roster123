import { Grid, Box, Container } from "@mui/material";
import React from "react";
import NewsFeedHeader from "../FeedHeader/NewsFeedHeader";
import AllFeedsLeftContent from "./AllFeedsLeftContent";
import AllFeedsRightContent from "./AllFeedsRightContent";
import AllFeedsMainContent from "./AllFeedsMainContent";

const AllFeeds = (props) => {
  const RenderForm = () => {
    return (
      <Box sx={{ flexGrow: 1 }}>
        <Grid container spacing={2}>
          <Grid item xs={12} md={2}>
            <AllFeedsLeftContent
              PagesList={props.PagesList}
              handleShowAdd={props.handleShowAdd}
              handleShowDetails={props.handleShowDetails}
            />
          </Grid>

          <Grid item xs={12} md={7}>
            <AllFeedsMainContent
              PagesList={props.PagesList}
              handleShowAdd={props.handleShowAdd}
            />
          </Grid>

          <Grid item xs={12} md={3}>
            <AllFeedsRightContent />
          </Grid>
        </Grid>
      </Box>
    );
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4 }}>
      <Grid container spacing={2}>
        <Grid
          item
          xs={12}
          sx={{
            backgroundColor: "#ffffff",
            borderRadius: "10px",
            padding: "10px",
          }}
        >
          <NewsFeedHeader
            firstLink="Feed"
            secondLink={props.PagesList[0]}
            navigateTo="/feeds"
            mode="allfeeds"
            handleShowAdd={props.handleShowAdd}
          />
        </Grid>

        <Grid item xs={12}>
          <RenderForm />
        </Grid>
      </Grid>
    </Container>
  );
};

export default AllFeeds;
