import { Grid, Box, Typography, Avatar } from "@mui/material";
import React, { useState } from "react";

const AllFeedsRightContent = (props) => {
  return (
    <Grid container spacing={2}>
      <Grid item xs={12}>
        <Box sx={{ display: "flex" }}>
          <Avatar>
            <Typography variant="body1">E1</Typography>
          </Avatar>
          <Box sx={{ textAlign: "left", pl: "10px" }}>
            <Typography variant="subtitle2">
              Employee 1 created a new post in Page 2
            </Typography>
            <Typography variant="caption">Oct 20, 2021 @ 4:12 PM</Typography>
          </Box>
        </Box>
      </Grid>
      <Grid item xs={12}>
        <Box sx={{ display: "flex" }}>
          <Avatar>
            <Typography variant="body1">E1</Typography>
          </Avatar>
          <Box sx={{ textAlign: "left", pl: "10px" }}>
            <Typography variant="subtitle2">
              Employee 1 created a new post in Page 1
            </Typography>
            <Typography variant="caption">Oct 20, 2021 @ 3:10 PM</Typography>
          </Box>
        </Box>
      </Grid>
    </Grid>
  );
};

export default AllFeedsRightContent;
