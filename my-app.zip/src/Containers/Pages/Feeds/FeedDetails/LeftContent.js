import { AddBoxOutlined, Edit, FeedOutlined } from "@mui/icons-material";
import {
  Grid,
  ListItem,
  ListItemText,
  List,
  Box,
  Divider,
} from "@mui/material";
import React from "react";
import styles from "../Feeds.module.css";

const LeftContent = (props) => {
  return (
    <Grid container>
      <Grid
        item
        xs={12}
        sx={{
          display: "flex",
          direction: "column",
          justifyContent: "flex-start",
        }}
      >
        <Box>
          <FeedOutlined />
        </Box>
        <Box sx={{ width: "85%", textAlign: "left" }}>Pages</Box>

        <Box>
          <AddBoxOutlined />
        </Box>
      </Grid>
      <Grid item xs={12}>
        <Divider />
      </Grid>
      <Grid item xs={12}>
        <List>
          {props.PagesList.map((pageTitle) => (
            <ListItem key={pageTitle}>
              <ListItemText
                primary={pageTitle}
                className={styles.link}
                onClick={() => props.handleShowDetails(true, pageTitle)}
              />
            </ListItem>
          ))}
        </List>
      </Grid>
    </Grid>
  );
};

export default LeftContent;
