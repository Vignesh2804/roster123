import { Box, Menu, MenuItem } from "@mui/material";
import React, { useState } from "react";

import { MoreVert } from "@mui/icons-material";

const options = ["Open", "Edit", "Delete"];

const ITEM_HEIGHT = 48;

const DisplayMenuButton = () => {
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <Box
      sx={{ border: "solid 1px gainsboro", pt: "7px", verticalAlign: "center" }}
    >
      <Box
        aria-label="more"
        id="long-button"
        aria-controls="long-menu"
        aria-expanded={open ? "true" : undefined}
        aria-haspopup="true"
        onClick={handleClick}
        // sx={{ border: "solid 1px black", pt: "5px", verticalAlign: "center" }}
      >
        <MoreVert sx={{ color: "gray" }} />
      </Box>
      <Menu
        id="long-menu"
        MenuListProps={{
          "aria-labelledby": "long-button",
        }}
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        PaperProps={{
          style: {
            maxHeight: ITEM_HEIGHT * 4.5,
            width: "20ch",
          },
        }}
      >
        {options.map((option) => (
          <MenuItem
            key={option}
            selected={option === "Pyxis"}
            onClick={handleClose}
          >
            {option}
          </MenuItem>
        ))}
      </Menu>
    </Box>
  );
};

export default DisplayMenuButton;
