import { Grid, Box, Container } from "@mui/material";
import React from "react";
import LeftContent from "./LeftContent";
import MainContent from "./MainContent";
import NewsFeedHeader from "../FeedHeader/NewsFeedHeader";
import RightContent from "./RightContent";

const FeedDetails = (props) => {
  const RenderForm = () => {
    return (
      <Box sx={{ flexGrow: 1 }}>
        <Grid container spacing={2}>
          <Grid item xs={12} md={2}>
            <LeftContent
              PagesList={props.PagesList}
              handleShowDetails={props.handleShowDetails}
            />
          </Grid>

          <Grid item xs={12} md={7}>
            <MainContent />
          </Grid>

          <Grid item xs={12} md={3}>
            <RightContent description="test page with lots of description for editting" />
          </Grid>
        </Grid>
      </Box>
    );
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4 }}>
      <Grid container spacing={2}>
        <Grid
          item
          xs={12}
          sx={{
            backgroundColor: "#ffffff",
            borderRadius: "10px",
            padding: "10px",
          }}
        >
          <NewsFeedHeader
            firstLink="Feed"
            secondLink={props.selectedPage}
            navigateTo="/feeds"
            mode="details"
          />
        </Grid>

        <Grid item xs={12}>
          <RenderForm />
        </Grid>
      </Grid>
    </Container>
  );
};

export default FeedDetails;
