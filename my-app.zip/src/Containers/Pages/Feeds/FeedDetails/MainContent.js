import { Grid, Box, Divider, Paper } from "@mui/material";
import React from "react";
import TextEditor from "../../../../Components/TextEditor";
import DisplayPage from "./DisplayPage";

const MainContent = (props) => {
  return (
    <Box sx={{ flexGrow: 1 }}>
      <Grid container spacing={2}>
        <Grid
          item
          xs={12}
          sx={{
            textAlign: "left",
          }}
        >
          <Box component={Paper}>
            <TextEditor />
          </Box>
        </Grid>
        <Grid item xs={12}>
          <Divider>21-10-2021</Divider>
        </Grid>
        <Grid item xs={12}>
          <DisplayPage />
        </Grid>
      </Grid>
    </Box>
  );
};

export default MainContent;
