import {
  Avatar,
  Grid,
  Paper,
  Box,
  Typography,
  Divider,
  Tooltip,
} from "@mui/material";
import React, { useState } from "react";

import { ModeComment, Visibility, Circle, ThumbUp } from "@mui/icons-material";
import DisplayMenuButton from "./DisplayMenuButton";
import CommentSection from "../../../../Components/CommentSection";

const DisplayPage = () => {
  const [like, setLike] = useState(false);
  const [showCommentSection, setShowCommentSection] = useState(false);

  const [comments, setComments] = useState([]);
  const [seenBy, setSeenBy] = useState(0);

  const handleLikeClick = () => {
    setLike((prevValue) => !prevValue);
  };

  const handleCommentClick = () => {
    setShowCommentSection((show) => !show);
  };

  return (
    <>
      <Box component={Paper} sx={{ padding: "5px" }}>
        <Grid container spacing={2} sx={{ padding: "5px" }}>
          <Grid item xs={12} container>
            <Grid
              item
              xs={4}
              sx={{
                display: "flex",
                alignItems: "center",
                justifyContent: "flex-start",
              }}
            >
              <Avatar>
                <Typography variant="body1">E1</Typography>
              </Avatar>
              <Box sx={{ textAlign: "left", paddingLeft: "10px" }}>
                <Typography variant="body2">Employee 1</Typography>
                <Box>
                  <Typography variant="caption">Designation </Typography>
                  <Circle sx={{ fontSize: "5px" }} color="primary" />
                  <Typography variant="caption" sx={{ pl: "3px" }}>
                    Company
                  </Typography>
                </Box>
              </Box>
            </Grid>
            <Grid item xs={4}></Grid>
            <Grid
              item
              xs={4}
              sx={{
                display: "flex",
                alignItems: "center",
                justifyContent: "flex-end",
              }}
            >
              <Box sx={{ textAlign: "right", padding: "5px" }}>
                <Typography variant="body2">Page 1</Typography>
                <Box>
                  <Typography variant="caption">
                    51 minutes ago @ 3:44 pm
                  </Typography>
                </Box>
              </Box>
              <DisplayMenuButton />
            </Grid>
          </Grid>
          <Grid item xs={12} sx={{ textAlign: "left" }}>
            <Divider></Divider>
          </Grid>
          <Grid item xs={12} sx={{ textAlign: "left", minHeight: "50px" }}>
            Description
          </Grid>
          {/* <Grid item xs={12} sx={{ textAlign: "left" }}>
          <Divider />
        </Grid> */}
          <Grid item xs={12} container>
            <Grid
              item
              xs={2}
              sx={{
                display: "flex",
                alignItems: "center",
                justifyContent: "flex-start",
              }}
            >
              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  width: "50%",
                  pr: "10px",
                }}
              >
                <Tooltip title="Like">
                  <ThumbUp
                    color={like ? "primary" : "none"}
                    onClick={handleLikeClick}
                    sx={{ cursor: "pointer" }}
                  />
                </Tooltip>
                {like && <Typography variant="body2">1</Typography>}
              </Box>

              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  width: "50%",
                  pr: "10px",
                }}
              >
                <Tooltip title="Comment">
                  <ModeComment
                    color={comments.length > 0 ? "primary" : "none"}
                    sx={{ cursor: "pointer" }}
                    onClick={handleCommentClick}
                  />
                </Tooltip>
                {comments.length > 0 && (
                  <Typography variant="body2">{comments.length}</Typography>
                )}
              </Box>
            </Grid>
            <Grid item xs={6}></Grid>
            <Grid
              item
              xs={4}
              sx={{
                paddingRight: "10px",
                display: "flex",
                alignItems: "center",
                justifyContent: "flex-end",
              }}
            >
              <Visibility color="primary" sx={{ paddingRight: "5px" }} />
              <Typography variant="caption">Seen by {seenBy}</Typography>
            </Grid>
          </Grid>
        </Grid>
      </Box>
      {showCommentSection && (
        <Box sx={{ backgroundColor: "gainsboro" }}>
          <CommentSection />
        </Box>
      )}
    </>
  );
};

export default DisplayPage;
