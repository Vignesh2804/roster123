import { Edit } from "@mui/icons-material";
import {
  Grid,
  ListItemText,
  ListItemIcon,
  ListItemButton,
  List,
  Box,
  Paper,
  Typography,
  TextField,
  Button,
  Collapse,
} from "@mui/material";
import React, { useState } from "react";

import { People, ArrowRight, ArrowDropDown } from "@mui/icons-material";

const RightContent = (props) => {
  const [edit, setEdit] = useState(false);
  const [pageDescription, setPageDescription] = useState("");
  const [accessOpen, setAccessOpen] = useState(false);
  const [followOpen, setFollowOpen] = useState(false);

  const handleSaveButton = () => {};
  const handleCancelButton = () => {
    setEdit(false);
  };
  const handleEditClick = () => {
    setEdit(true);
  };
  const handleAccessClick = () => {
    setAccessOpen((prevValue) => !prevValue);
  };
  const handleFollowClick = () => {
    setFollowOpen((prevValue) => !prevValue);
  };

  return (
    <Grid container spacing={2}>
      <Grid item xs={12}>
        <Box component={Paper} sx={{ textAlign: "left" }}>
          <Typography
            variant="subtitle1"
            gutterBottom
            component="div"
            sx={{ padding: "10px" }}
          >
            Description
          </Typography>
          {!edit && (
            <Box
              sx={{
                display: "flex",
                direction: "row",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              <Typography
                variant="subtitle2"
                gutterBottom
                component="div"
                sx={{ padding: "10px" }}
              >
                {props.description}
              </Typography>
              <Edit
                onClick={handleEditClick}
                sx={{ cursor: "pointer", marginRight: "10px" }}
              />
            </Box>
          )}

          {edit && (
            <Box sx={{ padding: "10px" }}>
              <TextField
                name="pageDescription"
                value={pageDescription}
                fullWidth
                size="small"
              ></TextField>
              <Grid container spacing={1}>
                <Grid item xs={12} sm={6}>
                  <Button
                    fullWidth
                    variant="contained"
                    sx={{ mt: 3, mb: 2, backgroundColor: "#616161" }}
                    onClick={handleCancelButton}
                    size="small"
                  >
                    Cancel
                  </Button>
                </Grid>

                <Grid item xs={12} sm={6}>
                  <Button
                    type="submit"
                    fullWidth
                    variant="contained"
                    sx={{ mt: 3, mb: 2 }}
                    color={"secondary"}
                    onClick={handleSaveButton}
                    size="small"
                  >
                    Save
                  </Button>
                </Grid>
              </Grid>
            </Box>
          )}
        </Box>
      </Grid>
      <Grid item xs={12}>
        <Box component={Paper} sx={{ textAlign: "left" }}>
          <Typography
            variant="subtitle1"
            gutterBottom
            component="div"
            sx={{ padding: "10px" }}
          >
            Access to this page
          </Typography>
          <List>
            <ListItemButton onClick={handleAccessClick}>
              <ListItemIcon>
                <People />
              </ListItemIcon>
              <ListItemText secondary="Inbox" />
              {accessOpen ? <ArrowDropDown /> : <ArrowRight />}
            </ListItemButton>
            <Collapse in={accessOpen} timeout="auto" unmountOnExit>
              <List component="div" disablePadding>
                <ListItemButton sx={{ pl: 4 }}>
                  <ListItemText secondary="Employee 1" />
                </ListItemButton>
              </List>
            </Collapse>
          </List>
        </Box>
      </Grid>
      <Grid item xs={12}>
        <Box component={Paper} sx={{ textAlign: "left" }}>
          <Typography
            variant="subtitle1"
            gutterBottom
            component="div"
            sx={{ padding: "10px" }}
          >
            Following this page
          </Typography>
          <List>
            <ListItemButton onClick={handleFollowClick}>
              <ListItemIcon>
                <People />
              </ListItemIcon>
              <ListItemText secondary="Inbox" />
              {followOpen ? <ArrowDropDown /> : <ArrowRight />}
            </ListItemButton>
            <Collapse in={followOpen} timeout="auto" unmountOnExit>
              <List component="div" disablePadding>
                <ListItemButton sx={{ pl: 4 }}>
                  <ListItemText secondary="Employee 1" />
                </ListItemButton>
              </List>
            </Collapse>
          </List>
        </Box>
      </Grid>
    </Grid>
  );
};

export default RightContent;
