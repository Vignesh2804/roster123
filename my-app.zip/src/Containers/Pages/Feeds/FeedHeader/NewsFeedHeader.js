import React from "react";
import { useHistory } from "react-router";
import CustomBreadCrumb from "../../../../Components/CustomBreadCrumb";
import HeaderMenuButton from "./HeaderMenuButton";
import { Box, Button } from "@mui/material";
import { Add } from "@mui/icons-material";

const NewsFeedHeader = (props) => {
  return (
    <Box
      sx={{
        display: "flex",
        alignItems: "center",
        width: "100%",
      }}
    >
      <Box>
        <CustomBreadCrumb
          firstLink={props.firstLink}
          secondLink={props.secondLink}
          navigateTo={props.navigateTo}
        />
      </Box>
      <Box
        sx={{
          ml: "auto",
        }}
      >
        {props.mode === "details" && <HeaderMenuButton />}
        {props.mode === "allfeeds" && (
          <Button
            variant="contained"
            endIcon={<Add />}
            color="secondary"
            size="small"
            onClick={() => props.handleShowAdd(true)}
          >
            Create Page
          </Button>
        )}
      </Box>
    </Box>
  );
};

export default NewsFeedHeader;
