import React, { useState } from "react";

import {
  CssBaseline,
  Grid,
  Box,
  Container,
  Divider,
  Button,
  Typography,
} from "@mui/material";
import { useHistory } from "react-router";
import CustomAutoComplete from "../../../Components/CustomAutoComplete";
import { Group, Person } from "@mui/icons-material";

const employees = [
  {
    label: "Vinoth S",
  },
  {
    label: "Employee 1",
  },
];

const PrivateChatCreation = (props) => {
  const history = useHistory();

  const handleSubmit = (event) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    console.log(data);
    props.handleChatMode(null);
  };

  const handleBackClick = (e) => {
    e.preventDefault();
    props.handleChatMode(null);
  };

  const RenderForm = () => {
    return (
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <Box component="form" noValidate onSubmit={handleSubmit} sx={{ mt: 3 }}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={12} sx={{ textAlign: "left" }}>
              <Typography
                variant="h5"
                color="primary"
                sx={{ display: "flex", alignItems: "center" }}
              >
                <Person sx={{ pr: "10px", width: "48px", height: "48px" }} />
                Private Chat
              </Typography>
            </Grid>

            <Grid item xs={12} sm={12}>
              <CustomAutoComplete
                id="employees"
                options={employees}
                inputLabel="Select employee to chat"
              />
            </Grid>

            <Grid item xs={12} sm={12}>
              <Divider />
            </Grid>

            <Grid item xs={12} sm={6}>
              <Button
                fullWidth
                variant="contained"
                sx={{ mt: 3, mb: 2, backgroundColor: "#616161" }}
                onClick={handleBackClick}
              >
                Cancel
              </Button>
            </Grid>

            <Grid item xs={12} sm={6}>
              <Button
                type="submit"
                fullWidth
                variant="contained"
                sx={{ mt: 3, mb: 2 }}
                color={"secondary"}
              >
                Save
              </Button>
            </Grid>
          </Grid>
        </Box>
      </Box>
    );
  };

  return (
    <Grid
      container
      sx={{ display: "flex", flexDirection: "column", alignItems: "center" }}
    >
      <Grid item xs={12}>
        <Container component="main">
          <CssBaseline />
          <RenderForm />
        </Container>
      </Grid>
    </Grid>
  );
};

export default PrivateChatCreation;
