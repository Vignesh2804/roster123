import { Group, Person } from "@mui/icons-material";
import { Container, Box, Typography, Divider, Stack } from "@mui/material";
import React, { useEffect, useState } from "react";
import TabCard from "../../../Components/TabCard";
import GroupChatCreation from "./GroupChat";
import PrivateChatCreation from "./PrivateChat";

const Chat = (props) => {
  const [chatMode, setChatMode] = useState(null);

  const handleChatMode = (mode) => {
    setChatMode(mode);
  };

  useEffect(() => {
    console.log("chatMode ===> ", chatMode);
  }, [chatMode]);

  return (
    <Container maxWidth={"md"}>
      {!chatMode && (
        <Box component="main" sx={{ p: "10px" }}>
          <Typography
            variant="h5"
            color="primary"
            sx={{ mt: "10px", p: "10px", mb: "10px", textAlign: "left" }}
          >
            Welcome {props.user || "User !"}
          </Typography>
          <Box>
            <Divider />
          </Box>
          <Stack spacing={2}>
            <Box onClick={() => handleChatMode("group")}>
              <TabCard
                lbl="Group Chat"
                icon={<Group fontSize="large" />}
                active={chatMode === "group"}
                description="Start a group conversation with coworkers across organization"
              />
            </Box>
            <Box onClick={() => handleChatMode("private")}>
              <TabCard
                lbl="Private Chat"
                icon={<Person fontSize="large" />}
                active={chatMode === "private"}
                description="Start a private conversation with coworkers across organization"
              />
            </Box>
          </Stack>
        </Box>
      )}

      {chatMode === "group" && (
        <GroupChatCreation handleChatMode={handleChatMode} />
      )}
      {chatMode === "private" && (
        <PrivateChatCreation handleChatMode={handleChatMode} />
      )}
    </Container>
  );
};

export default Chat;
