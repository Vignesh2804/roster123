import React, { useState } from "react";

import {
  CssBaseline,
  TextField,
  Grid,
  Box,
  Container,
  MenuItem,
  InputLabel,
  FormControl,
  Select,
  FormLabel,
  Switch,
  RadioGroup,
  FormControlLabel,
  Divider,
  Radio,
  Button,
  Typography,
} from "@mui/material";
import { useHistory } from "react-router";
import { Group, GroupRounded } from "@mui/icons-material";
import CustomAutoComplete from "../../../Components/CustomAutoComplete";

const members = [
  {
    label: "xyz",
    group: "Location",
  },
  {
    label: "abc",
    group: "Location",
  },
  {
    label: "Senior Executive",
    group: "Position",
  },
  {
    label: "General Manager",
    group: "Position",
  },
];

const employees = [
  {
    label: "Vinoth S",
  },
  {
    label: "Employee 1",
  },
];

const GroupChatCreation = (props) => {
  const history = useHistory();

  const [selectedRestriction, setSelectedRestriction] = useState("");

  const handleSubmit = (event) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    console.log(data);
    props.handleChatMode(null);
  };

  const handleBackClick = (e) => {
    e.preventDefault();
    props.handleChatMode(null);
  };

  const handleSelectedRestrictionChange = (e) => {
    setSelectedRestriction(e.target.value);
  };

  const RenderForm = () => {
    return (
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <Box component="form" noValidate onSubmit={handleSubmit} sx={{ mt: 3 }}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={12} sx={{ textAlign: "left" }}>
              <Typography
                variant="h5"
                color="primary"
                sx={{ display: "flex", alignItems: "center" }}
              >
                <Group sx={{ pr: "10px", width: "48px", height: "48px" }} />
                New Group Chat
              </Typography>
            </Grid>
            <Grid item xs={12}>
              <Divider />
            </Grid>
            <Grid item xs={12} sm={12}>
              <TextField
                autoComplete="groupname"
                name="groupname"
                required
                fullWidth
                id="groupname"
                label="Group Name"
                autoFocus
              />
            </Grid>

            <Grid item xs={12}>
              <CustomAutoComplete
                id="members"
                options={members}
                inputLabel="Add Members"
                groupBy={(option) => option.group}
              />
            </Grid>

            <Grid item xs={12} sm={12}>
              <Divider />
            </Grid>

            <Grid item xs={12} sm={12}>
              <FormControl fullWidth>
                <InputLabel id="RestrictionsLabel">Restrictions</InputLabel>
                <Select
                  labelId="RestrictionsLabel"
                  id="restrictions"
                  value={selectedRestriction}
                  label="Restrictions"
                  onChange={handleSelectedRestrictionChange}
                  sx={{ textAlign: "left" }}
                >
                  <MenuItem value={"everyone"}>Everyone can post</MenuItem>
                  <MenuItem value={"admins"}>
                    Only admins and managers can post
                  </MenuItem>
                  <MenuItem value={"members"}>
                    Only specified members can post
                  </MenuItem>
                </Select>
              </FormControl>
            </Grid>

            {selectedRestriction && selectedRestriction === "members" && (
              <Grid item xs={12}>
                <CustomAutoComplete
                  id="employees"
                  options={employees}
                  inputLabel="Add Employees"
                />
              </Grid>
            )}

            <Grid item xs={12} sm={6}>
              <Button
                fullWidth
                variant="contained"
                sx={{ mt: 3, mb: 2, backgroundColor: "#616161" }}
                onClick={handleBackClick}
              >
                Cancel
              </Button>
            </Grid>

            <Grid item xs={12} sm={6}>
              <Button
                type="submit"
                fullWidth
                variant="contained"
                sx={{ mt: 3, mb: 2 }}
                color={"secondary"}
              >
                Save
              </Button>
            </Grid>
          </Grid>
        </Box>
      </Box>
    );
  };

  return (
    <Grid
      container
      sx={{ display: "flex", flexDirection: "column", alignItems: "center" }}
    >
      <Grid item xs={12}>
        <Container component="main" maxWidth="sm">
          <CssBaseline />
          <RenderForm />
        </Container>
      </Grid>
    </Grid>
  );
};

export default GroupChatCreation;
