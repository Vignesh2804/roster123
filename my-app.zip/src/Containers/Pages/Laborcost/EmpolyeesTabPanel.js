import React from "react";
import { Edit } from "@mui/icons-material";
import { GridActionsCellItem } from "@mui/x-data-grid";
import CustomDataTable from "../../../Components/CustomDataTable";

const EmployeesTabPanel = (props) => {
  const editWages = (id) => {
    return;
  };

  const editUser = (id) => {
    return;
  };

  const EmployeesColumns = [
    { field: "name", headerName: "Name", flex: 1 },
    { field: "locations", headerName: "Locations", flex: 1 },
    {
      field: "positions",
      headerName: "Positions",
      width: 200,
      valueFormatter: (params) => {
        // console.log(
        //   "params ===> ",
        //   params.value.toString().split(",").join("\r\n")
        // );
        return params.value.toString();
      },
    },

    { field: "wages", headerName: "Wages", flex: 1 },
    { field: "type", headerName: "Type", width: 200 },

    {
      field: "actions",
      type: "actions",
      width: 80,
      getActions: (params) => [
        <GridActionsCellItem
          icon={<Edit />}
          label="Edit Employees"
          onClick={editUser(params.id)}
          showInMenu
        />,
        <GridActionsCellItem
          icon={<Edit />}
          label="Edit Wages"
          onClick={editWages(params.id)}
          showInMenu
        />,
      ],
    },
  ];

  const EmployeesData = [
    {
      id: Math.random().toString(),
      name: "Vinoth",
      positions: ["Executive", "Senior Executive"],
      locations: ["XYZ", "ABC"],
      type: "Hourly",
      wages: "40",
    },
    {
      id: Math.random().toString(),
      name: "Rakesh",
      positions: ["Junior Executive"],
      locations: ["ABC"],
      type: "Hourly",
      wages: "25",
    },
  ];
  return (
    <CustomDataTable
      title="Employees"
      columns={EmployeesColumns}
      rows={EmployeesData}
      elevation={6}
    />
  );
};

export default EmployeesTabPanel;
