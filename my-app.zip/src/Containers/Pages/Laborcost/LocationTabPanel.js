import React from "react";
import CustomDataTable from "../../../Components/CustomDataTable";
import SubHeader from "../../../Components/SubHeader";

import { Delete, Edit, Mail, NoAccounts } from "@mui/icons-material";
import { GridActionsCellItem } from "@mui/x-data-grid";
import { Divider } from "@mui/material";

const LocationsTabPanel = (props) => {
  const editLocations = (id) => {
    return;
  };

  const editBudget = (id) => {
    return;
  };

  const LocationColumns = [
    { field: "name", headerName: "Name", flex: 1 },
    { field: "projectedSales", headerName: "Projected Sales", flex: 1 },
    { field: "maxBudget", headerName: "Max Budget", flex: 1 },
    { field: "maxHours", headerName: "Max Hours", flex: 1 },

    {
      field: "actions",
      type: "actions",
      width: 80,
      getActions: (params) => [
        <GridActionsCellItem
          icon={<Edit />}
          label="Edit Locations"
          onClick={editLocations(params.id)}
          showInMenu
        />,
        <GridActionsCellItem
          icon={<Edit />}
          label="Edit Budget"
          onClick={editBudget(params.id)}
          showInMenu
        />,
      ],
    },
  ];

  const LocationData = [
    {
      id: Math.random().toString(),
      name: "Chennai",
      projectedSales: "1500",
      maxBudget: "1000",
      maxHours: "40",
    },
    {
      id: Math.random().toString(),
      name: "Bangalore",
      projectedSales: "2500",
      maxBudget: "2000",
      maxHours: "40",
    },
  ];

  return (
    <>
      <SubHeader
        heading={"2 Location"}
        buttonText="Location"
        navigateTo="/dashboard/addlocation"
        ButtonType="navigation"
      />
      <Divider />
      <Divider />
      <CustomDataTable
        title="Locations"
        columns={LocationColumns}
        rows={LocationData}
        elevation={6}
      />
    </>
  );
};

export default LocationsTabPanel;
