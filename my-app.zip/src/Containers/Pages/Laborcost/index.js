import { Tabs, Box, Tab } from "@mui/material";
import React, { useState } from "react";
import SwipeableViews from "react-swipeable-views";
import TabPanel from "../../../Components/TabPanel";
import { useTheme } from "@mui/material/styles";
import SubHeader from "../../../Components/SubHeader";
import { SettingsOutlined } from "@mui/icons-material";
import EmployeesTabPanel from "./EmpolyeesTabPanel";
import PositionsTabPanel from "./PositionsTabPanel";
import LocationsTabPanel from "./LocationTabPanel";

const Laborcost = (props) => {
  const theme = useTheme();
  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const handleChangeIndex = (index) => {
    setValue(index);
  };

  return (
    <Box>
      <SubHeader
        heading={"Labor cost"}
        buttonText=""
        ButtonType="icon"
        icon={<SettingsOutlined />}
      />
      <br />
      <Tabs
        value={value}
        onChange={handleChange}
        indicatorColor="secondary"
        textColor="secondary"
        aria-label="wages category wise"
        sx={{
          backgroundColor: "white",
        }}
      >
        <Tab label="Employees" />
        <Tab label="Positions" />
        <Tab label="Locations" />
      </Tabs>

      <SwipeableViews
        axis={theme.direction === "rtl" ? "x-reverse" : "x"}
        index={value}
        onChangeIndex={handleChangeIndex}
      >
        <TabPanel value={value} index={0} dir={theme.direction}>
          <EmployeesTabPanel />
        </TabPanel>
        <TabPanel value={value} index={1} dir={theme.direction}>
          <PositionsTabPanel />
        </TabPanel>
        <TabPanel value={value} index={2} dir={theme.direction}>
          <LocationsTabPanel />
        </TabPanel>
      </SwipeableViews>
    </Box>
  );
};

export default Laborcost;
