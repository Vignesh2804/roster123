import React from "react";
import ReportTabs from "./ReportTabs";

const Reports = (props) => {
  return <ReportTabs />;
};

export default Reports;
