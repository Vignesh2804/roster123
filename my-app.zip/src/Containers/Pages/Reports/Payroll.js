import React from "react";
import CustomDataTable from "../../../Components/CustomDataTable";

const PayrollReport = (props) => {
  const PayrollColumns = [
    { field: "name", headerName: "Name", flex: 1 },
    { field: "position", headerName: "Position", flex: 1 },
    { field: "location", headerName: "Location", flex: 1 },
    { field: "rate", headerName: "Rate", flex: 1 },
    { field: "hours", headerName: "Hours", flex: 1 },
    { field: "regHours", headerName: "Reg. Hours", flex: 1 },
    { field: "otHours", headerName: "O/T. Hours", flex: 1 },
    { field: "subTotalWage", headerName: "Subtotal Wage", flex: 1 },
    { field: "totalWage", headerName: "Total Wage", flex: 1 },
    { field: "payTypes", headerName: "Pay Type", flex: 1 },
  ];

  const PayrollData = [
    {
      id: Math.random().toString(),
      name: "Vinoth",
      position: "Executive",
      location: "XYZ",
      rate: "40",
      hours: "9.00",
      regHours: "9.00",
      otHours: "",
      subTotalWage: "$360.00",
      totalWage: "$360.00",
      payTypes: "Hourly",
    },
    {
      id: Math.random().toString(),
      name: "Raju",
      position: "Sr Executive",
      location: "ABC",
      rate: "40",
      hours: "9.00",
      regHours: "9.00",
      otHours: "",
      subTotalWage: "$360.00",
      totalWage: "$360.00",
      payTypes: "Hourly",
    },
  ];

  return (
    <>
      <CustomDataTable
        title="Employees"
        columns={PayrollColumns}
        rows={PayrollData}
        elevation={6}
      />
    </>
  );
};

export default PayrollReport;
