import React from "react";
import CustomDataTable from "../../../Components/CustomDataTable";

const SalesReport = (props) => {
  const SalesColumns = [
    { field: "date", headerName: "Date", flex: 1 },
    { field: "projectedSales", headerName: "Projected Sales", flex: 1 },
    { field: "actualSales", headerName: "Actual Sales", flex: 1 },
    { field: "diffSales", headerName: "Diff Sales", flex: 1 },
    { field: "projectedLabor", headerName: "Projected Labor", flex: 1 },
    { field: "actualLabor", headerName: "Actual Labor", flex: 1 },
    { field: "diffLabor", headerName: "Diff Labor", flex: 1 },
  ];

  const SalesData = [
    {
      id: Math.random().toString(),
      date: "04-11-2021",
      projectedSales: "$40.00",
      actualSales: "$60.00",
      diffSales: "20.00",
      projectedLabor: "100%",
      actualLabor: "100%",
      diffLabor: "0%",
    },
  ];

  return (
    <>
      <CustomDataTable
        title="Employees"
        columns={SalesColumns}
        rows={SalesData}
        elevation={6}
      />
    </>
  );
};

export default SalesReport;
