import React from "react";
import CustomDataTable from "../../../Components/CustomDataTable";

const AttendanceReports = (props) => {
  const AttendanceColumns = [
    { field: "name", headerName: "Name", flex: 1 },
    { field: "empID", headerName: "Employee ID", flex: 1 },
    { field: "position", headerName: "Position", flex: 1 },
    { field: "location", headerName: "Location", flex: 1 },
    { field: "schShifts", headerName: "Sch. Shifts", flex: 1 },
    { field: "actShifts", headerName: "Act. Shifts", flex: 1 },
    { field: "schHours", headerName: "Sch. Hours", flex: 1 },
    { field: "actHours", headerName: "Act. Hours", flex: 1 },
    { field: "noShow", headerName: "No Show", flex: 1 },
    { field: "sickCallOut", headerName: "SickCallOut", flex: 1 },
  ];

  const AttendanceData = [
    {
      id: Math.random().toString(),
      name: "Vinoth",
      empId: "29283",
      position: "Executive",
      location: "XYZ",
      schShifts: "0",
      actShifts: "1",
      schHours: "8",
      actHours: "9",
      noShow: "$360.00",
      sickCallOut: "$360.00",
    },
    {
      id: Math.random().toString(),
      name: "Raju",
      empId: "31386",
      position: "Sr Executive",
      location: "ABC",
      schShifts: "0",
      actShifts: "1",
      schHours: "8",
      actHours: "9",
      noShow: "$360.00",
      sickCallOut: "$360.00",
    },
  ];

  return (
    <>
      <CustomDataTable
        title="Employees"
        columns={AttendanceColumns}
        rows={AttendanceData}
        elevation={6}
      />
    </>
  );
};

export default AttendanceReports;
