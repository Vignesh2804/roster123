import { Grid } from "@mui/material";
import React from "react";
import CustomDataTable from "../../../Components/CustomDataTable";
import { Bar } from "react-chartjs-2";

const LaborReport = (props) => {
  const LaborColumns = [
    { field: "name", headerName: "Name", flex: 1 },
    { field: "position", headerName: "Position", flex: 1 },
    { field: "location", headerName: "Location", flex: 1 },
    { field: "schHours", headerName: "SCH. Hours", flex: 1 },
    { field: "schShifts", headerName: "SCH. Shifts", flex: 1 },
    { field: "estHours", headerName: "EST. Cost", flex: 1 },
    { field: "actHours", headerName: "ACT. Hours", flex: 1 },
    { field: "actCost", headerName: "ACT. Cost", flex: 1 },
    { field: "payTypes", headerName: "Pay Type", flex: 1 },
  ];

  const LaborData = [
    {
      id: Math.random().toString(),
      name: "Vinoth",
      position: "Executive",
      location: "XYZ",
      schHours: "8",
      schShifts: "2",
      estHours: "8",
      actHours: "9",
      actCost: "$360",
      payTypes: "Hourly",
    },
    {
      id: Math.random().toString(),
      name: "Raju",
      position: "Sr Executive",
      location: "ABC",
      schHours: "8",
      schShifts: "2",
      estHours: "8",
      actHours: "9",
      actCost: "$360",
      payTypes: "Hourly",
    },
  ];

  const data = {
    labels: [""],
    datasets: [
      {
        label: "Est. Sales",
        data: [12],
        backgroundColor: "rgb(255, 99, 132)",
        stack: "Stack 0",
      },
      {
        label: "Est. Wages",
        data: [2],
        backgroundColor: "rgb(54, 162, 235)",
        stack: "Stack 1",
      },
      {
        label: "O/T",
        data: [3],
        backgroundColor: "rgb(75, 192, 192)",
        stack: "Stack 2",
      },
    ],
  };

  const hoursdata = {
    labels: [""],
    datasets: [
      {
        label: "Hours",
        data: [4],
        backgroundColor: "rgb(255, 99, 132)",
        stack: "Stack 0",
      },
      {
        label: "O/T Hours",
        data: [9],
        backgroundColor: "rgb(54, 162, 235)",
        stack: "Stack 1",
      },
    ],
  };

  const options = {
    scales: {
      yAxes: [
        {
          ticks: {
            beginAtZero: true,
          },
        },
      ],
    },
  };

  return (
    <>
      <CustomDataTable
        title="Employees"
        columns={LaborColumns}
        rows={LaborData}
        elevation={6}
      />
      <br />
      <Grid container spacing={2}>
        <Grid item xs={6}>
          <h4>Sales Vs Wages</h4>
          <Bar data={data} options={options} />
        </Grid>
        <Grid item xs={6}>
          <h4>Hours Vs O/T</h4>
          <Bar data={hoursdata} options={options} />
        </Grid>
      </Grid>
    </>
  );
};

export default LaborReport;
