import React from "react";
import CustomDataTable from "../../../Components/CustomDataTable";

const TimeoffReport = (props) => {
  const TimeoffColumn = [
    { field: "name", headerName: "Name", flex: 1 },
    { field: "type", headerName: "Type", flex: 1 },
    { field: "remaining", headerName: "Remaining", flex: 1 },
    { field: "approvedDays", headerName: "Approved Days", flex: 1 },
    { field: "unpaidDays", headerName: "Unpaid Days", flex: 1 },
    { field: "unpaidHours", headerName: "Unpaid Hours", flex: 1 },
    { field: "deniedDays", headerName: "Denied Days", flex: 1 },
    { field: "deniedHours", headerName: "Denied Hours", flex: 1 },
    { field: "cost", headerName: "Cost", flex: 1 },
    { field: "approvedHours", headerName: "Approved Hours", flex: 1 },
  ];

  const TimeoffData = [
    {
      id: Math.random().toString(),
      name: "Vinoth",
      type: "-",
      remaining: "24",
      approvedDays: "1",
      unpaidDays: "1",
      unpaidHours: "8",
      deniedDays: "0",
      deniedHours: "0",
      cost: "$0.00",
      approvedHours: "$8.00",
    },
    {
      id: Math.random().toString(),
      name: "Raju",
      empId: "31386",
      type: "-",
      remaining: "24",
      approvedDays: "1",
      unpaidDays: "1",
      unpaidHours: "8",
      deniedDays: "0",
      deniedHours: "0",
      cost: "$0.00",
      approvedHours: "$8.00",
    },
  ];

  return (
    <>
      <CustomDataTable
        title="Employees"
        columns={TimeoffColumn}
        rows={TimeoffData}
        elevation={6}
      />
    </>
  );
};

export default TimeoffReport;
