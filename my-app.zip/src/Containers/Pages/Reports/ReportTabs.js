import React, { useEffect, useState } from "react";
import SwipeableViews from "react-swipeable-views";
import TabPanel from "../../../Components/TabPanel";
import { useTheme } from "@mui/material/styles";
import {
  Tabs,
  Tab,
  Box,
  Button,
  Stack,
  Container,
  Typography,
  TextField,
  Paper,
  Tooltip,
  IconButton,
} from "@mui/material";

import { Edit, IosShare, Print, Settings } from "@mui/icons-material";

import ReportHeader from "../../../Components/ReportHeader";
import CustomPopover from "../../../Components/CustomPopover";
import LaborReport from "./Labor";
import PayrollReport from "./Payroll";
import AttendanceReports from "./Attendance";
import SalesReport from "./Sales";
import TimeoffReport from "./Timeoff";

const groupByOptions = [
  { label: "None", value: "none", defaultChecked: true },
  { label: "Status", value: "status" },
];

const LaborGroupByOptions = [
  { label: "Employees", value: "employees", defaultChecked: true },
  { label: "Positions", value: "positions" },
];

const filterOptions = [
  {
    name: "Locations",
    filters: [{ name: "xyz", label: "xyz" }],
  },
];

const LaborFilterOptions = [
  {
    name: "Locations",
    filters: [{ name: "xyz", label: "xyz" }],
  },
  {
    name: "Positions",
    filters: [
      { name: "srExecutive", label: "Senior Executive" },
      { name: "executive", label: "Executive" },
    ],
  },
  {
    name: "Groups",
    filters: [{ name: "hr", label: "HR" }],
  },
  {
    name: "Employees",
    filters: [{ name: "vinoth", label: "Vinoth S" }],
  },
  {
    name: "Pay Types",
    filters: [
      { name: "hourly", label: "Hourly Wage" },
      { name: "annual", label: "Annual Salary" },
    ],
  },
];

const AttendanceFilterOptions = [
  {
    name: "Locations",
    filters: [{ name: "xyz", label: "xyz" }],
  },
  {
    name: "Positions",
    filters: [
      { name: "srExecutive", label: "Senior Executive" },
      { name: "executive", label: "Executive" },
    ],
  },
  {
    name: "Groups",
    filters: [{ name: "hr", label: "HR" }],
  },
  {
    name: "Employees",
    filters: [{ name: "vinoth", label: "Vinoth S" }],
  },
];

const RenderFeedback = (props) => {
  const [feedback, setFeedback] = useState(null);

  const handleFeedbackChange = (e) => {
    setFeedback(e.target.value);
  };

  return (
    <Box sx={{ mt: "10px", p: "15px", width: "350px" }}>
      <Stack spacing={2}>
        <Typography variant="subtitle1">Feedback</Typography>
        <TextField
          id="feedback"
          label="Your Suggestions & feedback"
          multiline
          rows={4}
          value={feedback}
          onChange={handleFeedbackChange}
          variant="outlined"
        />
        <Button
          onClick={props.handleOpen}
          variant="contained"
          color={"secondary"}
          size="small"
        >
          Share
        </Button>
      </Stack>
    </Box>
  );
};

const ReportTabs = () => {
  const theme = useTheme();
  const [tabValue, setTabValue] = useState(0);

  //popper
  const [open, setOpen] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);

  const canBeOpen = open && Boolean(anchorEl);
  const id = canBeOpen ? "feedbackpopover" : undefined;

  const togglePopOver = (event) => {
    setAnchorEl(event.currentTarget);
    setOpen((previousOpen) => !previousOpen);
  };
  //

  const handleChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const handleChangeIndex = (index) => {
    setTabValue(index);
  };

  return (
    <Box>
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "flex-start",
        }}
        component={Paper}
      >
        <Box>
          <Tabs
            value={tabValue}
            onChange={handleChange}
            indicatorColor="secondary"
            textColor="secondary"
            sx={{
              backgroundColor: "white",
            }}
          >
            <Tab label="Labor" />
            <Tab label="Payroll" />
            <Tab label="Attendance" />
            <Tab label="Time off" />
            <Tab label="Sales" />
          </Tabs>
        </Box>
        <Box sx={{ marginLeft: "auto" }}>
          <Stack spacing={2} direction="row">
            <Button
              variant="contained"
              endIcon={<Edit />}
              color="nuetral"
              onClick={togglePopOver}
            >
              Share Feedback
            </Button>

            <Box>
              <Stack
                spacing={2}
                direction="row"
                sx={{ border: "dashed 1px gainsboro", mt: "2px" }}
              >
                <Tooltip title="Export">
                  <IconButton>
                    <IosShare />
                  </IconButton>
                </Tooltip>
                {tabValue !== 4 && (
                  <Tooltip title="Print">
                    <IconButton>
                      <Print />
                    </IconButton>
                  </Tooltip>
                )}
                {tabValue === 4 && (
                  <Tooltip title="Import">
                    <IconButton>
                      <IosShare style={{ transform: "rotate(180deg)" }} />
                    </IconButton>
                  </Tooltip>
                )}
                <Tooltip title="Settings">
                  <IconButton>
                    <Settings />
                  </IconButton>
                </Tooltip>
              </Stack>
            </Box>
          </Stack>
        </Box>
      </Box>

      <Box
        sx={{
          borderRadius: "5px",
          padding: "10px",
          backgroundColor: "white",
          mt: "2px",
        }}
      >
        <ReportHeader
          groupBy={
            tabValue === 0 || tabValue === 1
              ? LaborGroupByOptions
              : groupByOptions
          }
          filters={
            tabValue === 0 || tabValue === 1
              ? LaborFilterOptions
              : tabValue === 2
              ? AttendanceFilterOptions
              : filterOptions
          }
        />
      </Box>

      <SwipeableViews
        axis={theme.direction === "rtl" ? "x-reverse" : "x"}
        index={tabValue}
        onChangeIndex={handleChangeIndex}
      >
        <TabPanel value={tabValue} index={0} dir={theme.direction}>
          <LaborReport />
        </TabPanel>
        <TabPanel value={tabValue} index={1} dir={theme.direction}>
          <PayrollReport />
        </TabPanel>
        <TabPanel value={tabValue} index={2} dir={theme.direction}>
          <AttendanceReports />
        </TabPanel>
        <TabPanel value={tabValue} index={3} dir={theme.direction}>
          <TimeoffReport />
        </TabPanel>
        <TabPanel value={tabValue} index={4} dir={theme.direction}>
          <SalesReport />
        </TabPanel>
      </SwipeableViews>

      {open && (
        <CustomPopover
          open={open}
          anchorEl={anchorEl}
          id={id}
          handleClose={togglePopOver}
          anchorOrigin={{
            vertical: "bottom",
            horizontal: "left",
          }}
          transformOrigin={{
            vertical: "top",
            horizontal: "right",
          }}
        >
          <RenderFeedback handleOpen={togglePopOver} />
        </CustomPopover>
      )}
    </Box>
  );
};

export default ReportTabs;
