import React, { Component } from "react";

/** * Import Layouts ** */
import HeaderArea from "./Header";

class Layout extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  render() {
    return (
      <div className="App">
        <HeaderArea />

        {this.props.children}
      </div>
    );
  }
}

export default Layout;
