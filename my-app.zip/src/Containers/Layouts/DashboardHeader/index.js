import { Container, Grid } from "@mui/material";
import React, { useEffect, useState } from "react";
import {
  DashboardOutlined,
  AccountCircleOutlined,
  LocationSearchingRounded,
  AttributionOutlined,
  LocalOfferOutlined,
  AnnouncementOutlined,
  AttachMoneyOutlined,
  GroupsOutlined,
} from "@mui/icons-material";
import TabCard from "../../../Components/TabCard";
import { useHistory } from "react-router";

const DashboardHeader = (props) => {
  const history = useHistory();

  const [cardValue, setCardValue] = useState(history.location.pathname);
  const [dashboardActive, setDashboardActive] = useState(false);
  const [employeesActive, setEmployeesActive] = useState(false);
  const [positionsActive, setPositionsActive] = useState(false);
  const [locationsActive, setLocationsActive] = useState(false);
  const [groupsActive, setGroupsActive] = useState(false);
  const [tagsActive, setTagsActive] = useState(false);
  const [announcementsActive, setAnnouncementsActive] = useState(false);
  const [laborcostActive, setLaborcostActive] = useState(false);

  useEffect(() => {
    setActiveCard(
      history.location.pathname ? history.location.pathname : "/dashboard"
    );
  });

  const handleCardChange = (newValue) => {
    setCardValue(newValue);
    setActiveCard(newValue);
    history.push(newValue);
  };

  const setActiveCard = (newValue) => {
    if (newValue === "/dashboard") {
      setDashboardActive(true);
      setEmployeesActive(false);
      setPositionsActive(false);
      setLocationsActive(false);
      setGroupsActive(false);
      setTagsActive(false);
      setAnnouncementsActive(false);
      setLaborcostActive(false);
    } else if (newValue === "/dashboard/employees") {
      setDashboardActive(false);
      setEmployeesActive(true);
      setPositionsActive(false);
      setLocationsActive(false);
      setGroupsActive(false);
      setTagsActive(false);
      setAnnouncementsActive(false);
      setLaborcostActive(false);
    } else if (newValue === "/dashboard/positions") {
      setDashboardActive(false);
      setEmployeesActive(false);
      setPositionsActive(true);
      setLocationsActive(false);
      setGroupsActive(false);
      setTagsActive(false);
      setAnnouncementsActive(false);
      setLaborcostActive(false);
    } else if (newValue === "/dashboard/locations") {
      setDashboardActive(false);
      setEmployeesActive(false);
      setPositionsActive(false);
      setLocationsActive(true);
      setGroupsActive(false);
      setTagsActive(false);
      setAnnouncementsActive(false);
      setLaborcostActive(false);
    } else if (newValue === "/dashboard/groups") {
      setDashboardActive(false);
      setEmployeesActive(false);
      setPositionsActive(false);
      setLocationsActive(false);
      setGroupsActive(true);
      setTagsActive(false);
      setAnnouncementsActive(false);
      setLaborcostActive(false);
    } else if (newValue === "/dashboard/tags") {
      setDashboardActive(false);
      setEmployeesActive(false);
      setPositionsActive(false);
      setLocationsActive(false);
      setGroupsActive(false);
      setTagsActive(true);
      setAnnouncementsActive(false);
      setLaborcostActive(false);
    } else if (newValue === "/dashboard/announcements") {
      setDashboardActive(false);
      setEmployeesActive(false);
      setPositionsActive(false);
      setLocationsActive(false);
      setGroupsActive(false);
      setTagsActive(false);
      setAnnouncementsActive(true);
      setLaborcostActive(false);
    } else if (newValue === "/dashboard/laborcost") {
      setDashboardActive(false);
      setEmployeesActive(false);
      setPositionsActive(false);
      setLocationsActive(false);
      setGroupsActive(false);
      setTagsActive(false);
      setAnnouncementsActive(false);
      setLaborcostActive(true);
    }
  };

  return (
    <Container component="main">
      <Grid container spacing={1} sx={{ mt: 2 }}>
        <Grid item xs={12} container spacing={1}>
          <Grid
            item
            xs={12}
            md={3}
            sx={{
              display: "flex",
              direction: "column",
              alignItems: "center",
              justifyContent: "center",
            }}
            onClick={() => handleCardChange("/dashboard")}
          >
            <TabCard
              lbl="DASHBOARD"
              icon={<DashboardOutlined fontSize="large" />}
              active={dashboardActive}
            />
          </Grid>
          <Grid
            item
            xs={12}
            md={3}
            sx={{
              display: "flex",
              direction: "column",
              alignItems: "center",
              justifyContent: "center",
            }}
            onClick={() => handleCardChange("/dashboard/employees")}
          >
            <TabCard
              lbl="EMPLOYEES"
              icon={<AccountCircleOutlined fontSize="large" />}
              active={employeesActive}
            />
          </Grid>
          <Grid
            item
            xs={12}
            md={3}
            sx={{
              display: "flex",
              direction: "column",
              alignItems: "center",
              justifyContent: "center",
            }}
            onClick={() => handleCardChange("/dashboard/positions")}
            to="/dashboard/positionslist"
          >
            <TabCard
              lbl="POSITIONS"
              icon={<AttributionOutlined fontSize="large" />}
              active={positionsActive}
            />
          </Grid>
          <Grid
            item
            xs={12}
            md={3}
            sx={{
              display: "flex",
              direction: "column",
              alignItems: "center",
              justifyContent: "center",
            }}
            onClick={() => handleCardChange("/dashboard/locations")}
            to="/locations"
          >
            <TabCard
              lbl="LOCATIONS"
              icon={<LocationSearchingRounded fontSize="large" />}
              active={locationsActive}
            />
          </Grid>
          <Grid
            item
            xs={12}
            md={3}
            sx={{
              display: "flex",
              direction: "column",
              alignItems: "center",
              justifyContent: "center",
            }}
            onClick={() => handleCardChange("/dashboard/groups")}
            to="/groups"
          >
            <TabCard
              lbl="GROUPS"
              icon={<GroupsOutlined fontSize="large" />}
              active={groupsActive}
            />
          </Grid>
          <Grid
            item
            xs={12}
            md={3}
            sx={{
              display: "flex",
              direction: "column",
              alignItems: "center",
              justifyContent: "center",
            }}
            onClick={() => handleCardChange("/dashboard/tags")}
            to="/tags"
          >
            <TabCard
              lbl="TAGS"
              icon={<LocalOfferOutlined fontSize="large" />}
              active={tagsActive}
            />
          </Grid>
          <Grid
            item
            xs={12}
            md={3}
            sx={{
              display: "flex",
              direction: "column",
              alignItems: "center",
              justifyContent: "center",
            }}
            onClick={() => handleCardChange("/dashboard/announcements")}
            to="/announcements"
          >
            <TabCard
              lbl="ANNOUNCEMENTS"
              icon={<AnnouncementOutlined fontSize="large" />}
              active={announcementsActive}
            />
          </Grid>
          <Grid
            item
            xs={12}
            md={3}
            sx={{
              display: "flex",
              direction: "column",
              alignItems: "center",
              justifyContent: "center",
            }}
            onClick={() => handleCardChange("/dashboard/laborcost")}
            to="/laborcost"
          >
            <TabCard
              lbl="LABOR COST"
              icon={<AttachMoneyOutlined fontSize="large" />}
              active={laborcostActive}
            />
          </Grid>
        </Grid>
        <Grid item xs={12}>
          {props.children}
        </Grid>
      </Grid>
    </Container>
  );
};

export default DashboardHeader;
