import * as React from "react";
import HeaderAppBar from "../../../Components/AppBar";

const HeaderArea = (props) => {
  return <HeaderAppBar />;
};

export default HeaderArea;
