import React, { Component } from "react";
// Import Router History And Link
import { Link } from "react-router-dom";
import History from "../../../utils/history";

class MainMenu extends Component {
  constructor(props) {
    super(props);
    this.state = {
      menu: [],
    };
  }

  componentDidMount() {
    const auth = JSON.parse(localStorage.getItem("auth"));
    // console.log(auth.menu)
    // User Roles Based Created Menu
    if (auth !== undefined && auth !== null) {
      this.setState({
        //menu: auth.menu
        menu: [
          {
            roles: [],
            _id: "1",
            menuName: "Dashboard",
            url: "/dashboard",
            enabled: true,
            icon: "dashboard_menu_icon",
            menuId: 1,
            pId: 0,
            subItem: [],
          },
          {
            roles: [],
            _id: "2",
            menuName: "Chat",
            url: "/chat",
            enabled: true,
            icon: "chat_menu_icon",
            menuId: 2,
            pId: 0,
            subItem: [],
          },
          {
            roles: [],
            _id: "3",
            menuName: "History",
            url: "/reports",
            enabled: true,
            icon: "history_menu_icon",
            menuId: 3,
            pId: 0,
            subItem: [],
          },
          {
            roles: [],
            _id: "4",
            menuName: "Withdrawal",
            url: "/withdraw",
            enabled: true,
            icon: "withdraw_menu_icon",
            menuId: 4,
            pId: 0,
            subItem: [],
          },
          {
            roles: [],
            _id: "5",
            menuName: "Profile",
            url: "/profile",
            enabled: true,
            icon: "profile_menu_icon",
            menuId: 5,
            pId: 0,
            subItem: [],
          },
          {
            roles: [],
            _id: "6",
            menuName: "Close Account",
            url: "/dashboard",
            enabled: true,
            icon: "closeaccount_menu_icon",
            menuId: 6,
            pId: 0,
            subItem: [],
          },
        ],
      });
    } else {
      // If auth is faild going to login
      History.push("login");
    }
  }

  firstLater(data) {
    if (data) {
      let str = data;
      let matches = str.match(/\b(\w)/g);
      let acronym = matches.join("");
      return acronym;
    }
  }

  render() {
    let activeURL = History.location.pathname;
    return (
      <aside className="main-sidebar sidebar-dark-primary elevation-4">
        <Link to="#" className="brand-link">
          <img
            src="/img/logo.png"
            className="menu_logo_lg"
            alt="African Doller Logo"
          />
          <img
            src="/img/logo_ad.png"
            className="menu_logo_sm"
            alt="African Doller Logo"
          />
          <p id="qa_gold_digital_cur_plt_rm">Gold Digital Currency Platform</p>
        </Link>
        <div className="sidebar">
          <nav className="mt-2">
            <ul
              className="nav nav-pills nav-sidebar flex-column pb-3"
              data-widget="treeview"
              role="menu"
              data-accordion="false"
            >
              <li className="nav-header" id="qa_main_menu">
                MAIN MENU
              </li>
              {this.state.menu !== undefined &&
                this.state.menu !== null &&
                this.state.menu.length > 0 &&
                this.state.menu.map((data, key) => {
                  return (
                    <li className="nav-item has-treeview pl-2" key={key}>
                      <Link
                        to={{
                          pathname: data.url,
                          state:
                            data._id === "6"
                              ? { data: { closeAccount: true } }
                              : { data: {} },
                        }}
                        className={
                          data.url === activeURL && data._id !== "6"
                            ? "nav-link active"
                            : "nav-link"
                        }
                      >
                        <span className={data.icon}></span>
                        <p id={data._id}>
                          {data.menuName}
                          {data.subItem.length > 0 && (
                            <i className="fas fa-caret-down right"></i>
                          )}
                        </p>
                      </Link>
                      {data.subItem.length > 0 && (
                        <ul className="nav nav-treeview">
                          {data.subItem !== undefined &&
                            data.subItem !== null &&
                            data.subItem.length > 0 &&
                            data.subItem.map((val, id) => {
                              return (
                                <li className="nav-item" key={id}>
                                  <Link
                                    to={val.url}
                                    className={
                                      val.url === activeURL
                                        ? "nav-link active"
                                        : "nav-link"
                                    }
                                  >
                                    <i className="first_later">
                                      {this.firstLater(val.menuName)}
                                    </i>
                                    <p id={val._id}>{val.menuName}</p>
                                  </Link>
                                </li>
                              );
                            })}
                        </ul>
                      )}
                    </li>
                  );
                })}
            </ul>

            <ul
              className="nav nav-pills nav-sidebar flex-column pl-3"
              data-widget="treeview"
              role="menu"
              data-accordion="false"
            >
              <li
                className="nav-item has-treeview border-top-white pt-5"
                id="qa_others"
              ></li>
              <li className="nav-item has-treeview">
                <Link to="#" className="nav-link">
                  <p>FAQ</p>
                </Link>
              </li>
              <li className="nav-item has-treeview">
                <Link to="#" className="nav-link">
                  <p className="opc8">About</p>
                </Link>
              </li>
              <li className="nav-item has-treeview">
                <Link to="#" className="nav-link">
                  <p className="opc8">Contact</p>
                </Link>
              </li>
              <li className="nav-item has-treeview">
                <Link to="#" className="nav-link">
                  <p className="opc8">Privacy Policy</p>
                </Link>
              </li>
              <li className="nav-item has-treeview">
                <Link to="#" className="nav-link">
                  <p className="opc8">Terms & Conditions</p>
                </Link>
              </li>
            </ul>
          </nav>
        </div>
        <div>
          <p className="menu_cp" id="qa_african_dollar">
            © 2020 African Dollar
          </p>
        </div>
      </aside>
    );
  }
}

export default MainMenu;
