import { Grid, Button } from "@mui/material";
import React from "react";
import CustomAnchor from "../../../Components/CustomAnchor";

const SettingsLayout = (props) => {
  return (
    <Grid component="main" container spacing={2}>
      <Grid item xs={12} md={2} sx={{ textAlign: "left" }}>
        {props.anchors.map((anchor, index) => (
          <CustomAnchor key={index} label={anchor.label} value={anchor.value} />
        ))}
      </Grid>
      <Grid
        item
        xs={12}
        md={10}
        sx={{
          textAlign: "left",
          height: "72vh",
          overflow: "auto",
        }}
        container
      >
        {props.contents}
      </Grid>

      <Grid item xs={12} sm={6}>
        <Button
          fullWidth
          variant="contained"
          sx={{ mt: 3, mb: 2, backgroundColor: "#616161" }}
        >
          Cancel
        </Button>
      </Grid>

      <Grid item xs={12} sm={6}>
        <Button
          type="submit"
          fullWidth
          variant="contained"
          sx={{ mt: 3, mb: 2 }}
          color={"secondary"}
        >
          Save
        </Button>
      </Grid>
    </Grid>
  );
};

export default SettingsLayout;
