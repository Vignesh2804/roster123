import React, { useEffect, useState } from "react";
import { Editor } from "react-draft-wysiwyg";
import { EditorState, convertToRaw } from "draft-js";
import "react-draft-wysiwyg/dist/react-draft-wysiwyg.css"; // eslint-disable-line no-unused-vars
import styles from "./CommentSection.module.css";
import {
  Button,
  Box,
  Typography,
  Avatar,
  Divider,
  Tooltip,
} from "@mui/material";
import draftToHtml from "draftjs-to-html";
import { Edit, Delete, ThumbUp } from "@mui/icons-material";

const SendButton = ({ onSave }) => {
  const handlePostClick = () => {
    onSave();
  };
  return (
    <Button
      type="submit"
      variant="contained"
      color={"secondary"}
      size="small"
      onClick={handlePostClick}
      sx={{ height: "32px" }}
    >
      Send
    </Button>
  );
};

const CommentSection = () => {
  const [editorState, setEditorState] = useState(EditorState.createEmpty());
  const [htmlContent, setHtmlContent] = useState(null);
  const [comments, setComments] = useState([]);
  const [like, setLike] = useState(false);

  useEffect(() => {
    if (editorState) {
      setHtmlContent(
        draftToHtml(convertToRaw(editorState.getCurrentContent()))
      );
    }
  }, [editorState]);

  const handleEditorStateChange = (value) => {
    setEditorState(value);
  };

  const handleSendButton = () => {
    setComments([...comments, htmlContent]);
    setEditorState(EditorState.createEmpty());
  };

  const handleLikeClick = () => {
    setLike((prevValue) => !prevValue);
  };

  return (
    <>
      {comments &&
        comments.length > 0 &&
        comments.map((content, index) => (
          <Box sx={{ p: "10px", pl: "20px", m: "10px" }} key={index}>
            <Box sx={{ display: "flex" }}>
              <Avatar>
                <Typography variant="body1">E1</Typography>
              </Avatar>
              <Box sx={{ pl: "10px", textAlign: "left" }}>
                <Box sx={{ display: "flex" }}>
                  <Typography
                    variant="body1"
                    sx={{ color: "blue", pr: "20px" }}
                  >
                    Employee{" "}
                  </Typography>
                  <Edit
                    sx={{
                      height: "18px",
                      width: "18px",
                      color: "gray",
                      cursor: "pointer",
                    }}
                  />
                  <Delete
                    sx={{
                      height: "18px",
                      width: "18px",
                      color: "gray",
                      cursor: "pointer",
                    }}
                  />
                </Box>
                <Box sx={{ display: "flex" }}>
                  <Typography variant="caption" sx={{ pr: "15px" }}>
                    Oct 21, 2021 @ 3:53 PM
                  </Typography>
                  <Tooltip title="Like">
                    <ThumbUp
                      color={like ? "primary" : "none"}
                      onClick={handleLikeClick}
                      sx={{ cursor: "pointer", height: "16px", width: "16px" }}
                    />
                  </Tooltip>
                  {like && (
                    <Typography variant="caption" sx={{ pl: "10px" }}>
                      1
                    </Typography>
                  )}
                </Box>
              </Box>
            </Box>

            <div
              dangerouslySetInnerHTML={{ __html: content }}
              style={{ textAlign: "left", paddingLeft: "50px" }}
            ></div>

            <Divider />
          </Box>
        ))}

      <Box className={styles.root}>
        <Editor
          editorState={editorState}
          toolbarClassName={styles.toolbar}
          wrapperClassName={styles.wrapper}
          editorClassName={styles.editor}
          toolbar={{
            options: ["link", "emoji"],

            link: {
              options: ["link"],
            },
          }}
          toolbarCustomButtons={[<SendButton onSave={handleSendButton} />]}
          onEditorStateChange={handleEditorStateChange}
        />
      </Box>
    </>
  );
};

export default CommentSection;
