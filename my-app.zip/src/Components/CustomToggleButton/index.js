import { ToggleButton, ToggleButtonGroup } from "@mui/material";
import React from "react";
import styles from "./CustomToggleButton.module.css";

const CustomToggleButton = (props) => {
  return (
    <ToggleButtonGroup
      value={props.value}
      exclusive={props.exclusive}
      onChange={props.onChange}
      color={props.color}
      size={props.size}
    >
      {props.buttonList.map((btn, index) => (
        <ToggleButton
          key={index}
          value={btn.value}
          className={styles.toggleButtons}
        >
          {btn.label}
        </ToggleButton>
      ))}
    </ToggleButtonGroup>
  );
};

export default CustomToggleButton;
