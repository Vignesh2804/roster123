import React, { useState, useEffect } from "react";
import {
  Checkbox,
  Grid,
  Box,
  FormControl,
  Select,
  MenuItem,
  Stack,
  TextField,
  InputLabel,
  Button,
  Divider,
} from "@mui/material";
import {
  CreateOutlined,
  DeleteOutlined,
  FileCopyOutlined,
  ArrowLeftOutlined,
  ArrowRightOutlined,
  FilterList,
} from "@mui/icons-material";
import DatePicker from "@mui/lab/DatePicker";
import styles from "./ReportHeader.module.css";
import CustomFilter from "../CustomFilter";

const ReportHeader = (props) => {
  const [scheduleMode, setScheduleMode] = useState("d");
  const [showEditOptions, setShowEditOptions] = useState(false);
  const [dateValue, setDateValue] = useState(new Date());
  const [groupBy, setGroupBy] = useState("");
  const [sortBy, setSortBy] = useState("");
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    if (props.sortBy) {
      let defaultSelected = props.sortBy.filter(
        (sort) => sort.defaultChecked === true
      );

      setSortBy(defaultSelected[0].value);
    }
  }, [props.sortBy]);

  useEffect(() => {
    if (props.groupBy) {
      let defaultSelected = props.groupBy.filter(
        (sort) => sort.defaultChecked === true
      );

      setGroupBy(defaultSelected[0].value);
    }
  }, [props.groupBy]);

  const checkBoxClickHandler = () => {
    setShowEditOptions(!showEditOptions);
  };

  const handleFilterShow = () => {
    setShowFilters(!showFilters);
  };

  return (
    <Grid container spacing={2} sx={{ padding: "5px" }}>
      <Grid item xs={6}>
        <Stack direction="row" spacing={2}>
          <Checkbox
            color="primary"
            inputProps={{ "aria-label": "primary checkbox" }}
            onClick={checkBoxClickHandler}
            sx={{
              border: "solid 1px gainsboro",
              borderRadius: "5px",
              height: "56px",
            }}
          />

          {showEditOptions && (
            <Box
              sx={{
                border: "solid 1px gainsboro",
                padding: "5px",
                borderRadius: "5px",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                width: "150px",
              }}
              hidden={showEditOptions}
            >
              <CreateOutlined />
              <FileCopyOutlined fontSize="small" />
              <DeleteOutlined />
            </Box>
          )}

          <Box sx={{ display: "flex" }}>
            <Box
              sx={{
                border: "solid 1px gainsboro",
                borderRadiu: "5px",
                width: "42px",
                height: "56px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <ArrowLeftOutlined />
            </Box>
            <Box
              sx={{
                border: "solid 1px gainsboro",
                borderRadiu: "5px",
                width: "42px",
                height: "56px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
              bordmerRadius={2}
            >
              <ArrowRightOutlined />
            </Box>
          </Box>
          <FormControl>
            <Select
              id="demo-simple-select-helper"
              value={scheduleMode}
              variant="outlined"
            >
              <MenuItem value="d">Day</MenuItem>
              <MenuItem value="w">Week</MenuItem>
              <MenuItem value="m">Month</MenuItem>
              <MenuItem value="c">Custom</MenuItem>
            </Select>
          </FormControl>
          <DatePicker
            label="select date"
            value={dateValue}
            onChange={(newValue) => {
              setDateValue(newValue);
            }}
            renderInput={(params) => <TextField {...params} />}
          />
        </Stack>
      </Grid>
      <Grid
        item
        xs={6}
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "right",
        }}
      >
        <Stack direction="row" spacing={2}>
          {props.sortBy && props.sortBy.length > 0 && (
            <FormControl>
              <InputLabel id="sortby-label">Sort By</InputLabel>
              <Select
                id="sortby"
                value={sortBy}
                variant="outlined"
                label="Sort By"
                labelId="sortby-label"
              >
                {props.sortBy.map((sort) => (
                  <MenuItem key={sort.label} value={sort.value}>
                    {sort.label}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          )}

          {props.groupBy && props.groupBy.length > 0 && (
            <FormControl>
              <InputLabel id="groupby-label">Group By</InputLabel>
              <Select
                id="groupby"
                value={groupBy}
                variant="outlined"
                label="Group By"
                labelId="groupby-label"
              >
                {props.groupBy.map((group) => (
                  <MenuItem key={group.label} value={group.value}>
                    {group.label}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          )}

          <Button
            variant="outlined"
            startIcon={<FilterList />}
            onClick={handleFilterShow}
          >
            Filters
          </Button>
        </Stack>
      </Grid>
      {showFilters && (
        <>
          <Grid item xs={12}>
            {" "}
            <Divider />
          </Grid>
          <Grid
            item
            xs={12}
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "flex-start",
            }}
          >
            <CustomFilter filters={props.filters} />
          </Grid>
        </>
      )}
    </Grid>
  );
};

export default ReportHeader;
