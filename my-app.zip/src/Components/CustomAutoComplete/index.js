import * as React from "react";
import TextField from "@mui/material/TextField";
import Autocomplete, { createFilterOptions } from "@mui/material/Autocomplete";

const filter = createFilterOptions();

export default function CustomAutoComplete(props) {
  const handleFilterOptions = (options, params) => {
    const filtered = filter(options, params);

    const { inputValue } = params;
    // Suggest the creation of a new value
    const isExisting = options.some((option) => inputValue === option.label);
    if (inputValue !== "" && !isExisting) {
      filtered.push({
        inputValue,
        label: `Add "${inputValue}"`,
      });
    }

    return filtered;
  };

  const handleOptionLables = (option) => {
    // Value selected with enter, right from the input
    if (typeof option === "string") {
      return option;
    }
    // Add "xxx" option created dynamically
    if (option.inputValue) {
      return option.inputValue;
    }
    // Regular option
    return option.label;
  };

  const handleRenderOptions = (props, option) => (
    <li {...props}>{option.label}</li>
  );

  const handleRenderInput = (params) => (
    <TextField {...params} label={props.inputLabel} />
  );
  return (
    <Autocomplete
      multiple={props.multiple}
      onChange={props.onChange}
      filterOptions={handleFilterOptions}
      selectOnFocus
      clearOnBlur
      handleHomeEndKeys
      id={props.id}
      options={props.options}
      getOptionLabel={handleOptionLables}
      renderOption={handleRenderOptions}
      renderInput={handleRenderInput}
      groupBy={props.groupBy}
      sx={{ textAlign: "left" }}
    />
  );
}
