import { FormControl, FormHelperText, MenuItem, Select } from "@mui/material";
import React from "react";

const TimeFormat = (props) => {
  return (
    <FormControl fullWidth>
      <Select
        id={props.id}
        value={props.value}
        label={props.value}
        onChange={props.onChange}
        name={props.name}
      >
        <MenuItem value={"12"} name="12hr">
          12 Hr
        </MenuItem>
        <MenuItem value={"24"} name="14hr">
          24 Hr
        </MenuItem>
      </Select>
      <FormHelperText>{props.helperText}</FormHelperText>
    </FormControl>
  );
};

export default TimeFormat;
