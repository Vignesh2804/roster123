import React from "react";
import { Box, Stack } from "@mui/material";

const ShiftAppearance = (props) => {
  const Time = "10:00 AM - 06:00 PM";
  const Duration = "8h";
  const Position = "Manager";
  const Location = "ABC";
  const Tag = "Tags";
  const Asignee = "John Smith";

  return (
    <Box
      component="main"
      sx={{
        border: "solid 1px gray",
        backgroundColor: "rgba(0, 140, 255, 0.966);",
        color: "white",
        padding: "5px",
        textAlign: "left",
      }}
    >
      <Stack>
        <Box>
          <p
            style={{
              border: "dashed 2px white",
              margin: "5px",
              paddingLeft: "10px",
              borderRadius: "5px",
            }}
          >
            <span>{Time}</span> <span style={{ fontSize: "18px" }}>::</span>{" "}
            <span>{Duration}</span>
          </p>
        </Box>
        <Box>
          <p
            style={{
              border: "dashed 2px white",
              margin: "5px",
              paddingLeft: "10px",
              borderRadius: "5px",
            }}
          >
            <span>{Position}</span> <span style={{ fontSize: "18px" }}>::</span>{" "}
            <span>{Location}</span>
          </p>
        </Box>
        <Box>
          <p
            style={{
              border: "dashed 2px white",
              margin: "5px",
              paddingLeft: "10px",
              borderRadius: "5px",
            }}
          >
            <span>{Tag}</span>
            {props.view !== "month" && (
              <>
                <span style={{ fontSize: "18px" }}>::</span>{" "}
                <span>{Asignee} </span>
              </>
            )}
          </p>
        </Box>

        {props.view === "month" && (
          <Box>
            <p
              style={{
                border: "dashed 2px white",
                margin: "5px",
                paddingLeft: "10px",
                borderRadius: "5px",
              }}
            >
              <span>{Asignee}</span>
            </p>
          </Box>
        )}
      </Stack>
    </Box>
  );
};

export default ShiftAppearance;
