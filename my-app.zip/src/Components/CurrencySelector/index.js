import * as React from "react";

import CurrencyList from "../../Helpers/currencies";
import { FormControl, MenuItem, Select } from "@mui/material";

export default function CurrencySelector(props) {
  return (
    <FormControl fullWidth>
      <Select
        id={props.id}
        value={props.value}
        onChange={props.onChange}
        name={props.name}
        size={props.size}
      >
        {CurrencyList.map((currency, index) => (
          <MenuItem
            key={index}
            value={currency.code}
          >{`${currency.name} - ${currency.code}`}</MenuItem>
        ))}
      </Select>
    </FormControl>
  );
}
