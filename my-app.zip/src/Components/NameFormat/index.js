import { FormControl, FormHelperText, MenuItem, Select } from "@mui/material";
import React from "react";

const NameFormat = (props) => {
  return (
    <FormControl fullWidth>
      <Select
        id={props.id}
        value={props.value}
        label={props.label}
        onChange={props.onChange}
        name={props.name}
      >
        <MenuItem value={"fnf"}>Firstname first</MenuItem>
        <MenuItem value={"lnf"}>Lastname first</MenuItem>
      </Select>
      <FormHelperText>{props.helperText}</FormHelperText>
    </FormControl>
  );
};

export default NameFormat;
