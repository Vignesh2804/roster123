import React from "react";
import { FormControl, MenuItem, Select } from "@mui/material";

const ClockRoundTimeSelector = (props) => {
  return (
    <FormControl fullWidth>
      <Select
        id={props.id}
        value={props.value}
        onChange={props.onChange}
        name={props.name}
        size={props.size}
      >
        <MenuItem value={"00"}>No Roundings</MenuItem>
        <MenuItem value={"15"}>15 minutes</MenuItem>
        <MenuItem value={"20"}>20 minutes</MenuItem>
        <MenuItem value={"30"}>30 minutes</MenuItem>
      </Select>
    </FormControl>
  );
};

export default ClockRoundTimeSelector;
