import React from "react";
import { DataGrid, GridToolbar } from "@mui/x-data-grid";
import Styles from "./CustomDataTable.module.css";
import { Box, Paper } from "@mui/material";

const CustomDataTable = (props) => {
  return (
    // <div style={{ height: 500, width: "100%" }}>
    <Box
      component={Paper}
      sx={{ height: "400px", backgroundColor: "transparent" }}
      elevation={6}
    >
      <DataGrid
        columns={props.columns}
        rows={props.rows}
        checkboxSelection={props.checkboxNeeded}
        classes={{
          root: Styles.root,
          cell: Styles.cell,
          columnHeader: Styles.columnHeader,
        }}
        disableSelectionOnClick
      />
    </Box>
    // </div>
  );
};

export default CustomDataTable;
