import React from "react";

const CustomAnchor = (props) => {
  return (
    <>
      <a
        href={`#${props.value}`}
        onClick={(e) => {
          e.preventDefault();
          document.querySelector(`#${props.value}`).scrollIntoView({
            behavior: "smooth",
          });
        }}
      >
        {props.label}
      </a>
      <br />
    </>
  );
};

export default CustomAnchor;
