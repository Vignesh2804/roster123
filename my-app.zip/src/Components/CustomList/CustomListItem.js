import { Close } from "@mui/icons-material";
import { ListItem, ListItemAvatar, ListItemText } from "@mui/material";

import Styles from "./CustomList.module.css";

const CustomListItem = (props) => {
  return (
    <ListItem sx={{ width: "100%", p: "15px" }} className={Styles.listItem}>
      {props.icon && (
        <ListItemAvatar>
          <div className={Styles.avatar}>{props.icon}</div>
        </ListItemAvatar>
      )}
      <ListItemText
        primary={props.primaryText}
        secondary={props.secondaryText}
      />
      <Close />
    </ListItem>
  );
};

export default CustomListItem;
