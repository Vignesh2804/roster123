import { List } from "@mui/material";
import CustomListItem from "./CustomListItem";

const CustomList = (props) => {
  return (
    <List sx={{ width: "100%" }}>
      {props.items.map((item) => (
        <CustomListItem
          key={item.id}
          icon={item.icon}
          primaryText={item.message}
          secondaryText={item.secondartyText}
        />
      ))}
    </List>
  );
};

export default CustomList;
