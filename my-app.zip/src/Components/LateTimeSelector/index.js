import { FormControl, MenuItem, Select } from "@mui/material";
import React from "react";

const LateTimeSelector = (props) => {
  return (
    <FormControl fullWidth>
      <Select
        id={props.id}
        value={props.value}
        onChange={props.onChange}
        name={props.name}
        size={props.size}
      >
        <MenuItem value={"15"}>15 minutes</MenuItem>
        <MenuItem value={"20"}>20 minutes</MenuItem>
        <MenuItem value={"30"}>30 minutes</MenuItem>
      </Select>
    </FormControl>
  );
};

export default LateTimeSelector;
