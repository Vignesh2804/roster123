import * as React from "react";

import { FormControl, MenuItem, Select } from "@mui/material";

export default function ScheduleIntervalSelector(props) {
  return (
    <FormControl fullWidth>
      <Select
        id={props.id}
        value={props.value}
        onChange={props.onChange}
        name={props.name}
        size={props.size}
      >
        <MenuItem value="weekly">Weekly</MenuItem>
        <MenuItem value="bi-weekly">Bi-Weekly</MenuItem>
        <MenuItem value="semi-monthly">Semi-Monthly</MenuItem>
        <MenuItem value="monthly">Monthly</MenuItem>
      </Select>
    </FormControl>
  );
}
