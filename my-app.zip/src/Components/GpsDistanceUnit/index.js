import { FormControl, FormHelperText, MenuItem, Select } from "@mui/material";
import React from "react";

const GpsDistanceUnit = (props) => {
  return (
    <FormControl fullWidth>
      <Select
        id={props.id}
        value={props.value}
        label={props.label}
        onChange={props.onChange}
        name={props.name}
      >
        <MenuItem value={"ft"}>Feet</MenuItem>
        <MenuItem value={"mt"}>Meter</MenuItem>
      </Select>
      <FormHelperText>{props.helperText}</FormHelperText>
    </FormControl>
  );
};

export default GpsDistanceUnit;
