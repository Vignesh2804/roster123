import * as React from "react";
import Box from "@mui/material/Box";
import Collapse from "@mui/material/Collapse";
import IconButton from "@mui/material/IconButton";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";

function Row(props) {
  const [open, setOpen] = React.useState(false);

  return (
    <React.Fragment>
      {/* <TableRow sx={{ "& > *": { borderBottom: "unset" } }}>
        <TableCell>
          {props.row["Emp Name"]}{" "}
          <IconButton
            aria-label="expand row"
            size="small"
            onClick={() => setOpen(!open)}
          >
            {open ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
          </IconButton>
        </TableCell>
      </TableRow> */}
      {props.row && (
        <TableRow key={props.row.id}>
          {props.columns.map((col) => {
            return (
              <TableCell
                component="th"
                scope="row"
                key={props.row[col]}
                sx={{ border: 1 }}
              >
                {props.row[col]}
              </TableCell>
            );
          })}
        </TableRow>
      )}

      {/* <TableRow>
        <TableCell
          style={{ paddingBottom: 0, paddingTop: 0 }}
          colSpan={props.columns.length}
        >
          <Collapse
            in={open}
            timeout="auto"
            unmountOnExit
            sx={{ border: 1, ml: 0 }}
          >
            <Box sx={{ border: 1 }}>
              <Table size="small">
                <TableBody>
                  {props.row && (
                    <TableRow key={props.row.id}>
                      {props.columns.map((col) => {
                        return (
                          <TableCell
                            component="th"
                            scope="row"
                            key={props.row[col]}
                            sx={{ border: 1 }}
                          >
                            {props.row[col]}
                          </TableCell>
                        );
                      })}
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </Box>
          </Collapse>
        </TableCell>
      </TableRow> */}
    </React.Fragment>
  );
}

export default function CollapsibleTable(props) {
  return (
    <TableContainer component={Paper}>
      <Table aria-label="collapsible table">
        <TableHead>
          <TableRow>
            {props.columns.map((header) => (
              <TableCell key={header} sx={{ border: 1 }}>
                {header}
              </TableCell>
            ))}
          </TableRow>
        </TableHead>
        <TableBody>
          {props.rows &&
            props.rows.length > 0 &&
            props.rows.map((row) => (
              <Row key={row.id} row={row} columns={props.columns} />
            ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
