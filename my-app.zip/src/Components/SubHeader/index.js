import React from "react";
// import { Box, styled, alpha } from "@mui/material";
import {
  AppBar,
  Box,
  Toolbar,
  Typography,
  Button,
  IconButton,
} from "@mui/material";

import { Add } from "@mui/icons-material";
import { useHistory } from "react-router";
import CustomDialog from "../CustomDialog";
import SearchBar from "../SearchBar";

// const purple = colors.purple[500];

const SubHeader = (props) => {
  const history = useHistory();

  const [openDialog, setOpenDialog] = React.useState(false);

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const handleSubmit = (path) => {
    if (props.ButtonType === "navigation") {
      history.push(path);
    }

    if (props.ButtonType === "dialog") {
      setOpenDialog(true);
    }
  };

  return (
    <>
      <Box sx={{ flexGrow: 1 }}>
        <AppBar position="static" color="inherit">
          <Toolbar>
            <Typography
              variant="h6"
              noWrap
              component="div"
              sx={{
                flexGrow: 1,
                display: { xs: "none", sm: "flex" },
                color: "secondary.main",
              }}
            >
              {props.heading}
            </Typography>
            <SearchBar />
            &nbsp;&nbsp;
            {props.ButtonType !== "icon" && (
              <Button
                variant="contained"
                endIcon={<Add />}
                color="secondary"
                onClick={() => handleSubmit(props.navigateTo)}
              >
                Add {props.buttonText}
              </Button>
            )}
            {props.ButtonType === "icon" && (
              <IconButton>{props.icon}</IconButton>
            )}
          </Toolbar>
        </AppBar>
      </Box>
      {openDialog && (
        <CustomDialog
          open={openDialog}
          title="Add Announcement"
          handleClose={handleCloseDialog}
          handleSubmit={handleCloseDialog}
          buttonCancelText="Cancel"
          buttonSubmitText="Save"
          Content={props.dialogContent}
        />
      )}
    </>
  );
};

export default SubHeader;
