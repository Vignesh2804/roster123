import * as React from "react";
import Button from "@mui/material/Button";

import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";

export default function CustomDialog(props) {
  return (
    <div>
      <Dialog
        open={props.open}
        onClose={props.handleClose}
        fullWidth
        maxWidth={"sm"}
      >
        <DialogTitle>{props.title}</DialogTitle>
        <DialogContent>
          <DialogContentText>{props.contentText}</DialogContentText>
          {props.Content}
        </DialogContent>
        <DialogActions>
          <Button
            onClick={props.handleClose}
            variant="contained"
            sx={{ backgroundColor: "#616161" }}
          >
            {props.buttonCancelText}
          </Button>
          <Button
            onClick={props.handleSubmit}
            variant="contained"
            color="secondary"
          >
            {props.buttonSubmitText}
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}
