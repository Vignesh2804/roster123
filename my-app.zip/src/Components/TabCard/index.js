import { Paper, Box, Typography } from "@mui/material";
import React, { useEffect } from "react";
import Styles from "./TabCard.module.css";
import classNames from "classnames";

const TabCard = (props) => {
  const classes = classNames(Styles.tabCard, { [Styles.active]: props.active });

  return (
    <Box
      component={Paper}
      sx={{
        width: "100%",
        borderRadius: "10px",
        height: "100px",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
      className={classes}
    >
      <Box>
        <Box>
          <Box>{props.icon}</Box>
          <Box className={Styles.label}>{props.lbl}</Box>
        </Box>
      </Box>
      {props.description && (
        <Box sx={{ pl: "30px" }}>
          <Typography variant="p">{props.description}</Typography>
        </Box>
      )}
    </Box>
  );
};

export default TabCard;
