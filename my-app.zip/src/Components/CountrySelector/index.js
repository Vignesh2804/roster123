import * as React from "react";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
import CountryList from "../../Helpers/countryList";

export default function CountrySelect() {
  return (
    <Autocomplete
      id="country-select"
      options={CountryList}
      autoHighlight
      getOptionLabel={(option) => option.phone}
      renderOption={(props, option) => (
        <Box
          component="li"
          sx={{ mr: 2, flexShrink: 0, fontSize: "12px" }}
          {...props}
        >
          {option.label} +{option.phone}
        </Box>
      )}
      renderInput={(params) => (
        <TextField
          {...params}
          label="Country"
          inputProps={{
            ...params.inputProps,
            autoComplete: "Country", // disable autocomplete and autofill
          }}
        />
      )}
    />
  );
}
