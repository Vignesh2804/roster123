import { FormControl, MenuItem, Select } from "@mui/material";
import React from "react";

const DaysOfWeekSelector = (props) => {
  return (
    <FormControl fullWidth>
      <Select
        id={props.id}
        value={props.value}
        onChange={props.onChange}
        name={props.name}
        size={props.small}
      >
        <MenuItem value={"monday"}>Monday</MenuItem>
        <MenuItem value={"tuesday"}>Tuesday</MenuItem>
        <MenuItem value={"wednesday"}>Wednesday</MenuItem>
        <MenuItem value={"thursday"}>Thursday</MenuItem>
        <MenuItem value={"friday"}>Friday</MenuItem>
        <MenuItem value={"saturday"}>Saturday</MenuItem>
        <MenuItem value={"sunday"}>Sunday</MenuItem>
      </Select>
    </FormControl>
  );
};

export default DaysOfWeekSelector;
