import { FormControl, MenuItem, Select } from "@mui/material";
import React from "react";

const AlertsWhenSelector = (props) => {
  return (
    <FormControl fullWidth>
      <Select
        id={props.id}
        value={props.value}
        onChange={props.onChange}
        name={props.name}
        size={props.size}
      >
        {props.itemsList.map((item, index) => (
          <MenuItem key={index} value={item.value}>
            {item.label}
          </MenuItem>
        ))}
      </Select>
    </FormControl>
  );
};

export default AlertsWhenSelector;
