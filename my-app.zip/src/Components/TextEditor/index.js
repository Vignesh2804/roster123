import React from "react";
import { Editor } from "react-draft-wysiwyg";
import "react-draft-wysiwyg/dist/react-draft-wysiwyg.css"; // eslint-disable-line no-unused-vars
import styles from "./textEditor.module.css";
import { Button } from "@mui/material";

// top: "185px",
// right: "150px",
// position: "absolute",

const SaveButton = () => {
  const handlePostClick = () => {
    console.log("post button clicked");
  };
  return (
    <Button
      type="submit"
      variant="contained"
      color={"secondary"}
      size="small"
      onClick={handlePostClick}
      sx={{ height: "32px" }}
    >
      Post
    </Button>
  );
};

const TextEditor = () => {
  return (
    <div className={styles.root}>
      <Editor
        wrapperClassName={styles.wrapper}
        editorClassName={styles.editor}
        toolbar={{
          options: ["inline", "link", "emoji"],
          inline: {
            options: ["bold", "italic", "underline", "strikethrough"],
          },
          link: {
            options: ["link"],
          },
        }}
        toolbarCustomButtons={[<SaveButton />]}
      />
    </div>
  );
};

export default TextEditor;
