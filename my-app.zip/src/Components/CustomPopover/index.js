import React from "react";
import { Popover } from "@mui/material";

export default function CustomPopover(props) {
  return (
    <Popover
      id={props.id}
      open={props.open}
      anchorEl={props.anchorEl}
      onClose={props.handleClose}
      anchorOrigin={props.anchorOrigin}
      transformOrigin={props.transformOrigin}
    >
      {props.children}
    </Popover>
  );
}
