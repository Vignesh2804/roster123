import * as React from "react";
import TextField from "@mui/material/TextField";
import AdapterDateFns from "@mui/lab/AdapterDateFns";
import LocalizationProvider from "@mui/lab/LocalizationProvider";
import DateTimePicker from "@mui/lab/DateTimePicker";

export default function CustomDateTimePicker(props) {
  const handleDateChange = (date) => {
    props.onChange(props.id, date);
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <DateTimePicker
        renderInput={(props) => <TextField {...props} />}
        label={props.label || ""}
        value={props.value}
        onChange={handleDateChange}
      />
    </LocalizationProvider>
  );
}
