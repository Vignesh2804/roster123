import { ArrowBack } from "@mui/icons-material";
import { Button, IconButton, Typography } from "@mui/material";
import React from "react";
import { useHistory } from "react-router";
import CustomBreadCrumb from "../CustomBreadCrumb";
import { Box } from "@mui/material";

const AddPagesHeader = (props) => {
  const history = useHistory();

  const handleBackClick = (e) => {
    e.preventDefault();
    history.push(props.navigateTo);
  };

  return (
    <Box
      sx={{
        display: "flex",
        alignItems: "center",
        width: "100%",
        padding: "10px",
      }}
    >
      <Box>
        <CustomBreadCrumb
          firstLink={props.firstLink}
          secondLink={props.secondLink}
          navigateTo={props.navigateTo}
        />
      </Box>
      <Box sx={{ ml: "auto" }}>
        <Button
          variant="text"
          startIcon={<ArrowBack />}
          onClick={handleBackClick}
          size="small"
        >
          Back
        </Button>
      </Box>
    </Box>
  );
};

export default AddPagesHeader;
