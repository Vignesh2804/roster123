import React from "react";
import { Breadcrumbs, Link } from "@mui/material";
import { NavigateNext } from "@mui/icons-material";

const CustomBreadCrumb = (props) => {
  return (
    <Breadcrumbs
      sx={{ fontSize: "18px" }}
      separator={<NavigateNext fontSize="small" />}
    >
      <Link underline="hover" color="inherit" href={props.navigateTo}>
        {props.firstLink}
      </Link>
      <Link
        underline="hover"
        color="text.secondary"
        href="#"
        aria-current="page"
      >
        {props.secondLink}
      </Link>
    </Breadcrumbs>
  );
};

export default CustomBreadCrumb;
