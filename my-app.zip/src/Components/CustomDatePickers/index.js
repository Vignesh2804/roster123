import moment from "moment";
import MomentUtils from "@date-io/moment";
import { ArrowDropDown } from "@mui/icons-material";
import React, { useState } from "react";
import { DatePicker, MuiPickersUtilsProvider } from "@material-ui/pickers";
// import "moment/locale/fr";
// import "moment/locale/ru";

// moment.locale("fr"); // it is required to select default locale manually

// const localeMap = {
//   en: "en",
//   fr: "fr",
//   ru: "ru",
// };

function CustomDatePicker() {
  //   const [locale, setLocale] = useState("fr");
  // const [anchorEl, setAnchorEl] = useState(null);
  const [selectedDate, handleDateChange] = useState(new Date());

  return (
    <MuiPickersUtilsProvider
      libInstance={moment}
      utils={MomentUtils}
      //   locale={locale}
    >
      <DatePicker
        // disableToolbar
        variant="inline"
        value={selectedDate}
        onChange={handleDateChange}
        format="ddd . DD MMM"
        inputVariant="outlined"
        InputProps={{
          endAdornment: <ArrowDropDown />,
        }}
      />
    </MuiPickersUtilsProvider>
  );
}

export default CustomDatePicker;
