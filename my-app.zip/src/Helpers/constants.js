let Constants;
let url = "http://localhost:3000/";
// let url = "http://localhost:5101/";
// let url = "http://admapi.myprojectpreview.space/";
// let url = "http://api.africandollar.com/";

let socketUrl = "http://localhost:3010/";
// let socketUrl = "http://admsocket.myprojectpreview.space"
// let socketUrl = "http://socket.africandollar.com"

if (process.env.NODE_ENV === "production") {
    Constants = {
        API_URL: url + "api/",
        IMAGE_URL: url,
        SOCKET_URL: socketUrl
    };
} else {
    Constants = {
        API_URL: url + "api/",
        IMAGE_URL: url,
        SOCKET_URL: socketUrl
    };
}

export default Constants;