const helperTools = {
  formatCurrency: (value) => {
    let formatedValue = 0;
    if (value !== null && value !== "") {
      formatedValue = new Intl.NumberFormat().format(value);
    }
    return formatedValue;
  },
  decimalFormat: (value, fdigits) => {
    let formatedValue = 0;
    if (value !== null && value !== "") {
      formatedValue = new Intl.NumberFormat("en-Es", {
        minimumFractionDigits: fdigits,
      }).format(value);
    }
    return formatedValue;
  },
  toCamelCase: (str) => {
    if (str) {
      return str
        .replace(/(?:^\w|[A-Z]|\b\w)/g, function (word, index) {
          return index === 0 ? word.toLowerCase() : word.toUpperCase();
        })
        .replace(/\s+/g, "");
    }
  },
  mobileNoVisibleCustom: (number) => {
    if (number) {
      return (
        "x".repeat(number.length - 3) +
        number.slice(number.length - 3, number.length)
      );
    }
  },
  emailNoVisibleCustom: (mail) => {
    if (mail) {
      let name = mail.replace(/@.*/, "");
      return (
        "x".repeat(name.length - 3) + mail.slice(name.length - 3, name.length)
      );
    }
  },
  validateEmail: (email) => {
    var re =
      /^(([^<>()[]\\.,;:\s@"]+(\.[^<>()[]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
  },
};

export default helperTools;
