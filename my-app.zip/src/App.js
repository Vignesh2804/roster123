import "./App.css";
import MainRouter from "./utils/router";

function App() {
  return <MainRouter></MainRouter>;
}

export default App;
