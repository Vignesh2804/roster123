import { ClockIn, ClockOut } from "mdi-material-ui";
import { EventAvailableOutlined, TimerOffOutlined } from "@mui/icons-material";

//type = availability | timeoff | trial | clockin | clockout | shifts | Joined
export const dashNotifications = [
  {
    type: "availability",
    id: Math.random().toString(),
    icon: <EventAvailableOutlined />,
    user: "Rakesh",
    message: "Rakesh's availability changed",
    data: {
      createdAt: "24-09-2021 10:15 AM",
    },
  },
  {
    type: "timeoff",
    id: Math.random().toString(),
    icon: <TimerOffOutlined />,
    user: "Vignesh",
    message: "Vignesh has requested time off on 30-09-2021",
    data: {
      timeoff: [
        { fromTime: "30-09-2021 09:00 AM", toTime: "30-09-2021 06:00 PM" },
      ],
      createdAt: "25-09-2021 10:15 AM",
    },
  },
  {
    type: "clockout",
    id: Math.random().toString(),
    icon: <ClockOut />,
    user: "Vinoth",
    message: "You have missed out the clockout on 22-09-2021",
    data: {
      clockout: [
        {
          date: "22-09-2021",
        },
      ],
      createdAt: "26-09-2021 10:15 AM",
    },
  },
  {
    type: "clockin",
    id: Math.random().toString(),
    icon: <ClockIn />,
    user: "Vinoth",
    message: "You have clocked in late on 27-09-2021",
    data: {
      clockin: [
        {
          date: "24-09-2021",
          time: "10:20 AM",
          lateBy: "20 Mins",
        },
      ],
      createdAt: "27-09-2021 10:15 AM",
    },
  },
  {
    type: "Joined",
    id: Math.random().toString(),
    user: "Vimala Harris",
    icon: undefined,
    message: "Vimala Harris has joined on 28-09-2021",
    data: {
      joined: {
        date: "20-09-2021",
        via: "Invite",
      },
      createdAt: "28-09-2021 10:15 AM",
    },
  },
];
